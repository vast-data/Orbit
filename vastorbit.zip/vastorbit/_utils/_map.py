"""
SPDX-License-Identifier: Apache-2.0
"""

from typing import Literal, Optional


def vastorbit_agg_name(key: str, method: Optional[Literal["VAST"]] = None) -> str:
    """
    Returns the vastorbit correctly formatted key.
    This function is used to normalize aggregation
    names throughout the entire API.

    Parameters
    ----------
    key: str
        aggregation key.
    method: str, optional
        Can be ``None`` or ``VAST``.
        If ``None``, the output will represent
        the vastorbit aggregations. Otherwise
        it will represent VAST aggregations.

    Returns
    -------
    str
        Correctly Formatted Aggregation.

    Examples
    --------
    The following code demonstrates
    the usage of the function.

    .. ipython:: python

        # Import the function.
        from vastorbit._utils._map import vastorbit_agg_name

        # median
        vastorbit_agg_name('median')

        # variance
        vastorbit_agg_name('variance')

        # using 'VAST' method
        vastorbit_agg_name('std', method='VAST')

    .. note::

        These functions serve as utilities to
        construct others, simplifying the overall
        code.
    """
    key = key.lower()
    if key in ("median", "med"):
        key = "50%"
    elif key in ("approx_median", "approximate_median"):
        key = "approx_50%"
    elif key == "100%":
        key = "max"
    elif key == "0%":
        key = "min"
    elif key == "approx_distinct":
        key = "approx_unique"
    elif key == "approx_distinct":
        key = "approx_unique"
    elif key == "mean":
        key = "avg"
    elif key in ("stddev", "stdev"):
        key = "std"
    elif key == "product":
        key = "prod"
    elif key == "variance":
        key = "var"
    elif key == "kurt":
        key = "kurtosis"
    elif key == "skew":
        key = "skewness"
    elif key in ("top1", "mode"):
        key = "top"
    elif key == "top1_percent":
        key = "top_percent"
    elif "%" == key[-1]:
        start = 7 if len(key) >= 7 and key.startswith("approx_") else 0
        if float(key[start:-1]) == int(float(key[start:-1])):
            key = f"{int(float(key[start:-1]))}%"
            if start == 7:
                key = "approx_" + key
    elif key == "row":
        key = "row_number"
    elif key == "first":
        key = "first_value"
    elif key == "last":
        key = "last_value"
    elif key == "next":
        key = "lead"
    elif key in ("prev", "previous"):
        key = "lag"
    if method == "VAST":
        if key == "var":
            key = "variance"
        elif key == "std":
            key = "stddev"
    return key


def param_docstring(*args):
    """
    Constructs and inserts a parameter docstring
    into the decorated function's existing docstring.
    The decorator accepts a dictionary of parameter
    descriptions and then the keys to the parameters
    of the decorated function. For example:

    .. code-block:: python

        @param_docstring(
            PARAMETER_DESCRIPTIONS,
            'y_true',
            'y_score',
            'input_relation',
            'pos_label',
        )

    The decorator inserts the supplied parameter
    descriptions inbetween the function's description
    and the Returns section. For instance, in the
    following docstring, the above decorator would
    insert the parameter descriptions inbetween
    'Computes the Confusion Matrix' and 'Returns':

    Computes the Confusion Matrix.

    Returns
    -------
    Array
        confusion matrix.

    When several functions share the same parameters,
    this decorator can be used to improve code
    readability and doc consistency.

    .. note::

        To preserve correct spacing, add four spaces
        before the parameter name in the ``dictionary``
        value and for each following line. For example:

    ...
    'y_true': '''    y_true: str
        Response column.''',
    'y_score': '''    y_score: str
        Prediction.''',
    'input_relation': '''    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x''',
    ...
    """
    param_defs = args[0]
    parameter_docstring = """Parameters
    ----------\n"""
    for param in args[1:]:
        parameter_docstring += param_defs[param] + "\n"
    parameter_docstring += """
    Returns
    -------"""

    def docstring_decorator(func):
        existing_docstring = func.__doc__
        existing_docstring = existing_docstring.split("""Returns
    -------""")
        func.__doc__ = (
            existing_docstring[0] + parameter_docstring + existing_docstring[1]
        )

        return func

    return docstring_decorator
