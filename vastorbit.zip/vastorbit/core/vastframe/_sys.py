"""
SPDX-License-Identifier: Apache-2.0
"""

import copy
import sys
import time
from typing import Any, Optional, Union, TYPE_CHECKING

import vastorbit._config.config as conf
from vastorbit._typing import NoneType, SQLColumns
from vastorbit._utils._map import vastorbit_agg_name
from vastorbit._utils._object import create_new_vdc
from vastorbit._utils._print import print_message
from vastorbit._utils._sql._cast import to_varchar
from vastorbit._utils._sql._collect import save_vastorbit_logs
from vastorbit._utils._sql._format import format_type, indent_vo_sql, quote_ident
from vastorbit._utils._sql._random import _current_random
from vastorbit._utils._sql._sys import _executeSQL

from vastorbit.core.tablesample.base import TableSample

from vastorbit.core.vastframe._typing import vDFTyping, vDCTyping

if TYPE_CHECKING:
    from vastorbit.core.vastframe.base import VastFrame


class vDFSystem(vDFTyping):
    def __format__(self, format_spec: Any) -> str:
        return format(self._genSQL(), format_spec)

    def _add_to_history(self, message: str) -> "VastFrame":
        """
        vastorbit stores the user modification and helps the user
        to look at what they did. This method is used to add a
        customized message in the VastFrame history attribute.
        """
        self._vars["history"] += ["{" + time.strftime("%c") + "}" + " " + message]
        return self

    def _genSQL(
        self,
        split: bool = False,
        transformations: Optional[dict] = None,
        force_columns: Optional[SQLColumns] = None,
    ) -> str:
        """
        Method used to generate the SQL final relation. It
        looks at all transformations and builds a nested query where
        each transformation is associated to a specific floor.

        Parameters
        ----------
        split: bool, optional
            Adds a split  column __vastorbit_split__ in the relation,
            which can be used to downsample the data.
        transformations: dict, optional
            Dictionary of columns and their respective transformation.
            It can be used to test if an expression is correct and
            can be added in the final relation.
        force_columns: SQLColumns, optional
            Columns used to generate the final relation.

        Returns
        -------
        str
            The SQL final relation.
        """
        # The First step is to find the Max Floor
        all_imputations_grammar = []
        transformations = format_type(transformations, dtype=dict)
        force_columns = format_type(force_columns, dtype=list)
        force_columns_copy = copy.deepcopy(force_columns)
        if len(force_columns) == 0:
            force_columns = copy.deepcopy(self._vars["columns"])
        for column in force_columns:
            all_imputations_grammar += [
                [transformation[0] for transformation in self[column]._transf]
            ]
        for column in transformations:
            all_imputations_grammar += [transformations[column]]
        max_transformation_floor = len(max(all_imputations_grammar, key=len))
        # We complete all virtual columns transformations which do not have enough floors
        # with the identity transformation x :-> x in order to generate the correct SQL query
        for imputations in all_imputations_grammar:
            diff = max_transformation_floor - len(imputations)
            if diff > 0:
                imputations += ["{}"] * diff
        # We find the position of all filters in order to write them at the correct floor
        where_positions = [item[1] for item in self._vars["where"]]
        max_where_pos = max(where_positions + [0])
        all_where = [[] for item in range(max_where_pos + 1)]
        for i in range(0, len(self._vars["where"])):
            all_where[where_positions[i]] += [self._vars["where"][i][0]]
        all_where = [
            " AND ".join([f"({c})" for c in condition]) for condition in all_where
        ]
        for i in range(len(all_where)):
            if all_where[i] != "":
                all_where[i] = f" WHERE {all_where[i]}"
        # We compute the first floor
        columns = force_columns + [column for column in transformations]
        first_values = [item[0] for item in all_imputations_grammar]
        transformations_first_floor = False
        for i in range(0, len(first_values)):
            if (first_values[i] != "___vastorbit_UNDEFINED___") and (
                first_values[i] != columns[i]
            ):
                first_values[i] = f"{first_values[i]} AS {columns[i]}"
                transformations_first_floor = True
        all_undefined = True
        for v in first_values:
            if v != "___vastorbit_UNDEFINED___":
                all_undefined = False
                break
        if (
            (transformations_first_floor)
            or (self._vars["allcols_ind"] != len(first_values))
        ) and not all_undefined:
            table = f"""
                SELECT 
                    {', '.join(first_values)} 
                FROM {self._vars['main_relation']}"""
        else:
            table = f"""SELECT * FROM {self._vars["main_relation"]}"""
        # We compute the other floors
        for i in range(1, max_transformation_floor):
            values = [item[i] for item in all_imputations_grammar]
            for j in range(0, len(values)):
                if values[j] == "{}":
                    values[j] = columns[j]
                elif values[j] != "___vastorbit_UNDEFINED___":
                    values_str = values[j].replace("{}", columns[j])
                    values[j] = f"{values_str} AS {columns[j]}"
            table = f"SELECT {', '.join(values)} FROM ({table}) VASTORBIT_SUBTABLE"
            if len(all_where) > i - 1:
                table += all_where[i - 1]
            if (i - 1) in self._vars["order_by"]:
                table += self._vars["order_by"][i - 1]
        where_final = (
            all_where[max_transformation_floor - 1]
            if (len(all_where) > max_transformation_floor - 1)
            else ""
        )
        # Only the last order_by matters as the order_by will never change
        # the final relation
        try:
            order_final = self._vars["order_by"][max_transformation_floor - 1]
        except (IndexError, KeyError):
            order_final = ""
        for vml_undefined in [
            ", ___vastorbit_UNDEFINED___",
            "___vastorbit_UNDEFINED___, ",
            "___vastorbit_UNDEFINED___",
        ]:
            table = table.replace(vml_undefined, "")
        random_func = _current_random()
        split = f", {random_func} AS __vastorbit_split__" if (split) else ""
        if (where_final == "") and (order_final == ""):
            if split:
                table = f"SELECT *{split} FROM ({table}) VASTORBIT_SUBTABLE"
            table = f"({table}) VASTORBIT_SUBTABLE"
        else:
            table = f"({table}) VASTORBIT_SUBTABLE{where_final}{order_final}"
            table = f"(SELECT *{split} FROM {table}) VASTORBIT_SUBTABLE"
        if (self._vars["exclude_columns"]) and not split:
            if not force_columns_copy:
                force_columns_copy = self.get_columns()
            force_columns_copy = ", ".join(force_columns_copy)
            table = f"""
                (SELECT 
                    {force_columns_copy}{split} 
                FROM {table}) VASTORBIT_SUBTABLE"""
        main_relation = self._vars["main_relation"]
        all_main_relation = f"(SELECT * FROM {main_relation}) VASTORBIT_SUBTABLE"
        return table.replace(all_main_relation, main_relation)

    def _get_catalog_value(
        self,
        column: Optional[str] = None,
        key: Optional[str] = None,
        method: Optional[str] = None,
        columns: Optional[SQLColumns] = None,
    ) -> Optional[str]:
        """
        vastorbit  stores  the  already  computed aggregations to  avoid
        useless computations. This method returns the stored aggregation
        if it was already computed.
        """
        if not conf.get_option("cache"):
            return "VASTORBIT_NOT_PRECOMPUTED"
        if column == "vastorbit_COUNT":
            if self._vars["count"] < 0:
                return "VASTORBIT_NOT_PRECOMPUTED"
            total = self._vars["count"]
            if not isinstance(total, (int, float)):
                return "VASTORBIT_NOT_PRECOMPUTED"
            return total
        elif method:
            method = vastorbit_agg_name(str(method).lower())
            if columns[1] in self[columns[0]]._catalog[method]:
                return self[columns[0]]._catalog[method][columns[1]]
            else:
                return "VASTORBIT_NOT_PRECOMPUTED"
        key = vastorbit_agg_name(key.lower())
        column = self.format_colnames(column)
        try:
            if (key == "approx_unique") and ("unique" in self[column]._catalog):
                key = "unique"
            result = (
                "VASTORBIT_NOT_PRECOMPUTED"
                if key not in self[column]._catalog
                else self[column]._catalog[key]
            )
        except AttributeError:
            result = "VASTORBIT_NOT_PRECOMPUTED"
        if result != result:
            result = None
        if ("top" not in key) and isinstance(result, NoneType):
            return "VASTORBIT_NOT_PRECOMPUTED"
        return result

    def _get_last_order_by(self) -> str:
        """
        Returns the last column used to sort the data.
        """
        max_pos, order_by = 0, ""
        columns_tmp = copy.deepcopy(self.get_columns())
        for column in columns_tmp:
            max_pos = max(max_pos, len(self[column]._transf) - 1)
        if max_pos in self._vars["order_by"]:
            order_by = self._vars["order_by"][max_pos]
        return order_by

    def _get_hash_syntax(self, columns: Union[dict, SQLColumns]) -> str:
        """
        Returns the SQL syntax used to segment using the input columns.
        """
        if not columns:
            return ""
        segment_cols = quote_ident(columns)
        segment_cols = ", ".join(
            [
                f"FROM_BIG_ENDIAN_64(XXHASH64(TO_UTF8(CAST(({col} AS VARCHAR))))"
                for col in segment_cols
            ]
        )
        return f" SEGMENTED BY {segment_cols} ALL NODES"

    def _get_sort_syntax(self, columns: Union[dict, SQLColumns]) -> str:
        """
        Returns the SQL syntax used to sort the input columns.
        """
        if not columns:
            return ""
        if isinstance(columns, dict):
            order_by = []
            for col in columns:
                column_name = self.format_colnames(col)
                if columns[col].lower() not in ("asc", "desc"):
                    warning_message = (
                        f"Method of {column_name} must be in (asc, desc), "
                        f"found '{columns[col].lower()}'\nThis column was ignored."
                    )
                    print_message(warning_message, "warning")
                else:
                    order_by += [f"{column_name} {columns[col].upper()}"]
        else:
            order_by = quote_ident(columns)
        return f" ORDER BY {', '.join(order_by)}"

    def _update_catalog(
        self,
        values: Optional[dict] = None,
        erase: bool = False,
        columns: Optional[SQLColumns] = None,
        matrix: Optional[str] = None,
        column: Optional[str] = None,
    ) -> None:
        """
        vastorbit stores the already computed aggregations to
        avoid useless  computations.  This  method stores the
        input aggregation in the VastColumn catalog.
        """
        values = format_type(values, dtype=dict)
        columns = format_type(columns, dtype=list)
        columns = self.format_colnames(columns)
        agg_dict = {
            "cov": {},
            "pearson": {},
            "spearman": {},
            "spearmand": {},
            "kendall": {},
            "cramer": {},
            "biserial": {},
            "regr_avgx": {},
            "regr_avgy": {},
            "regr_count": {},
            "regr_intercept": {},
            "regr_r2": {},
            "regr_slope": {},
            "regr_sxx": {},
            "regr_sxy": {},
            "regr_syy": {},
        }
        if erase:
            if not columns:
                columns = self.get_columns()
            for column in columns:
                self[column]._catalog = copy.deepcopy(agg_dict)
            self._vars["count"] = -1
        elif matrix:
            matrix = vastorbit_agg_name(matrix.lower())
            if matrix in agg_dict:
                for elem in values:
                    val = values[elem]
                    try:
                        val = float(val)
                    except (TypeError, ValueError):
                        pass
                    self[column]._catalog[matrix][elem] = val
        else:
            columns = list(values)
            columns.remove("index")
            for column in columns:
                for i in range(len(values["index"])):
                    key, val = values["index"][i].lower(), values[column][i]
                    if key not in ["listagg"]:
                        key = vastorbit_agg_name(key)
                        try:
                            val = float(val)
                            if val - int(val) == 0:
                                val = int(val)
                        except (OverflowError, TypeError, ValueError):
                            pass
                        if val != val:
                            val = None
                        self[column]._catalog[key] = val

    def current_relation(self, reindent: bool = True, split: bool = False) -> str:
        """
        Returns the current VastFrame relation.

        Parameters
        ----------
        reindent: bool, optional
            Reindent the text to be more readable.
        split: bool, optional
            Adds a split  column __vastorbit_split__
            in the  relation, which can be used to
            downsample the data.

        Returns
        -------
        str
            The formatted current VastFrame relation.

        Examples
        --------
        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset;

        .. ipython:: python

            vdf = vo.VastFrame({"val": [0, 10, 20]})

        .. ipython:: python
            :suppress:

            result = vdf
            html_file = open("SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html

        Now we can check its current relation conveniently by:

        .. ipython:: python

            print(vdf.current_relation())

        If we make any changes to the :py:class:`~VastFrame`,
        those will also be reflected in the ``current_relation``.
        For example, we normalize the data:

        .. ipython:: python

            vdf.normalize()

        Let us observe the current relation now:

        .. ipython:: python

            print(vdf.current_relation())

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.explain` : Information on how
                VAST is computing the current :py:class:`~VastFrame` relation.
            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.info` : Displays information
                about the different VastFrame transformations

        """
        if reindent:
            return indent_vo_sql(self._genSQL(split=split))
        else:
            return self._genSQL(split=split)

    def del_catalog(self) -> "VastFrame":
        """
        Deletes the current VastFrame catalog.

        Returns
        -------
        VastFrame
            self

        Examples
        --------
        Aggregate results are cached to optimize
        computation. Sometimes cached results
        can be problemtic or not desired. In those
        cases ``del_catalog`` can be used to delete
        all cached aggregates.

        Let us look at the below example:

        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        We have a dummy data:

        .. ipython:: python

            vdf = vo.VastFrame({"val": [0, 10, 20]})

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html

        We can create the summary of the
        :py:class:`~VastFrame` using:

        .. code-block:: python

            vdf.describe()

        .. ipython:: python
            :suppress:

            result = vdf.describe()
            html_file = open("SPHINX_DIRECTORY/figures/core_VastFrame_sys_del_catalog.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_del_catalog.html

        No if we look at the cache, we can see the stored values:

        .. ipython:: python

            vdf["val"]._catalog

        In order to erase the stored values we can use:

        .. code-block:: python

            vdf.del_catalog()

        .. ipython:: python
            :suppress:

            vdf.del_catalog()

        Now there will not be any stored values:

        .. ipython:: python

            vdf["val"]._catalog

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.explain` : Information on how
                VAST is computing the current :py:class:`~VastFrame` relation.
        """
        self._update_catalog(erase=True)
        return self

    def empty(self) -> bool:
        """
        Returns True if the VastFrame is empty.

        Returns
        -------
        bool
            True if the VastFrame has no VastColumns.

        Examples
        --------

        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and check:

        .. code-block:: python

            vdf = vo.VastFrame({"val": [0, 10, 20]})

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html

        Let's check if it is empty:

        .. ipython:: python

            vdf.empty()

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.explain` : Information on how
                VAST is computing the current :py:class:`~VastFrame` relation.
        """
        return not self.get_columns()

    @save_vastorbit_logs
    def expected_store_usage(self, unit: str = "b") -> TableSample:
        """
        Returns the VastFrame expected store usage.

        Parameters
        ----------
        unit: str, optional
            Unit used for the computation.
            b : byte
            kb: kilo byte
            gb: giga byte
            tb: tera byte

        Returns
        -------
        TableSample
            result.

        Examples
        --------
        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and check its expected storage:

        .. code-block:: python

            vdf = vo.VastFrame({"val": [0, 10, 20]})

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html

        We can check the expected storage of the
        :py:class:`~VastFrame` using:

        .. code-block:: python

            vdf.expected_store_usage()

        .. ipython:: python
            :suppress:

            result = vdf.expected_store_usage()
            html_file = open("SPHINX_DIRECTORY/figures/core_VastFrame_sys_expected_store_usage.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_expected_store_usage.html

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.memory_usage` : :py:class:`~VastFrame` memory usage
            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.explain` : Information on how
                VAST is computing the current :py:class:`~VastFrame` relation.
        """
        if unit.lower() == "kb":
            div_unit = 1024
        elif unit.lower() == "mb":
            div_unit = 1024 * 1024
        elif unit.lower() == "gb":
            div_unit = 1024 * 1024 * 1024
        elif unit.lower() == "tb":
            div_unit = 1024 * 1024 * 1024 * 1024
        else:
            unit, div_unit = "b", 1
        total, total_expected = 0, 0
        columns = self.get_columns()
        values = self.aggregate(func=["count"], columns=columns).transpose().values
        values["index"] = [
            f"expected_size ({unit})",
            f"max_size ({unit})",
            "type",
        ]
        for column in columns:
            ctype = self[column].ctype()
            if ctype.startswith(("date", "time", "interval", "smalldatetime")):
                maxsize, expsize = 8, 8
            elif "int" in ctype:
                maxsize, expsize = 8, self[column].store_usage()
            elif ctype.startswith("bool"):
                maxsize, expsize = 1, 1
            elif ctype.startswith(("real", "double", "real")):
                maxsize, expsize = 8, 8
            elif ctype.startswith(("decimal", "number", "numeric", "money")):
                try:
                    size = sum(
                        int(item)
                        for item in ctype.split("(")[1].split(")")[0].split(",")
                    )
                except IndexError:
                    size = 38
                maxsize, expsize = size, size
            elif ctype.startswith("varchar"):
                try:
                    size = int(ctype.split("(")[1].split(")")[0])
                except IndexError:
                    size = 80
                maxsize, expsize = size, self[column].store_usage()
            elif ctype.startswith("geo") or ctype.endswith(
                ("binary", "bytea", "char", "raw")
            ):
                try:
                    size = int(ctype.split("(")[1].split(")")[0])
                    maxsize, expsize = size, size
                except IndexError:
                    if ctype.startswith("geo"):
                        maxsize, expsize = 10000000, 10000
                    elif ctype.startswith("long"):
                        maxsize, expsize = 32000000, 10000
                    else:
                        maxsize, expsize = 65000, 1000
            elif ctype.startswith("uuid"):
                maxsize, expsize = 16, 16
            else:
                maxsize, expsize = 80, self[column].store_usage()
            maxsize /= div_unit
            expsize /= div_unit
            values[column] = [expsize, values[column][0] * maxsize, ctype]
            total_expected += values[column][0]
            total += values[column][1]
        values["separator"] = [
            len(columns) * self.shape()[0] / div_unit,
            len(columns) * self.shape()[0] / div_unit,
            "",
        ]
        total += values["separator"][0]
        total_expected += values["separator"][0]
        values["header"] = [
            (sum(len(col) for col in columns) + len(columns)) / div_unit,
            (sum(len(col) for col in columns) + len(columns)) / div_unit,
            "",
        ]
        total += values["header"][0]
        total_expected += values["header"][0]
        values["rawsize"] = [total_expected, total, ""]
        return TableSample(values=values).transpose()

    @save_vastorbit_logs
    def explain(self, analyze: bool = False, verbose: bool = False) -> str:
        """
        Provides information on how Trino is computing
        the current :py:class:`~VastFrame` relation.

        Parameters
        ----------
        analyze: bool, optional
            If set to True, executes the query and returns
            runtime statistics in addition to the plan.
        verbose: bool, optional
            If set to True, returns more detailed information
            including cost estimates and statistics.

        Returns
        -------
        str
            explain plan

        Examples
        --------
        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and check its Query Plan:

        .. ipython:: python

            vdf = vo.VastFrame({"val": [0, 10, 20]})

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html

        We can display the Query Plan of the :py:class:`~VastFrame`
        using:

        .. ipython:: python

            print(vdf.explain())

        For more detailed information with runtime statistics:

        .. ipython:: python

            print(vdf.explain(analyze=True))

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.info` : Displays information
                about the different VastFrame transformations
        """
        # Build EXPLAIN statement based on options
        explain_type = []
        if verbose:
            analyze = True

        if analyze:
            explain_type.append("ANALYZE")

        if verbose:
            explain_type.append("VERBOSE")

        explain_clause = "EXPLAIN " + " ".join(explain_type)

        result = _executeSQL(
            query=f"""
                {explain_clause}
                SELECT 
                    /*+LABEL('VastFrame.explain')*/ * 
                FROM {self}""",
            title="Explaining the Current Relation",
            method="fetchall",
        )

        # Trino returns explain plan as rows
        # Concatenate all rows into a single string
        if result:
            result = "\n".join([str(row[0]) for row in result])
        else:
            result = "No execution plan available"

        return result

    def info(self) -> str:
        """
        Displays information about the different VastFrame
        transformations.

        Returns
        -------
        str
            information on the VastFrame modifications

        Examples
        --------
        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and check modifications:

        .. ipython:: python

            vdf = vo.VastFrame({"val": [0, 10, 20]})

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html

        Since the :py:class:`~VastFrame` just got created,
        it will have no modifications. We can check:

        .. ipython:: python

            vdf.info()

        Next we can add 10 to all the values:

        .. ipython:: python

            vdf["val"] = 10 + vdf["val"]

        .. ipython:: python
            :suppress:

            result = vdf
            html_file = open("SPHINX_DIRECTORY/figures/core_VastFrame_sys_info.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_info.html

        We can check the modifications:

        .. ipython:: python

            vdf.info()

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.explain` : Information on how
                VAST is computing the current :py:class:`~VastFrame` relation.
        """
        if len(self._vars["history"]) == 0:
            result = "The VastFrame was never modified."
        elif len(self._vars["history"]) == 1:
            result = "The VastFrame was modified with only one action: "
            result += "\n * " + self._vars["history"][0]
        else:
            result = "The VastFrame was modified many times: "
            for modif in self._vars["history"]:
                result += "\n * " + modif
        return result

    @save_vastorbit_logs
    def memory_usage(self) -> TableSample:
        """
        Returns the VastFrame memory usage.

        Returns
        -------
        TableSample
            result.

        Examples
        --------
        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and check its
        memory usage:

        .. code-block:: python

            vdf = vo.VastFrame({"val": [0, 10, 20]})

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html

        We can see the memory usage of the
        :py:class:`~VastFrame` using:

        .. ipython:: python

            vdf.memory_usage()

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.expected_store_usage` :
                Returns the :py:class:`~VastFrame` expected store usage.

        """
        total = sum(sys.getsizeof(v) for v in self._vars) + sys.getsizeof(self)
        values = {"index": ["object"], "value": [total]}
        columns = copy.deepcopy(self._vars["columns"])
        for column in columns:
            values["index"] += [column]
            values["value"] += [self[column].memory_usage()]
            total += self[column].memory_usage()
        values["index"] += ["total"]
        values["value"] += [total]
        return TableSample(values=values)

    @save_vastorbit_logs
    def swap(self, column1: Union[int, str], column2: Union[int, str]) -> "VastFrame":
        """
        Swap the two input VastColumns.

        Parameters
        ----------
        column1: str | int
            The first  VastColumn or its index to swap.
        column2: str | int
            The second VastColumn or its index to swap.

        Returns
        -------
        VastFrame
            self

        Examples
        --------
        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and swap its columns:

        .. ipython:: python

            vdf = vo.VastFrame(
                {
                    "val" : [0, 10, 20],
                    "cat": ['a', 'b', 'c'],
                },
            )

        .. ipython:: python
            :suppress:

            result = vdf
            html_file = open("SPHINX_DIRECTORY/figures/core_VastFrame_sys_swap.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_swap.html

        We can swap the categorical column and value columns:

        .. code-block:: python

            vdf.swap("val", "cat")

        .. ipython:: python
            :suppress:

            vdf.swap("val", "cat")
            result = vdf
            html_file = open("SPHINX_DIRECTORY/figures/core_VastFrame_sys_swap_2.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_swap_2.html

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.info` : Displays information
                about the different VastFrame transformations
        """
        if isinstance(column1, int):
            assert column1 < self.shape()[1], ValueError(
                "The parameter 'column1' is incorrect, it is greater or equal "
                f"to the VastFrame number of columns: {column1}>={self.shape()[1]}"
                "\nWhen this parameter type is 'integer', it must represent the index "
                "of the column to swap."
            )
            column1 = self.get_columns()[column1]
        if isinstance(column2, int):
            assert column2 < self.shape()[1], ValueError(
                "The parameter 'column2' is incorrect, it is greater or equal "
                f"to the VastFrame number of columns: {column2}>={self.shape()[1]}"
                "\nWhen this parameter type is 'integer', it must represent the "
                "index of the column to swap."
            )
            column2 = self.get_columns()[column2]
        column1, column2 = self.format_colnames(column1, column2)
        columns = self._vars["columns"]
        all_cols = {}
        for idx, elem in enumerate(columns):
            all_cols[elem] = idx
        columns[all_cols[column1]], columns[all_cols[column2]] = (
            columns[all_cols[column2]],
            columns[all_cols[column1]],
        )
        return self


class vDCSystem(vDCTyping):
    def __format__(self, format_spec) -> str:
        return format(self._alias, format_spec)

    def add_copy(self, name: str) -> "VastFrame":
        """
        Adds a copy VastColumn to the parent VastFrame.

        Parameters
        ----------
        name: str
            Name of the copy.

        Returns
        -------
        VastFrame
            self._parent

        Examples
        --------

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and copy one
        of its columns:

        .. ipython:: python

            vdf = vo.VastFrame(
                {
                    "val" : [0, 10, 20],
                    "cat": ['a', 'b', 'c'],
                },
            )

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_swap.html

        We can copy the "val" column, and name the
        new column:

        .. code-block:: python

            vdf["val"].add_copy("val_copy")

        .. ipython:: python
            :suppress:

            vdf["val"].add_copy("val_copy")
            result = vdf
            html_file = open("SPHINX_DIRECTORY/figures/core_VastFrame_sys_add_copy.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_add_copy.html

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.info` : Displays information
                about the different VastFrame transformations
        """
        if name == "":
            raise ValueError("The parameter 'name' must not be empty")
        elif self._parent.is_colname_in(name):
            raise ValueError(
                f"A VastColumn has already the alias {name}.\nBy changing "
                "the parameter 'name', you'll be able to solve this issue."
            )
        name = quote_ident(name.replace('"', "_"))
        new_VastColumn = create_new_vdc(
            name,
            parent=self._parent,
            transformations=list(self._transf),
            catalog=self._catalog,
        )
        setattr(self._parent, name, new_VastColumn)
        setattr(self._parent, name[1:-1], new_VastColumn)
        self._parent._vars["columns"] += [name]
        self._parent._add_to_history(
            f"[Add Copy]: A copy of the VastColumn {self} "
            f"named {name} was added to the VastFrame."
        )
        return self._parent

    @save_vastorbit_logs
    def memory_usage(self) -> float:
        """
        Returns the VastColumn memory usage.

        Returns
        -------
        float
            VastColumn memory usage (byte)

        Examples
        --------
        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and check its memory usage:

        .. code-block:: python

            vdf = vo.VastFrame({"val": [0, 10, 20]})

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html

        We can see the memory usage of the
        :py:class:`~VastColumn` using:

        .. ipython:: python

            vdf["val"].memory_usage()

        .. seealso::

            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.memory_usage` : :py:class:`~VastFrame` memory usage.
            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.explain` : Information on how.
                VAST is computing the current :py:class:`~VastFrame` relation.
        """
        total = (
            sys.getsizeof(self)
            + sys.getsizeof(self._alias)
            + sys.getsizeof(self._transf)
            + sys.getsizeof(self._catalog)
        )
        for elem in self._catalog:
            total += sys.getsizeof(elem)
        return total

    @save_vastorbit_logs
    def store_usage(self) -> int:
        """
        Returns the VastColumn expected store usage (unit: b).

        Returns
        -------
        int
            VastColumn expected store usage.

        Examples
        --------
        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and check its
        expected storage:

        .. code-block:: python

            vdf = vo.VastFrame({"val": [0, 10, 20]})

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_current_relation.html

        We can check the expected storage of the
        :py:class:`~VastFrame` using:

        .. ipython:: python

            vdf["val"].store_usage()

        .. seealso::

            | ``VastColumn.``:py:meth:`~vastorbit.VastColumn.memory_usage` :
                :py:class:`~VastColumn` memory usage.
            | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.explain` : Information on how
                VAST is computing the current :py:class:`~VastFrame` relation.
        """
        pre_comp = self._parent._get_catalog_value(self._alias, "store_usage")
        if pre_comp != "VASTORBIT_NOT_PRECOMPUTED":
            return pre_comp
        alias_sql_repr = to_varchar(self.category(), self._alias)
        store_usage = _executeSQL(
            query=f"""
                SELECT 
                    /*+LABEL('VastColumn.storage_usage')*/ 
                    COALESCE(SUM(LENGTH(CAST({alias_sql_repr} AS VARCHAR))), 0) 
                FROM {self._parent}""",
            title=f"Computing the Store Usage of the VastColumn {self}.",
            method="fetchfirstelem",
        )
        self._parent._update_catalog(
            {"index": ["store_usage"], self._alias: [store_usage]}
        )
        return store_usage

    def rename(
        self,
        new_name: str,
        inplace: bool = True,
    ) -> "VastFrame":
        """
        Renames the VastColumn. This function is not
        directly applied to the input object.

        .. warning::

            SQL code generation will be slower if the
            ``VastFrame`` has been transformed multiple
            times, so it's better to use this method when
            first preparing your data. It is even
            recommended to use the
            ``VastFrame.``:py:meth:`~vastorbit.VastFrame.select`
            method directly and perform all renaming within
            a single operation.

        Parameters
        ----------
        new_name: str
            The new VastColumn alias.
        inplace: bool, optional
            If set to ``True``, the
            :py:class:`~VastFrame` is replaced
            with the new relation.

        Returns
        -------
        VastFrame
            result.

        Examples
        --------
        Let's begin by importing `vastorbit`.

        .. ipython:: python

            import vastorbit as vo

        .. hint::

            By assigning an alias to :py:mod:`vastorbit`,
            we mitigate the risk of code collisions with
            other libraries. This precaution is necessary
            because vastorbit uses commonly known function
            names like "average" and "median", which can
            potentially lead to naming conflicts. The use
            of an alias ensures that the functions from
            :py:mod:`vastorbit` are used as intended
            without interfering with functions from other
            libraries.

        Let us create a dummy dataset and rename one
        of its columns:

        .. ipython:: python

            vdf = vo.VastFrame(
                {
                    "val" : [0, 10, 20],
                    "cat": ['a', 'b', 'c'],
                },
            )

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_swap.html

        We can copy the "val" column, and name the
        new column:

        .. code-block:: python

            vdf["val"].rename("value")

        .. ipython:: python
            :suppress:

            result = vdf["val"].rename("value", inplace=False)
            html_file = open("SPHINX_DIRECTORY/figures/core_VastFrame_sys_rename.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/core_VastFrame_sys_rename.html

        .. seealso::

            | ``VastColumn.``:py:meth:`~vastorbit.VastColumn.add_copy` : Adds a
                copy :py:class:`~VastColumn` to the parent VastFrame.
        """
        old_name = quote_ident(self._alias)
        new_name = quote_ident(new_name)
        if self._parent.is_colname_in(new_name):
            raise NameError(
                f"A VastColumn has already the alias {new_name}.\n"
                "By changing the parameter 'new_name', you'll "
                "be able to solve this issue."
            )
        res = self._parent.select(
            self._parent.get_columns(exclude_columns=[old_name])
            + [f"{old_name} AS {new_name}"]
        )
        if inplace:
            self._parent.__init__(res.current_relation())
            return self._parent
        return res
