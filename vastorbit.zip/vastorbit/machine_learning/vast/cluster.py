"""
SPDX-License-Identifier: Apache-2.0
"""

from typing import Literal, Optional

import numpy as np
import sklearn

from vastorbit.connection.errors import QueryError

import vastorbit._config.config as conf
from vastorbit._typing import (
    NoneType,
    PlottingObject,
    PythonScalar,
    SQLColumns,
    SQLRelation,
)
from vastorbit._utils._gen import gen_tmp_name
from vastorbit._utils._sql._collect import save_vastorbit_logs
from vastorbit._utils._sql._format import format_type, quote_ident
from vastorbit._utils._sql._sys import _executeSQL

from vastorbit.core.tablesample.base import TableSample
from vastorbit.core.vastframe.base import VastFrame

import vastorbit.machine_learning.memmodel as mm
from vastorbit.machine_learning.vast.base import (
    MulticlassClassifier,
    Tree,
    Unsupervised,
    VASTModel,
)

from vastorbit.sql.drop import drop

if conf.get_import_success("graphviz"):
    from graphviz import Source

"""
General Class.
"""


class Clustering(Unsupervised):

    # Prediction / Transformation Methods.

    def predict(
        self,
        vdf: SQLRelation,
        X: Optional[SQLColumns] = None,
        name: Optional[str] = None,
        inplace: bool = True,
    ) -> VastFrame:
        """
        Makes predictions using
        the input relation.

        Parameters
        ----------
        vdf: SQLRelation
            Object used to run the prediction.
            You can also specify a customized
            relation, but you must enclose it
            with an alias. For example:
            ``(SELECT 1) x`` is valid whereas
            ``(SELECT 1)`` and ``SELECT 1``
            are invalid.
        X: SQLColumns, optional
            ``list`` of the columns used to
            deploy the models. If empty, the
            model predictors are used.
        name: str, optional
            Name of the added
            :py:class:`~VastColumn`.
            If empty, a name is generated.
        inplace: bool, optional
            If set to ``True``, the prediction
            is added to the :py:class:`~VastFrame`.

        Returns
        -------
        VastFrame
            the input object.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import KMeans

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = KMeans(
                n_clusters = 8,
                init = "k-means++",
                max_iter = 300,
                tol = 1e-4,
            )

        We can then fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(data, X = ["density", "sulphates"])

        Predicting or ranking the
        dataset is straight-forward:

        .. ipython:: python
            :suppress:
            :okexcept:

            result = model.predict(data, ["density", "sulphates"], name = "Cluster IDs")
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_prediction.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.predict(data, ["density", "sulphates"], name = "Cluster IDs")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_prediction.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        if isinstance(X, NoneType):
            X = self.X
        X = format_type(X, dtype=list)
        if isinstance(vdf, str):
            vdf = VastFrame(vdf)
        X = quote_ident(X)
        if not name:
            name = (
                self._model_type
                + "_"
                + "".join(ch for ch in self.model_name if ch.isalnum())
            )
        if inplace:
            return vdf.eval(name, self.deploySQL(X=X))
        else:
            return vdf.copy().eval(name, self.deploySQL(X=X))

    def _get_plot_kwargs(
        self,
        nbins: int = 30,
        chart: Optional[PlottingObject] = None,
        method: Optional[str] = None,
    ) -> dict:
        """
        Returns the kwargs used by plotting methods.
        """
        res = {"nbins": nbins, "chart": chart}
        if method == "contour":
            res["func_name"] = "cluster"
        else:
            raise NotImplementedError
        return res

    def plot(
        self,
        max_nb_points: int = 100,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> PlottingObject:
        """
        Draws the model.

        Parameters
        ----------
        max_nb_points: int
            Maximum number of
            points to display.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to
            pass to the Plotting functions.

        Returns
        -------
        obj
            Plotting Object.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html


        Let's import the model:

        .. ipython:: python
            :okwarning:

            from vastorbit.machine_learning.vast import KMeans

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = KMeans(
                n_clusters = 8,
                init = "k-means++",
                max_iter = 300,
                tol = 1e-4,
            )

        We can then fit the model:

        .. code-block:: python

            model.fit(data, X = ["density", "sulphates"])

        .. ipython:: python
            :okwarning:
            :suppress:

            model.fit(data, X = ["density", "sulphates"])

        Plots highlighting the different
        clusters can be easily drawn using:

        .. code-block:: python

            model.plot()

        .. ipython:: python
            :suppress:
            :okwarning:

            vo.set_option("plotting_lib", "plotly")
            fig = model.plot(width = 600)
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_clustering_plot_fun.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_clustering_plot_fun.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        vdf = VastFrame(self.input_relation)
        kwargs = {
            "columns": self.X,
            "max_nb_points": max_nb_points,
            "chart": chart,
            **style_kwargs,
        }
        if self._model_subcategory == "ANOMALY_DETECTION":
            fun = vdf.scatter
            name = "anomaly_score"
            kwargs["cmap_col"] = name
        else:
            fun = vdf.scatter
            name = "cluster"
            kwargs["by"] = name
            kwargs["max_cardinality"] = 100
        self.predict(vdf, name=name)
        return fun(**kwargs)


"""
KMeans Algorithms & Extensions.
"""


class KMeans(Clustering):
    """
    Creates an ``KMeans`` object
    using SKLEARN for training and
    the scalability of VASTDB for
    the inferences.

    Parameters
    ----------
    name: str, optional
        Name of the model. The model
        is stored in the database.
    overwrite_model: bool, optional
        If set to ``True``, training a
        model with the same name as an
        existing model overwrites the
        existing model.
    ``**kwargs``: SKLEARN model parameters.

    Attributes
    ----------
    Many attributes are created
    during the fitting phase.

    ``clusters_``: numpy.array
        Cluster centers.
    ``p_``: int
        The ``p`` of the ``p``-distances.
    ``between_clusters_ss_``: float
        The between-cluster sum of squares (BSS) measures
        the dispersion between different clusters and is
        an important metric in evaluating the effectiveness
        of a clustering algorithm.
    ``total_ss_``: float
        The total sum of squares (TSS) is used to assess
        the total dispersion of data points from the overall
        mean, providing a basis for evaluating the clustering
        algorithm's performance.
    ``total_within_clusters_ss_``: float
        The within-cluster sum of squares (WSS) gauges the
        dispersion of data points within individual clusters
        in a clustering analysis. It reflects the compactness
        of clusters and is instrumental in evaluating the
        homogeneity of the clusters produced by the algorithm.
    ``elbow_score_``: float
        The elbow score. It helps identify the optimal number
        of clusters by observing the point where the rate of
        WSS reduction slows down, resembling the bend or
        'elbow' in the plot, indicative of an optimal clustering
        solution. The bigger the better.
    ``converged_``: boolean
        True if the model converged.

    .. note::

        All attributes can be accessed using the
        :py:meth:`~vastorbit.machine_learning.vast.cluster.Clustering.get_attributes`
        method.

    Examples
    --------

    The following examples provide a
    basic understanding of usage.
    For more detailed examples, please
    refer to the :ref:`user_guide.machine_learning`
    or the :ref:`examples`
    section on the website.

    Load data for machine learning
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    We import :py:mod:`vastorbit`:

    .. ipython:: python

        import vastorbit as vo

    .. hint::

        By assigning an alias to :py:mod:`vastorbit`,
        we mitigate the risk of code collisions with
        other libraries. This precaution is necessary
        because vastorbit uses commonly known function
        names like "average" and "median", which can
        potentially lead to naming conflicts. The use
        of an alias ensures that the functions from
        :py:mod:`vastorbit` are used as intended
        without interfering with functions from other
        libraries.

    For this example, we will
    use the winequality dataset.

    .. code-block:: python

        import vastorbit.datasets as vod

        data = vod.load_winequality()

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

    .. note::

        vastorbit offers a wide range of sample
        datasets that are ideal for training
        and testing purposes. You can explore
        the full list of available datasets in
        the :ref:`api.datasets`, which provides
        detailed information on each dataset and
        how to use them effectively. These datasets
        are invaluable resources for honing your
        data analysis and machine learning skills
        within the vastorbit environment.

    .. ipython:: python
        :suppress:

        import vastorbit.datasets as vod
        data = vod.load_winequality()

    Model Initialization
    ^^^^^^^^^^^^^^^^^^^^^

    First we import the
    :py:class:`~vastorbit.machine_learning.vast.cluster.KMeans`
    model:

    .. code-block::

        from vastorbit.machine_learning.vast import KMeans

    .. ipython:: python
        :suppress:

        from vastorbit.machine_learning.vast import KMeans

    Then we can create the model:

    .. ipython:: python
        :okwarning:

        model = KMeans(
            n_clusters = 8,
            init = "k-means++",
            max_iter = 300,
            tol = 1e-4,
        )

    .. important::

        The model name is crucial for the model
        management system and versioning. It's
        highly recommended to provide a name if
        you plan to reuse the model later.

    Model Training
    ^^^^^^^^^^^^^^^

    We can now fit the model:

    .. ipython:: python
        :okwarning:

        model.fit(data, X = ["density", "sulphates"])

    .. important::

        To train a model, you can directly use the
        :py:class:`~VastFrame` or the name of the
        relation stored in the database. The test
        set is optional and is only used to compute
        the test metrics. In :py:mod:`vastorbit`, we
        don't work using ``X`` matrices and ``y``
        vectors. Instead, we work directly with lists
        of predictors and the response name.

    .. hint::

        For clustering and anomaly detection, the
        use of predictors is optional. In such cases,
        all available predictors are considered, which
        can include solely numerical variables or a
        combination of numerical and categorical variables,
        depending on the model's capabilities.

    Metrics
    ^^^^^^^^

    You can also find the cluster positions by:

    .. ipython:: python
        :okwarning:

        model.clusters_

    To evaluate the model, various attributes are computed, such as
    the between sum of squares, the total within clusters sum of
    squares, and the total sum of squares.

    .. ipython:: python
        :okwarning:

        model.between_clusters_ss_
        model.total_within_clusters_ss_
        model.total_ss_

    Some other useful attributes can be used to evaluate the model,
    like the Elbow Score (the bigger it is, the better it is).

    .. ipython:: python
        :okwarning:

        model.elbow_score_

    Prediction
    ^^^^^^^^^^^

    Predicting or ranking the dataset is straight-forward:

    .. ipython:: python
        :suppress:
        :okwarning:
        :okexcept:

        result = model.predict(data, ["density", "sulphates"], name = "Cluster IDs")
        html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_prediction.html", "w")
        html_file.write(result._repr_html_())
        html_file.close()

    .. code-block:: python

        model.predict(data, ["density", "sulphates"], name = "Cluster IDs")

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_prediction.html

    As shown above, a new column has been created, containing
    the clusters.

    .. hint::
        The name of the new column is optional. If not provided,
        it is randomly assigned.

    Plots - Cluster Plot
    ^^^^^^^^^^^^^^^^^^^^^

    Plots highlighting the different clusters can be easily drawn using:

    .. code-block:: python

        model.plot()

    .. ipython:: python
        :suppress:
        :okwarning:

        vo.set_option("plotting_lib", "plotly")
        fig = model.plot(width = 600)
        fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_plot.html")

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_plot.html

    Plots - Voronoi
    ^^^^^^^^^^^^^^^^

    :py:class:`~vastorbit.machine_learning.vast.cluster.KMeans`
    models can be visualized by
    drawing their voronoi plots.
    For more examples, check out
    :ref:`chart_gallery.voronoi_plot`.

    .. code-block:: python

        model.plot_voronoi()

    .. ipython:: python
        :suppress:
        :okwarning:

        vo.set_option("plotting_lib", "plotly")
        fig = model.plot_voronoi(width = 600)
        fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_plot_voronoi.html")

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_plot_voronoi.html

    Plots - Contour
    ^^^^^^^^^^^^^^^^

    In order to understand the parameter space, we can also look
    at the contour plots:

    .. code-block:: python

        model.contour()

    .. ipython:: python
        :suppress:
        :okwarning:

        fig = model.contour(width = 600)
        fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_contour.html")

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_contour.html

    .. note::

        Machine learning models with two predictors can usually benefit
        from their own contour plot. This visual representation aids in
        exploring predictions and gaining a deeper understanding of how
        these models perform in different scenarios. Please refer to
        :ref:`chart_gallery.contour` for more examples.

    Parameter Modification
    ^^^^^^^^^^^^^^^^^^^^^^^

    In order to see the parameters:

    .. ipython:: python

        model.get_params()

    And to manually change some of the parameters:

    .. ipython:: python

        model.set_params({'n_clusters': 5})

    Model Exporting
    ^^^^^^^^^^^^^^^^

    **To Memmodel**

    .. code-block:: python

        model.to_memmodel()

    .. note::

        ``MemModel`` objects serve as in-memory
        representations of machine learning models.
        They can be used for both in-database and
        in-memory prediction tasks. These objects
        can be pickled in the same way that you
        would pickle a ``scikit-learn`` model.

    The preceding methods for exporting the
    model use ``MemModel``, and it is recommended
    to use ``MemModel`` directly.

    **To SQL**

    You can get the SQL query
    equivalent of the ``KMeans``
    model by:

    .. ipython:: python

        model.to_sql()

    .. note::

        This SQL query can be
        directly used in any
        database.

    **Deploy SQL**

    To get the SQL query which uses
    VAST functions use below:

    .. ipython:: python

        model.deploySQL()

    **To Python**

    To obtain the prediction function in
    Python syntax, use the following code:

    .. ipython:: python

        X = [[0.9, 0.5]]
        model.to_python()(X)

    .. hint::

        The
        :py:meth:`~vastorbit.machine_learning.vast.tree.KMeans.to_python`
        method is used to retrieve the anomaly score.
        For specific details on how to
        use this method for different
        model types, refer to the relevant
        documentation for each model.
    """

    # Properties.

    @property
    def _model_subcategory(self) -> Literal["CLUSTERING"]:
        return "CLUSTERING"

    @property
    def _model_type(self) -> Literal["KMeans"]:
        return "KMeans"

    @property
    def _attributes(self) -> list[str]:
        return [
            "clusters_",
            "p_",
            "between_clusters_ss_",
            "total_ss_",
            "total_within_clusters_ss_",
            "elbow_score_",
            "converged_",
        ]

    @property
    def _sklearn_model(self) -> Literal[sklearn.cluster.KMeans]:
        return sklearn.cluster.KMeans

    # Attributes Methods.

    def _compute_attributes(self) -> None:
        """
        Computes the model's attributes.
        """
        self.clusters_ = self._model.cluster_centers_
        self.p_ = 2
        self._compute_metrics()

    def _compute_metrics(self) -> None:
        """
        Computes the KMeans metrics.
        """
        self.total_within_clusters_ss_ = self._model.inertia_

        # 2. Total Sum of Squares (variance of entire dataset)
        X_centered = self._X - self._X.mean(axis=0)
        self.total_ss_ = np.sum(X_centered**2)

        # 3. Between-Cluster Sum of Squares
        self.between_clusters_ss_ = self.total_ss_ - self.total_within_clusters_ss_

        # 4. Elbow Score (ratio)
        self.elbow_score_ = self.between_clusters_ss_ / self.total_ss_

        # 5. Converged (sklearn always converges or hits max_iter)
        self.converged_ = self._model.n_iter_ < self._model.max_iter

    # I/O Methods.

    def to_memmodel(self) -> mm.KMeans:
        """
        Converts the model to an InMemory object
        that can be used for different types of
        predictions.

        Returns
        -------
        InMemoryModel
            Representation of the model.

        Examples
        --------
        If we consider that you've built a model named
        ``model``, then it is easy to export it using
        the following syntax.

        .. code-block:: python

            model.to_memmodel()

        .. note::

            ``MemModel`` objects serve as in-memory
            representations of machine learning models.
            They can be used for both in-database and
            in-memory prediction tasks. These objects
            can be pickled in the same way that you
            would pickle a ``scikit-learn`` model.

        .. note::

            Look at
            :py:class:`~vastorbit.machine_learning.memmodel.cluster.KMeans`
            for more information.
        """
        return mm.KMeans(
            self.clusters_,
            self.p_,
        )

    # Plotting Methods.

    def plot_voronoi(
        self,
        max_nb_points: int = 50,
        plot_crosses: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> PlottingObject:
        """
        Draws the Voronoi
        Graph of the model.

        Parameters
        ----------
        max_nb_points: int, optional
            Maximum number of
            points to display.
        plot_crosses: bool, optional
            If set to ``True``, the
            centers are represented
            by white crosses.
        chart: PlottingObject, optional
            The chart object
            to plot on.
        ``**style_kwargs``
            Any optional parameter to
            pass to the Plotting functions.

        Returns
        -------
        obj
            Plotting Object.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import KMeans

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = KMeans(
                n_clusters = 8,
                init = "k-means++",
                max_iter = 300,
                tol = 1e-4,
            )

        We can then fit the model:

        .. code-block:: python

            model.fit(data, X = ["density", "sulphates"])

        .. ipython:: python
            :okwarning:
            :suppress:

            model.fit(data, X = ["density", "sulphates"])

        Models can be visualized by drawing
        their voronoi plots.

        .. code-block:: python

            model.plot_voronoi()

        .. ipython:: python
            :suppress:
            :okwarning:

            vo.set_option("plotting_lib", "plotly")
            fig = model.plot_voronoi(width = 600)
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_plot_voronoi.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_kmeans_plot_voronoi.html

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.vast.cluster.KMeans`
            for more information about the
            different methods and usages.
        """
        if len(self.X) == 2:
            vo_plt, kwargs = self.get_plotting_lib(
                class_name="VoronoiPlot",
                chart=chart,
                matplotlib_kwargs={"plot_crosses": plot_crosses},
                style_kwargs=style_kwargs,
            )
            return vo_plt.VoronoiPlot(
                vdf=VastFrame(self.input_relation),
                columns=self.X,
                max_nb_points=max_nb_points,
                misc_data={"clusters": self.clusters_},
            ).draw(**kwargs)
        else:
            raise Exception("Voronoi Plots are only available in 2D")


class BisectingKMeans(KMeans, Tree):
    """
    Creates   a  BisectingKMeans  object  using   the
    VAST   bisecting  k-means  algorithm.  k-means
    clustering is a method of vector quantization,
    originally  from  signal processing, that aims to
    partition n observations into k  clusters. Each
    observation  belongs  to the  cluster  with  the
    nearest  mean   (cluster centers  or  cluster
    centroid),  which serves  as a  prototype  of the
    cluster.  This  results  in a partitioning of the
    data space into  Voronoi cells. Bisecting k-means
    combines k-means  and hierarchical clustering.

    Parameters
    ----------
    name: str, optional
        Name of the model.  The  model is stored in
        the database.
    overwrite_model: bool, optional
        If set to ``True``, training a
        model with the same name as an
        existing model overwrites the
        existing model.
    ``**kwargs``: SKLEARN model parameters.

    Attributes
    ----------
    Many attributes are created
    during the fitting phase.

    ``cluster_centers_``, ``labels_``, ``inertia_``, ``n_features_in_``, ``feature_names_in_``

    .. note::

        All attributes can be accessed using the
        :py:meth:`~vastorbit.machine_learning.vast.cluster.Clustering.get_attributes`
        method.

    Examples
    --------

    The following examples provide a
    basic understanding of usage.
    For more detailed examples, please
    refer to the :ref:`user_guide.machine_learning`
    or the :ref:`examples`
    section on the website.

    Load data for machine learning
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    We import :py:mod:`vastorbit`:

    .. ipython:: python

        import vastorbit as vo

    .. hint::

        By assigning an alias to :py:mod:`vastorbit`,
        we mitigate the risk of code collisions with
        other libraries. This precaution is necessary
        because vastorbit uses commonly known function
        names like "average" and "median", which can
        potentially lead to naming conflicts. The use
        of an alias ensures that the functions from
        :py:mod:`vastorbit` are used as intended
        without interfering with functions from other
        libraries.

    For this example, we will
    use the winequality dataset.

    .. code-block:: python

        import vastorbit.datasets as vod

        data = vod.load_winequality()

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

    .. note::

        vastorbit offers a wide range of sample
        datasets that are ideal for training
        and testing purposes. You can explore
        the full list of available datasets in
        the :ref:`api.datasets`, which provides
        detailed information on each dataset and
        how to use them effectively. These datasets
        are invaluable resources for honing your
        data analysis and machine learning skills
        within the vastorbit environment.

    .. ipython:: python
        :suppress:

        import vastorbit.datasets as vod
        data = vod.load_winequality()

    Model Initialization
    ^^^^^^^^^^^^^^^^^^^^^

    First we import the ``BisectingKMeans`` model:

    .. code-block::

        from vastorbit.machine_learning.vast import BisectingKMeans

    .. ipython:: python
        :suppress:
        :okwarning:

        from vastorbit.machine_learning.vast import BisectingKMeans

    Then we can create the model:

    .. ipython:: python
        :okwarning:

        model = BisectingKMeans(
            n_clusters = 8,
            algorithm = 'lloyd',
            bisecting_strategy = "biggest_inertia",
            max_iter = 300,
            tol = 1e-4,
        )

    .. important::

        The model name is crucial for the model
        management system and versioning. It's
        highly recommended to provide a name if
        you plan to reuse the model later.

    Model Training
    ^^^^^^^^^^^^^^^

    We can now fit the model:

    .. ipython:: python
        :okwarning:

        model.fit(data, X = ["density", "sulphates"])

    .. important::

        To train a model, you can directly use the
        :py:class:`~VastFrame` or the name of the
        relation stored in the database. The test
        set is optional and is only used to compute
        the test metrics. In :py:mod:`vastorbit`, we
        don't work using ``X`` matrices and ``y``
        vectors. Instead, we work directly with lists
        of predictors and the response name.

    .. hint::

        For clustering and anomaly detection, the
        use of predictors is optional. In such cases,
        all available predictors are considered, which
        can include solely numerical variables or a
        combination of numerical and categorical variables,
        depending on the model's capabilities.

    Metrics
    ^^^^^^^^

    You can also find the cluster positions by:

    .. ipython:: python
        :okwarning:

        model.clusters_

    In order to get the size of each cluster, you can use:

    .. ipython:: python
        :okwarning:

        model.cluster_size_

    To evaluate the model, various attributes are computed, such as
    the between sum of squares, the total within clusters sum of
    squares, and the total sum of squares.

    .. ipython:: python
        :okwarning:

        model.between_clusters_ss_
        model.total_within_clusters_ss_
        model.total_ss_

    You also have access to the sum of squares of each cluster.

    .. ipython:: python
        :okwarning:

        model.cluster_i_ss_

    Some other useful attributes can be used to evaluate the model,
    like the Elbow Score (the bigger it is, the better it is).

    .. ipython:: python
        :okwarning:

        model.elbow_score_

    Prediction
    ^^^^^^^^^^^

    Predicting or ranking the dataset is straight-forward:

    .. ipython:: python
        :suppress:
        :okwarning:
        :okexcept:

        result = model.predict(data, ["density", "sulphates"])
        html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_bisect_km_prediction.html", "w")
        html_file.write(result._repr_html_())
        html_file.close()

    .. code-block:: python

        model.predict(data, ["density", "sulphates"])

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_bisect_km_prediction.html

    As shown above, a new column has been created, containing
    the bisected clusters.

    Plots - Cluster Plot
    ^^^^^^^^^^^^^^^^^^^^^

    Plots highlighting the different clusters can be easily drawn using:

    .. code-block:: python

        model.plot()

    .. ipython:: python
        :suppress:
        :okwarning:

        vo.set_option("plotting_lib", "plotly")
        fig = model.plot(width = 600)
        fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_bisect_km_plot.html")

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_bisect_km_plot.html

    Plots - Tree
    ^^^^^^^^^^^^^

    Tree models can be visualized by drawing their tree plots.
    For more examples, check out :ref:`chart_gallery.tree`.

    .. code-block:: python

        model.plot_tree()

    .. ipython:: python
        :suppress:
        :okwarning:

        res = model.plot_tree()
        res.render(filename='figures/machine_learning_VAST_tree_bisect_km_', format='png')


    .. image:: /../figures/machine_learning_VAST_tree_bisect_km_.png

    .. note::

        The above example may not render
        properly in the doc because of the
        huge size of the tree. But it should
        render nicely in jupyter environment.

    In order to plot graph using
    `graphviz <https://graphviz.org/>`__
    separately, you can extract the
    graphviz DOT file code as follows:

    .. ipython:: python
        :okwarning:

        model.to_graphviz()

    This string can then be copied into a DOT file which can be
    parsed by graphviz.

    Plots - Contour
    ^^^^^^^^^^^^^^^^

    In order to understand the parameter space, we can also look
    at the contour plots:

    .. code-block:: python

        model.contour()

    .. ipython:: python
        :suppress:

        fig = model.contour(width = 600)
        fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_bisect_km_contour.html")

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_bisect_km_contour.html

    .. note::

        Machine learning models with two predictors can usually benefit
        from their own contour plot. This visual representation aids in
        exploring predictions and gaining a deeper understanding of how
        these models perform in different scenarios. Please refer to
        :ref:`chart_gallery.contour` for more examples.

    Parameter Modification
    ^^^^^^^^^^^^^^^^^^^^^^^

    In order to see the parameters:

    .. ipython:: python
        :okwarning:

        model.get_params()

    And to manually change some of the parameters:

    .. ipython:: python
        :okwarning:

        model.set_params({'n_clusters': 5})

    Model Exporting
    ^^^^^^^^^^^^^^^^

    **To Memmodel**

    .. code-block:: python

        model.to_memmodel()

    .. note::

        ``MemModel`` objects serve as in-memory
        representations of machine learning models.
        They can be used for both in-database and
        in-memory prediction tasks. These objects
        can be pickled in the same way that you
        would pickle a ``scikit-learn`` model.

    The preceding methods for exporting the
    model use ``MemModel``, and it is recommended
    to use ``MemModel`` directly.

    **To SQL**

    You can get the SQL query equivalent of the GB model by:

    .. ipython:: python
        :okwarning:

        model.to_sql()

    .. note::

        This SQL query can be
        directly used in any
        database.

    **Deploy SQL**

    To get the SQL query which uses
    VAST functions use below:

    .. ipython:: python

        model.deploySQL()

    **To Python**

    To obtain the prediction function in
    Python syntax, use the following code:

    .. ipython:: python

        X = [[0.9, 0.5]]
        model.to_python()(X)

    .. hint::

        The
        :py:meth:`~vastorbit.machine_learning.vast.tree.BisectingKMeans.to_python`
        method is used to retrieve the anomaly score.
        For specific details on how to
        use this method for different
        model types, refer to the relevant
        documentation for each model.
    """

    # Properties.

    @property
    def _model_subcategory(self) -> Literal["CLUSTERING"]:
        return "CLUSTERING"

    @property
    def _model_type(self) -> Literal["BisectingKMeans"]:
        return "BisectingKMeans"

    @property
    def _sklearn_model(self) -> Literal[sklearn.cluster.BisectingKMeans]:
        return sklearn.cluster.BisectingKMeans

    @property
    def _attributes(self) -> list[str]:
        return [
            "tree_",
            "clusters_",
            "children_left_",
            "children_right_",
            "cluster_size_",
            "cluster_score_",
            "p_",
            "between_clusters_ss_",
            "total_ss_",
            "total_within_clusters_ss_",
            "elbow_score_",
            "cluster_i_ss_",
        ]

    # Attributes Methods.

    def _compute_attributes(self) -> None:
        """
        Computes the model's attributes.
        """
        labels = self._model.labels_
        n_clusters = self._model.n_clusters

        # 2. Total / Between Sum of Squares (computed from the flat clustering)
        self.total_within_clusters_ss_ = self._model.inertia_
        X_centered = self._X - self._X.mean(axis=0)
        self.total_ss_ = np.sum(X_centered**2)
        self.between_clusters_ss_ = self.total_ss_ - self.total_within_clusters_ss_
        self.elbow_score_ = self.between_clusters_ss_ / self.total_ss_
        self.p_ = 2

        # 3. Tree structure.
        # scikit-learn does not expose the bisecting hierarchy as flat arrays,
        # but it keeps it in the private ``_bisecting_tree``. The memmodel
        # (predict_sql / get_tree / to_graphviz) needs ``children_left_`` /
        # ``children_right_`` arrays indexed by node id (root = node 0, ``None``
        # at leaves) and a ``clusters_`` array holding the centroid of *every*
        # node, internal nodes included. Walk the tree to rebuild them; without
        # this the children are ``None`` and the memmodel raises
        # "array is 0-dimensional" / "len() of unsized object".
        bisecting_tree = getattr(self._model, "_bisecting_tree", None)
        if bisecting_tree is not None:
            centers, children_left, children_right, leaf_label = [], [], [], []

            def _add_node(node):
                node_id = len(centers)
                centers.append(np.asarray(node.center, dtype=float))
                children_left.append(None)
                children_right.append(None)
                leaf_label.append(getattr(node, "label", None))
                return node_id

            root_id = _add_node(bisecting_tree)
            queue = [(bisecting_tree, root_id)]
            while queue:
                node, node_id = queue.pop(0)
                left = getattr(node, "left", None)
                right = getattr(node, "right", None)
                if left is not None and right is not None:
                    left_id = _add_node(left)
                    right_id = _add_node(right)
                    children_left[node_id] = left_id
                    children_right[node_id] = right_id
                    leaf_label[node_id] = None
                    queue += [(left, left_id), (right, right_id)]

            n_nodes = len(centers)
            self.clusters_ = np.array(centers)
            self.children_left_ = np.array(children_left, dtype=object)
            self.children_right_ = np.array(children_right, dtype=object)

            # Per-node size and within-cluster SS, indexed by node id. Leaves take
            # their own cluster value; internal nodes aggregate their subtree so
            # get_tree()/to_graphviz() can label every node.
            size = np.zeros(n_nodes)
            within_ss = np.zeros(n_nodes)
            for node_id in range(n_nodes):
                label = leaf_label[node_id]
                if label is not None:
                    mask = labels == label
                    size[node_id] = int(np.sum(mask))
                    within_ss[node_id] = np.sum((self._X[mask] - centers[node_id]) ** 2)
            for node_id in range(n_nodes - 1, -1, -1):
                if children_left[node_id] is not None:
                    left_id = children_left[node_id]
                    right_id = children_right[node_id]
                    size[node_id] = size[left_id] + size[right_id]
                    within_ss[node_id] = within_ss[left_id] + within_ss[right_id]
            self.cluster_size_ = size.astype(int)
            self.cluster_i_ss_ = within_ss
            self.cluster_score_ = within_ss / self.total_within_clusters_ss_
        else:
            # Defensive fallback: keep the flat clustering if the private tree
            # is unavailable (older/newer scikit-learn).
            self.clusters_ = self._model.cluster_centers_
            self.children_left_ = None
            self.children_right_ = None
            _unique_labels, counts = np.unique(labels, return_counts=True)
            self.cluster_size_ = counts
            self.cluster_i_ss_ = np.array(
                [
                    (
                        np.sum(
                            (self._X[labels == i] - self._model.cluster_centers_[i])
                            ** 2
                        )
                        if np.sum(labels == i) > 0
                        else 0.0
                    )
                    for i in range(n_clusters)
                ]
            )
            self.cluster_score_ = self.cluster_i_ss_ / self.total_within_clusters_ss_

    # I/O Methods.

    def to_memmodel(self) -> mm.BisectingKMeans:
        """
        Converts the model to an InMemory object
        that can be used for different types of
        predictions.

        Returns
        -------
        InMemoryModel
            Representation of the model.

        Examples
        --------
        If we consider that you've built a model named
        ``model``, then it is easy to export it using
        the following syntax.

        .. code-block:: python

            model.to_memmodel()

        .. note::

            ``MemModel`` objects serve as in-memory
            representations of machine learning models.
            They can be used for both in-database and
            in-memory prediction tasks. These objects
            can be pickled in the same way that you
            would pickle a ``scikit-learn`` model.

        .. note::

            Look at
            :py:class:`~vastorbit.machine_learning.memmodel.cluster.BisectingKMeans`
            for more information.
        """
        return mm.BisectingKMeans(
            self.clusters_,
            self.children_left_,
            self.children_right_,
            self.cluster_size_,
            self.cluster_score_,
            self.p_,
        )

    # Trees Representation Methods.

    def get_tree(self) -> TableSample:
        """
        Returns a table containing
        information about the BK-tree.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import BisectingKMeans

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = BisectingKMeans(
                n_clusters = 8,
                algorithm = 'lloyd',
                bisecting_strategy = "biggest_inertia",
                max_iter = 300,
                tol = 1e-4,
            )

        We can then fit the model:

        .. code-block:: python

            model.fit(data, X = ["density", "sulphates"])

        .. ipython:: python
            :okwarning:
            :suppress:

            model.fit(data, X = ["density", "sulphates"])

        We can get all the information of
        the tree using:

        .. ipython:: python
            :suppress:
            :okexcept:

            result = model.get_tree()
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_get_tree.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.get_tree()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_get_tree.html

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.vast.cluster.BisectingKMeans`
            for more information about the
            different methods and usages.
        """
        return self.tree_

    def to_graphviz(
        self,
        round_score: int = 2,
        percent: bool = False,
        vertical: bool = True,
        node_style: dict | None = None,
        edge_style: Optional[dict] = None,
        leaf_style: Optional[dict] = None,
    ) -> str:
        """
        Returns the code for a Graphviz tree.

        Parameters
        ----------
        round_score: int, optional
            The number of  decimals to round the  node's
            score to. Zero rounds to an integer.
        percent: bool, optional
            If set to True, the scores are  returned  as
            a percent.
        vertical: bool, optional
            If set to True,  the  function  generates  a
            vertical tree.
        node_style: dict, optional
            Dictionary of options to customize each  node
            of the tree.
            For a list of options, see the:
            `Graphviz API <https://graphviz.org/doc/info/attrs.html>`_
        edge_style: dict, optional
            Dictionary of options to customize each arrow
            of the tree.
            For a list of options, see the:
            `Graphviz API <https://graphviz.org/doc/info/attrs.html>`_
        leaf_style: dict, optional
            Dictionary of options to customize each  leaf
            of the tree.
            For a list of options, see the:
            `Graphviz API <https://graphviz.org/doc/info/attrs.html>`_

        Returns
        -------
        str
            Graphviz code.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import BisectingKMeans

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = BisectingKMeans(
                n_clusters = 8,
                algorithm = 'lloyd',
                bisecting_strategy = "biggest_inertia",
                max_iter = 300,
                tol = 1e-4,
            )

        We can then fit the model:

        .. code-block:: python

            model.fit(data, X = ["density", "sulphates"])

        .. ipython:: python
            :okwarning:
            :suppress:

            model.fit(data, X = ["density", "sulphates"])

        We can then get the code for
        a graphviz tree:

        .. ipython:: python

            model.to_graphviz()

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.vast.cluster.BisectingKMeans`
            for more information about the
            different methods and usages.
        """
        if node_style is None:
            node_style = {"shape": "none"}
        return self.to_memmodel().to_graphviz(
            round_score=round_score,
            percent=percent,
            vertical=vertical,
            node_style=node_style,
            edge_style=edge_style,
            leaf_style=leaf_style,
        )

    def plot_tree(
        self,
        pic_path: Optional[str] = None,
        *args,
        **kwargs,
    ) -> "Source":
        """
        Draws the input tree.
        Requires the graphviz module.

        Parameters
        ----------
        pic_path: str, optional
            Absolute path to save
            the image of the tree.
        *args, ``**kwargs``: Any, optional
            Arguments to pass to the
            ``to_graphviz`` method.

        Returns
        -------
        graphviz.Source
            graphviz object.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import BisectingKMeans

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = BisectingKMeans(
                n_clusters = 8,
                algorithm = 'lloyd',
                bisecting_strategy = "biggest_inertia",
                max_iter = 300,
                tol = 1e-4,
            )

        We can then fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(data, X = ["density", "sulphates"])

        We can plot the tree conveniently:

        .. ipython:: python
            :suppress:
            :okwarning:

            res = model.plot_tree()
            res.render(filename='figures/machine_learning_VAST_cluster_BKMeans_plot_tree', format='png')


        .. image:: /../figures/machine_learning_VAST_cluster_BKMeans_plot_tree.png

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.vast.cluster.BisectingKMeans`
            for more information about the
            different methods and usages.
        """
        return self.to_memmodel().plot_tree(
            pic_path=pic_path,
            *args,
            **kwargs,
        )


"""
Algorithms used for clustering.
"""


class DBSCAN(VASTModel):
    """
    [Beta Version]
    Creates a DBSCAN object by  using the DBSCAN algorithm
    as defined by Martin  Ester,  Hans-Peter Kriegel, Jörg
    Sander, and Xiaowei Xu.  This  object uses pure SQL to
    compute the distances and neighbors, and uses Python to
    compute the cluster propagation (non-scalable phase).

    .. warning::

        This   algorithm   uses  a   CROSS  JOIN
        during   computation  and  is  therefore
        computationally  expensive at  O(n * n),
        where n is the total number of elements.
        This  algorithm indexes elements of  the
        table in order to be optimal  (the CROSS
        JOIN will happen only with IDs which are
        integers).
        Since  DBSCAN uses  the  p-distance, it
        is highly sensitive  to unnormalized data.
        However,  DBSCAN is robust to outliers and
        can find non-linear clusters. It is a very
        powerful algorithm for outlier  detection
        and clustering. A table is created at
        the end of the learning phase.

    .. important::

        This algorithm is not VAST
        Native and relies solely on SQL
        for attribute computation. While
        this model does not take advantage
        of the benefits provided by a model
        management system, including versioning
        and tracking, the SQL code it generates
        can still be used to create a pipeline.

    Parameters
    ----------
    name: str, optional
        Name  of the model.  This is  not a  built-in
        model, so this name is  used to build the
        final table.
    overwrite_model: bool, optional
        If set to ``True``, training a
        model with the same name as an
        existing model overwrites the
        existing model.
    eps: float, optional
        The radius of a  neighborhood with respect to
        some point.
    min_samples: int, optional
        Minimum number  of points required to  form a
        dense region.
    p: int, optional
        The p of the p-distance (distance metric used
        during the model computation).

    Attributes
    ----------
    Many attributes are created
    during the fitting phase.

    ``n_clusters_``: int
        Number of clusters.
    ``p_``: int
        The ``p`` of the ``p``-distances.
    ``n_noise_``: int
        Number of outliers.

    .. note::

        All attributes can be accessed using the
        :py:meth:`~vastorbit.machine_learning.vast.base.VASTModel.get_attributes`
        method.

    Examples
    --------

    The following examples provide a
    basic understanding of usage.
    For more detailed examples, please
    refer to the :ref:`user_guide.machine_learning`
    or the :ref:`examples`
    section on the website.

    Load data for machine learning
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    We import :py:mod:`vastorbit`:

    .. ipython:: python

        import vastorbit as vo

    .. hint::

        By assigning an alias to :py:mod:`vastorbit`,
        we mitigate the risk of code collisions with
        other libraries. This precaution is necessary
        because vastorbit uses commonly known function
        names like "average" and "median", which can
        potentially lead to naming conflicts. The use
        of an alias ensures that the functions from
        :py:mod:`vastorbit` are used as intended
        without interfering with functions from other
        libraries.

    For this example, we will create a small dataset.

    .. ipython:: python

        data = vo.VastFrame({"col":[1.2, 1.1, 1.3, 1.5, 2, 2.2, 1.09, 0.9, 100, 102]})

    .. note::

        vastorbit offers a wide range of sample
        datasets that are ideal for training
        and testing purposes. You can explore
        the full list of available datasets in
        the :ref:`api.datasets`, which provides
        detailed information on each dataset and
        how to use them effectively. These datasets
        are invaluable resources for honing your
        data analysis and machine learning skills
        within the vastorbit environment.

    Model Initialization
    ^^^^^^^^^^^^^^^^^^^^^

    First we import the
    :py:class:`~vastorbit.machine_learning.vast.cluster.DBSCAN`
    model:

    .. code-block::

        from vastorbit.machine_learning.vast import DBSCAN

    .. ipython:: python
        :suppress:

        from vastorbit.machine_learning.vast import DBSCAN

    Then we can create the model:

    .. ipython:: python
        :okwarning:

        model = DBSCAN(
            eps = 0.5,
            min_samples = 2,
            p = 2,
        )

    .. important::

        As this model is not native, it solely relies on SQL statements to
        compute various attributes, storing them within the object. No data
        is saved in the database.

    Model Training
    ^^^^^^^^^^^^^^^

    We can now fit the model:

    .. ipython:: python
        :okwarning:

        model.fit(data, X = ["col"])

    .. important::

        To train a model, you can directly
        use the :py:class:`~VastFrame` or
        the name of the relation stored in
        the database.

    .. hint::

        For clustering and anomaly detection, the
        use of predictors is optional. In such cases,
        all available predictors are considered, which
        can include solely numerical variables or a
        combination of numerical and categorical variables,
        depending on the model's capabilities.

    .. important::

        As this model is not native, it solely relies on SQL statements to
        compute various attributes, storing them within the object. No data
        is saved in the database.

    Prediction
    ^^^^^^^^^^^

    Predicting or ranking the dataset is straight-forward:

    .. ipython:: python
        :suppress:
        :okexcept:

        result = model.predict()
        html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_dbscan_prediction.html", "w")
        html_file.write(result._repr_html_())
        html_file.close()

    .. code-block:: python

        model.predict()

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_dbscan_prediction.html

    As shown above, a new column has been created, containing
    the clusters.

    .. hint::
        The name of the new column is optional. If not provided,
        it is randomly assigned.

    Parameter Modification
    ^^^^^^^^^^^^^^^^^^^^^^^

    In order to see the parameters:

    .. ipython:: python

        model.get_params()

    And to manually change some of the parameters:

    .. ipython:: python

        model.set_params({'min_samples': 5})

    Model Register
    ^^^^^^^^^^^^^^

    As this model is not native, it does not
    support model management and versioning.
    However, it is possible to use the SQL
    code it generates for deployment.
    """

    # Properties.

    @property
    def _is_native(self) -> Literal[False]:
        return False

    @property
    def _fit_sql(self) -> Literal[""]:
        return ""

    @property
    def _predict_sql(self) -> Literal[""]:
        return ""

    @property
    def _model_category(self) -> Literal["UNSUPERVISED"]:
        return "UNSUPERVISED"

    @property
    def _model_subcategory(self) -> Literal["CLUSTERING"]:
        return "CLUSTERING"

    @property
    def _model_type(self) -> Literal["DBSCAN"]:
        return "DBSCAN"

    @property
    def _attributes(self) -> list[str]:
        return ["n_clusters_", "n_noise_", "p_"]

    # System & Special Methods.

    @save_vastorbit_logs
    def __init__(
        self,
        name: str = None,
        overwrite_model: bool = False,
        eps: float = 0.5,
        min_samples: int = 5,
        p: int = 2,
    ) -> None:
        super().__init__(name, overwrite_model)
        self.parameters = {"eps": eps, "min_samples": min_samples, "p": p}

    def drop(self) -> bool:
        """
        Drops the model from
        the VAST database.

        Examples
        --------
        Let's start by importing a model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import DBSCAN

        Then we can initialize the model:

        .. ipython:: python
            :okwarning:

            model = DBSCAN(
                eps = 0.5,
                min_samples = 2,
                p = 2,
            )

        Once the model is initialized
        we can easily drop it:

        .. ipython:: python
            :okwarning:

            model.drop()

        .. note::

            If it returns ``False``, then
            it means that there was no model
            in the first place.

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.vast.cluster.DBSCAN`
            for more information about the
            different methods and usages.
        """
        try:
            _executeSQL(
                query=f"SELECT dbscan_clusters FROM {self.model_name} LIMIT 0;",
                title="Looking if the DBSCAN table exists.",
            )
            return drop(self.model_name, method="table")
        except QueryError:
            return False

    # Model Fitting Method.

    def _is_already_stored(self, raise_error: bool = False) -> bool:
        """
        Checks whether the model's output table already exists in the
        database. DBSCAN materialises its result as a regular table named
        ``model_name``, so existence is resolved against
        ``information_schema.tables``.
        """
        name = self.model_name.replace('"', "")
        parts = name.split(".")
        table = parts[-1]
        if len(parts) >= 3:
            info_relation = f"{parts[-3]}.information_schema.tables"
            schema = parts[-2]
        else:
            info_relation = "information_schema.tables"
            schema = parts[-2] if len(parts) == 2 else None
        where = f"table_name = '{table}'"
        if schema:
            where += f" AND table_schema = '{schema}'"
        result = _executeSQL(
            query=f"""
                SELECT /*+LABEL('learn.cluster.DBSCAN._is_already_stored')*/
                    table_name
                FROM {info_relation}
                WHERE {where}""",
            method="fetchall",
            print_time_sql=False,
        )
        is_stored = len(result) > 0
        if is_stored and raise_error:
            raise NameError(
                f"The model '{self.model_name}' already exists! Use "
                "'overwrite_model = True' to overwrite it, or choose a "
                "different model name."
            )
        return is_stored

    def fit(
        self,
        input_relation: SQLRelation,
        X: Optional[SQLColumns] = None,
        key_columns: Optional[SQLColumns] = None,
        index: Optional[str] = None,
        return_report: bool = False,
    ) -> None:
        """
        Trains the model.

        Parameters
        ----------
        input_relation: SQLRelation
            Training relation.
        X: SQLColumns, optional
            ``list`` of the predictors.
            If empty, all the numerical
            `:py:class:`~VastColumn`
            are used.
        key_columns: SQLColumns, optional
            Columns not used during the
            algorithm computation but
            which are used to create
            the final relation.
        index: str, optional
            Index used to identify each
            row separately. It is highly
            recommanded to have one already
            in the main table to avoid creating
            temporary tables.

        Examples
        --------
        Let's start by importing
        :py:mod:`vastorbit`:

        .. ipython:: python

            import vastorbit as vo

        For this example, we will
        create a small dataset.

        .. ipython:: python

            data = vo.VastFrame({"col":[1.2, 1.1, 1.3, 1.5, 2, 2.2, 1.09, 0.9, 100, 102]})

        Then we import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import DBSCAN

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = DBSCAN(
                eps = 0.5,
                min_samples = 2,
                p = 2,
            )

        Once the model is initialized
        we can fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(data, X = ["col"])

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.vast.cluster.DBSCAN`
            for more information about the
            different methods and usages.
        """
        if self.overwrite_model:
            self.drop()
        else:
            self._is_already_stored(raise_error=True)
        if isinstance(input_relation, VastFrame):
            if isinstance(X, NoneType):
                X = input_relation.numcol()
            input_relation = input_relation.current_relation()
        else:
            if isinstance(X, NoneType):
                X = VastFrame(input_relation).numcol()
        X, key_columns = format_type(X, key_columns, dtype=list)
        X = quote_ident(X)
        self.X = X
        self.key_columns = quote_ident(key_columns)
        self.input_relation = input_relation
        name_main = gen_tmp_name(schema=conf.get_option("temp_schema"), name="main")
        created_main = False
        try:
            if not index:
                index = "id"
                drop(name_main, method="table")
                _executeSQL(
                    query=f"""
                    CREATE TABLE {name_main} AS
                    SELECT /*+LABEL('learn.cluster.DBSCAN.fit')*/
                        ROW_NUMBER() OVER () AS id, 
                        {', '.join(X + key_columns)} 
                    FROM {self.input_relation} 
                    WHERE {' AND '.join([f"{item} IS NOT NULL" for item in X])}""",
                    title="Computing the DBSCAN Table [Step 0]",
                )
                created_main = True
            else:
                _executeSQL(
                    query=f"""
                        SELECT 
                            /*+LABEL('learn.cluster.DBSCAN.fit')*/ 
                            {', '.join(X + key_columns + [index])} 
                        FROM {self.input_relation} 
                        LIMIT 10""",
                    print_time_sql=False,
                )
                name_main = self.input_relation
            distance = [
                f"POWER(ABS(x.{X[i]} - y.{X[i]}), {self.parameters['p']})"
                for i in range(len(X))
            ]
            distance = f"POWER({' + '.join(distance)}, 1.0 / {self.parameters['p']})"
            table = f"""
                SELECT 
                    node_id, 
                    nn_id, 
                    SUM(CASE 
                          WHEN distance <= {self.parameters['eps']} 
                            THEN 1 
                          ELSE 0 
                        END) 
                        OVER (PARTITION BY node_id) AS density, 
                    distance 
                FROM (SELECT 
                          x.{index} AS node_id, 
                          y.{index} AS nn_id, 
                          {distance} AS distance 
                      FROM 
                      {name_main} AS x 
                      CROSS JOIN 
                      {name_main} AS y) distance_table"""
            if isinstance(conf.get_option("random_state"), int):
                order_by = "ORDER BY node_id, nn_id"
            else:
                order_by = ""
            graph = _executeSQL(
                query=f"""
                    SELECT /*+LABEL('learn.cluster.DBSCAN.fit')*/
                        node_id, 
                        nn_id 
                    FROM ({table}) VASTORBIT_SUBTABLE 
                    WHERE density > {self.parameters['min_samples']} 
                      AND distance < {self.parameters['eps']} 
                      AND node_id != nn_id {order_by}""",
                title="Computing the DBSCAN Table [Step 1]",
                method="fetchall",
            )
            main_nodes = list(
                dict.fromkeys([elem[0] for elem in graph] + [elem[1] for elem in graph])
            )
            clusters = {}
            for elem in main_nodes:
                clusters[elem] = None
            i = 0
            while graph:
                node = graph[0][0]
                node_neighbor = graph[0][1]
                if isinstance(clusters[node], NoneType) and isinstance(
                    clusters[node_neighbor], NoneType
                ):
                    clusters[node] = i
                    clusters[node_neighbor] = i
                    i = i + 1
                else:
                    if not isinstance(clusters[node], NoneType) and isinstance(
                        clusters[node_neighbor], NoneType
                    ):
                        clusters[node_neighbor] = clusters[node]
                    elif not (
                        isinstance(clusters[node_neighbor], NoneType)
                    ) and isinstance(clusters[node], NoneType):
                        clusters[node] = clusters[node_neighbor]
                del graph[0]
            self.n_clusters_ = i
            # Attach the (node_id -> cluster) mapping with an inline VALUES table
            # CSV-write + COPY round-trip, which Trino does not support.
            assigned = [
                (node_id, cluster)
                for node_id, cluster in clusters.items()
                if not isinstance(cluster, NoneType)
            ]
            cols = ", ".join(self.X + self.key_columns)
            if assigned:
                values = ", ".join(
                    f"({node_id}, {cluster})" for node_id, cluster in assigned
                )
                cluster_join = (
                    f" LEFT JOIN (VALUES {values}) AS y(node_id, cluster) "
                    f"ON x.{index} = y.node_id"
                )
                cluster_select = "COALESCE(cluster, -1)"
            else:
                # No core points were found: every row is noise.
                cluster_join = ""
                cluster_select = "-1"
            _executeSQL(
                query=f"""
                    CREATE TABLE {self.model_name} AS 
                       SELECT /*+LABEL('learn.cluster.DBSCAN.fit')*/
                            {cols}, 
                            {cluster_select} AS dbscan_clusters 
                       FROM {name_main} AS x{cluster_join}""",
                title="Computing the DBSCAN Table [Step 2]",
            )
            self.n_noise_ = _executeSQL(
                query=f"""
                    SELECT 
                        /*+LABEL('learn.cluster.DBSCAN.fit')*/ 
                        COUNT(*) 
                    FROM {self.model_name} 
                    WHERE dbscan_clusters = -1""",
                method="fetchfirstelem",
                print_time_sql=False,
            )
            self.p_ = self.parameters["p"]
        finally:
            if created_main:
                drop(name_main, method="table")

    # Prediction / Transformation Methods.

    def predict(self) -> VastFrame:
        """
        Creates a :py:class:`~VastFrame`
        of the model.

        Returns
        -------
        VastFrame
            the :py:class:`~VastFrame`
            including the prediction.

        Examples
        --------
        Let's start by importing
        :py:mod:`vastorbit`:

        .. ipython:: python

            import vastorbit as vo

        For this example, we will
        create a small dataset.

        .. ipython:: python

            data = vo.VastFrame(
                {
                    "col": [1.2, 1.1, 1.3, 1.5, 2, 2.2, 1.09, 0.9, 100, 102],
                }
            )

        Then we import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import DBSCAN

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = DBSCAN(
                eps = 0.5,
                min_samples = 2,
                p = 2,
            )

        Once the model is initialized
        we can fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(data, X = ["col"])

        And lastly we can use the
        trained model to predict:

        .. ipython:: python
            :suppress:
            :okexcept:

            result = model.predict()
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_dbscan_prediction_fun.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.predict()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_dbscan_prediction_fun.html

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.vast.cluster.DBSCAN`
            for more information about the
            different methods and usages.
        """
        return VastFrame(self.model_name)

    # Plotting Methods.

    def plot(
        self,
        max_nb_points: int = 100,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> PlottingObject:
        """
        Draws the model.

        Parameters
        ----------
        max_nb_points: int
            Maximum number of
            points to display.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to
            pass to the Plotting functions.

        Returns
        -------
        obj
            Plotting Object.

        Examples
        --------
        Let's start by importing
        :py:mod:`vastorbit`:

        .. ipython:: python

            import vastorbit as vo

        For this example, we will
        create a small dataset.

        .. ipython:: python

            data = vo.VastFrame(
                {
                    "col1": [1.2, 1.1, 1.3, 1.5, 2, 2.2, 1.09, 0.9, 100, 102],
                    "col2": [2.2, 2.1, 4.3, 5.5, 6, 2, 9, 1, 110, 120],
                },
            )

        Then we import the model:

        .. ipython:: python
            :okwarning:

            from vastorbit.machine_learning.vast import DBSCAN

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = DBSCAN(
                eps = 0.5,
                min_samples = 2,
                p = 2,
            )

        Once the model is initialized
        we can fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(data, X = ["col1", "col2"])

        And lastly we can plot the model:

        .. code-block:: python

            model.plot()

        .. ipython:: python
            :suppress:
            :okwarning:

            vo.set_option("plotting_lib", "plotly")
            fig = model.plot(width = 600)
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_dbscan_plot_func.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_dbscan_plot_func.html

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.vast.cluster.DBSCAN`
            for more information about the
            different methods and usages.
        """
        return VastFrame(self.model_name).scatter(
            columns=self.X,
            by="dbscan_clusters",
            max_cardinality=100,
            max_nb_points=max_nb_points,
            chart=chart,
            **style_kwargs,
        )


"""
Algorithms used for classification.
"""


class NearestCentroid(MulticlassClassifier):
    """
    Creates a ``NearestCentroid`` object
    using the k-nearest centroid algorithm.
    This object uses pure SQL to compute
    the distances and final score.

    .. important::

        This algorithm is not VAST
        Native and relies solely on SQL
        for attribute computation. While
        this model does not take advantage
        of the benefits provided by a model
        management system, including versioning
        and tracking, the SQL code it generates
        can still be used to create a pipeline.

    Parameters
    ----------
    p: int, optional
        The ``p`` corresponding to
        the one of the ``p``-distances
        (distance metric used to compute
        the model).

    Attributes
    ----------
    Many attributes are created
    during the fitting phase.

    ``clusters_``: numpy.array
        Cluster centers.
    ``p_``: int
        The ``p`` of the ``p``-distances.
    ``classes_``: numpy.array
        The classes labels.

    .. note::

        All attributes can be accessed using the
        :py:meth:`~vastorbit.machine_learning.vast.base.VASTModel.get_attributes`
        method.

    Examples
    --------

    The following examples provide a
    basic understanding of usage.
    For more detailed examples, please
    refer to the :ref:`user_guide.machine_learning`
    or the :ref:`examples`
    section on the website.

    Load data for machine learning
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    We import :py:mod:`vastorbit`:

    .. code-block:: python

        import vastorbit as vo

    .. hint::

        By assigning an alias to :py:mod:`vastorbit`,
        we mitigate the risk of code collisions with
        other libraries. This precaution is necessary
        because vastorbit uses commonly known function
        names like "average" and "median", which can
        potentially lead to naming conflicts. The use
        of an alias ensures that the functions from
        :py:mod:`vastorbit` are used as intended
        without interfering with functions from other
        libraries.

    For this example, we will use the iris dataset.

    .. code-block:: python

        import vastorbit.datasets as vod

        data = vod.load_iris()

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

    .. note::

        vastorbit offers a wide range of sample
        datasets that are ideal for training
        and testing purposes. You can explore
        the full list of available datasets in
        the :ref:`api.datasets`, which provides
        detailed information on each dataset and
        how to use them effectively. These datasets
        are invaluable resources for honing your
        data analysis and machine learning skills
        within the vastorbit environment.

    You can easily divide your dataset
    into training and testing subsets
    using the
    ``VastFrame.``:py:meth:`~vastorbit.VastFrame.train_test_split`
    method. This is a crucial step when
    preparing your data for machine learning,
    as it allows you to evaluate the
    performance of your models accurately.

    .. code-block:: python

        data = vod.load_iris()
        train, test = data.train_test_split(test_size = 0.2)

    .. warning::

        In this case, vastorbit utilizes seeded
        randomization to guarantee the reproducibility
        of your data split. However, please be aware
        that this approach may lead to reduced
        performance. For a more efficient data split,
        you can use the ``VastFrame.``:py:meth:`~vastorbit.VastFrame.to_db`
        method to save your results into ``tables``
        or ``temporary tables``. This will help
        enhance the overall performance of the
        process.

    .. ipython:: python
        :suppress:

        import vastorbit as vo
        import vastorbit.datasets as vod
        data = vod.load_iris()
        train, test = data.train_test_split(test_size = 0.2)

    Balancing the Dataset
    ^^^^^^^^^^^^^^^^^^^^^^

    In vastorbit, balancing a dataset to
    address class imbalances is made
    straightforward through the
    :py:meth:`~vastorbit.machine_learning.vast.preprocessing.balance`
    function within the ``preprocessing``
    module. This function enables users
    to rectify skewed class distributions
    efficiently. By specifying the target
    variable and setting parameters like
    the method for balancing, users can
    effortlessly achieve a more equitable
    representation of classes in their dataset.
    Whether opting for over-sampling,
    under-sampling, or a combination
    of both, vastorbit's
    :py:meth:`~vastorbit.machine_learning.vast.preprocessing.balance`
    function streamlines the process,
    empowering users to enhance the
    performance and fairness of their
    machine learning models trained
    on imbalanced data.

    To balance the dataset, use the following syntax.

    .. code-block:: python

        from vastorbit.machine_learning.vast.preprocessing import balance

        balanced_train = balance(
            name = "my_schema.train_balanced",
            input_relation = train,
            y = "good",
            method = "hybrid",
        )

    .. note::

        With this code, a table named `train_balanced`
        is created in the `my_schema` schema.
        It can then be used to train the model.
        In the rest of the example, we will work
        with the full dataset.

    .. hint::

        Balancing the dataset is a crucial
        step in improving the accuracy of
        machine learning models, particularly
        when faced with imbalanced class
        distributions. By addressing disparities
        in the number of instances across different
        classes, the model becomes more adept at
        learning patterns from all classes rather
        than being biased towards the majority
        class. This, in turn, enhances the model's
        ability to make accurate predictions for
        under-represented classes. The balanced
        dataset ensures that the model is not
        dominated by the majority class and, as a
        result, leads to more robust and unbiased
        model performance. Therefore, by employing
        techniques such as over-sampling, under-sampling,
        or a combination of both during dataset
        preparation, practitioners can significantly
        contribute to achieving higher accuracy and
        better generalization of their machine learning
        models.

    Model Initialization
    ^^^^^^^^^^^^^^^^^^^^^

    First we import the
    :py:class:`~vastorbit.machine_learning.vast.cluster.NearestCentroid`
    model:

    .. ipython:: python

        from vastorbit.machine_learning.vast import NearestCentroid

    Then we can create the model:

    .. ipython:: python

        model = NearestCentroid(p = 2)

    Model Training
    ^^^^^^^^^^^^^^^

    We can now fit the model:

    .. ipython:: python

        model.fit(
            train,
            [
                "SepalLengthCm",
                "SepalWidthCm",
                "PetalLengthCm",
                "PetalWidthCm",
            ],
            "Species",
            test,
        )

    .. important::

        To train a model, you can directly use the
        :py:class:`~VastFrame` or the name of the
        relation stored in the database. The test
        set is optional and is only used to compute
        the test metrics. In :py:mod:`vastorbit`, we
        don't work using ``X`` matrices and ``y``
        vectors. Instead, we work directly with lists
        of predictors and the response name.

    .. important::

        As this model is not native, it solely relies on SQL statements to
        compute various attributes, storing them within the object. No data
        is saved in the database.

    Metrics
    ^^^^^^^^

    We can get the entire report using:

    .. ipython:: python
        :suppress:
        :okexcept:

        result = model.report()
        html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_report.html", "w")
        html_file.write(result._repr_html_())
        html_file.close()

    .. code-block:: python

        model.report()

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_report.html

    .. important::

        Most metrics are computed using a
        single SQL query, but some of them
        might require multiple SQL queries.
        Selecting only the necessary metrics
        in the report can help optimize performance.
        E.g. ``model.report(metrics = ["auc", "accuracy"])``.

    For classification models, we can easily modify the ``cutoff`` to observe
    the effect on different metrics:

    .. ipython:: python
        :suppress:
        :okexcept:

        result = model.report(cutoff = 0.2)
        html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_report_cutoff.html", "w")
        html_file.write(result._repr_html_())
        html_file.close()

    .. code-block:: python

        model.report(cutoff = 0.2)

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_report_cutoff.html


    You can also use the
    :py:meth:`~vastorbit.machine_learning.vast.cluster.NearestCentroid.score`
    function to compute any
    classification metric. The
    default metric is the accuracy:

    .. ipython:: python

        model.score(metric = "f1", average = "macro")

    .. note::

        For multi-class scoring, :py:mod:`vastorbit`
        allows the flexibility to use three averaging
        techniques: ``micro``, ``macro`` and ``weighted``.
        Please refer to
        `this link <https://towardsdatascience.com/micro-macro-weighted-averages-of-f1-score-clearly-explained-b603420b292f>`__
        for more details on how they are calculated.

    Prediction
    ^^^^^^^^^^^

    Prediction is straight-forward:

    .. ipython:: python
        :suppress:
        :okexcept:

        result = model.predict(
            test,
            [
                "SepalLengthCm",
                "SepalWidthCm",
                "PetalLengthCm",
                "PetalWidthCm",
            ],
            "prediction",
        )
        html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_prediction.html", "w")
        html_file.write(result._repr_html_())
        html_file.close()

    .. code-block:: python

        model.predict(
            test,
            [
                "SepalLengthCm",
                "SepalWidthCm",
                "PetalLengthCm",
                "PetalWidthCm",
            ],
            "prediction",
        )

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_prediction.html

    .. note::

        Predictions can be made automatically
        using the test set, in which case you
        don't need to specify the predictors.
        Alternatively, you can pass only the
        :py:class:`~VastFrame` to the
        :py:meth:`~vastorbit.machine_learning.vast.cluster.NearestCentroid.predict`
        function, but in this case, it's
        essential that the column names of
        the :py:class:`~VastFrame` match the
        predictors and response name in the
        model.

    Probabilities
    ^^^^^^^^^^^^^^

    It is also easy to get the model's probabilities:

    .. ipython:: python
        :suppress:
        :okexcept:

        result = model.predict_proba(
            test,
            [
                "SepalLengthCm",
                "SepalWidthCm",
                "PetalLengthCm",
                "PetalWidthCm",
            ],
            "prediction",
        )
        html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_proba.html", "w")
        html_file.write(result._repr_html_())
        html_file.close()

    .. code-block:: python

        model.predict_proba(
            test,
            [
                "SepalLengthCm",
                "SepalWidthCm",
                "PetalLengthCm",
                "PetalWidthCm",
            ],
            "prediction",
        )

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_proba.html

    .. note::

        Probabilities are added to the :py:class:`~VastFrame`,
        and vastorbit uses the corresponding probability
        function in SQL behind the scenes. You can use
        the ``pos_label`` parameter to add only the
        probability of the selected category.

    Confusion Matrix
    ^^^^^^^^^^^^^^^^^

    You can obtain the confusion matrix.

    .. ipython:: python

        model.confusion_matrix()

    .. hint::

        In the context of multi-class classification,
        you typically work with an overall confusion
        matrix that summarizes the classification
        efficiency across all classes. However, you
        have the flexibility to specify a ``pos_label``
        and adjust the cutoff threshold. In this case,
        a binary confusion matrix is computed, where
        the chosen class is treated as the positive
        class, allowing you to evaluate its efficiency
        as if it were a binary classification problem.

        **Specific confusion matrix:**

        .. ipython:: python

            model.confusion_matrix(pos_label = "Iris-setosa", cutoff = 0.6)

    .. note::

        In classification, the ``cutoff`` is a
        threshold value used to determine class
        assignment based on predicted probabilities
        or scores from a classification model. In
        binary classification, if the predicted
        probability for a specific class is greater
        than or equal to the cutoff, the instance is
        assigned to the positive class; otherwise, it
        is assigned to the negative class. Adjusting
        the cutoff allows for trade-offs between true
        positives and false positives, enabling the
        model to be optimized for specific objectives
        or to consider the relative costs of different
        classification errors. The choice of cutoff is
        critical for tailoring the model's performance
        to meet specific needs.

    Main Plots (Classification Curves)
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

    Classification models allow for the
    creation of various plots that are
    very helpful in understanding the
    model, such as the ROC Curve,
    PRC Curve, Cutoff Curve, Gain
    Curve, and more.

    Most of the classification curves
    can be found in the
    :ref:`chart_gallery.classification_curve`.

    For example, let's draw the
    model's ROC curve.

    .. code-block:: python

        model.roc_curve(pos_label = "Iris-setosa")

    .. ipython:: python
        :suppress:

        vo.set_option("plotting_lib", "plotly")
        fig = model.roc_curve(pos_label = "Iris-setosa")
        fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_roc.html")

    .. raw:: html
        :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_cluster_nearest_centroid_roc.html

    .. important::

        Most of the curves have a parameter called
        ``nbins``, which is essential for estimating
        metrics. The larger the ``nbins``, the more
        precise the estimation, but it can significantly
        impact performance. Exercise caution when
        increasing this parameter excessively.

    .. hint::

        In binary classification, various curves can
        be easily plotted. However, in multi-class
        classification, it's important to select the
        ``pos_label``, representing the class to be
        treated as positive when drawing the curve.

    Other Plots
    ^^^^^^^^^^^^

    **Contour plot** is another useful plot that can be produced
    for models with two predictors.

    .. code-block:: python

        model.contour(pos_label = "Iris-setosa")

    .. important::

        Machine learning models with two
        predictors can usually benefit
        from their own contour plot.
        This visual representation aids
        in exploring predictions and
        gaining a deeper understanding
        of how these models perform in
        different scenarios.
        Please refer to
        :ref:`chart_gallery.contour`
        for more examples.

    Parameter Modification
    ^^^^^^^^^^^^^^^^^^^^^^^

    In order to see the parameters:

    .. ipython:: python

        model.get_params()

    And to manually change some of the parameters:

    .. ipython:: python

        model.set_params({'p': 3})

    Model Register
    ^^^^^^^^^^^^^^

    As this model is not native, it does not
    support model management and versioning.
    However, it is possible to use the SQL
    code it generates for deployment.

    Model Exporting
    ^^^^^^^^^^^^^^^^

    **To Memmodel**

    .. code-block:: python

        model.to_memmodel()

    .. note::

        ``MemModel`` objects serve as in-memory
        representations of machine learning models.
        They can be used for both in-database and
        in-memory prediction tasks. These objects
        can be pickled in the same way that you
        would pickle a ``scikit-learn`` model.

    The following methods for exporting the model
    use ``MemModel``, and it is recommended to use
    ``MemModel`` directly.

    **To SQL**

    You can get the SQL code by:

    .. ipython:: python

        model.to_sql()

    **To Python**

    To obtain the prediction function in
    Python syntax, use the following code:

    .. ipython:: python

        X = [[5, 2, 3, 1]]
        model.to_python()(X)

    .. hint::

        The
        :py:meth:`~vastorbit.machine_learning.vast.cluster.NearestCentroid.to_python`
        method is used to retrieve predictions,
        probabilities, or cluster distances. For
        specific details on how to use this method
        for different model types, refer to the
        relevant documentation for each model.
    """

    # Properties.

    @property
    def _is_native(self) -> Literal[False]:
        return False

    @property
    def _fit_sql(self) -> Literal[""]:
        return ""

    @property
    def _predict_sql(self) -> Literal[""]:
        return ""

    @property
    def _model_subcategory(self) -> Literal["CLASSIFIER"]:
        return "CLASSIFIER"

    @property
    def _model_type(self) -> Literal["NearestCentroid"]:
        return "NearestCentroid"

    @property
    def _attributes(self) -> list[str]:
        return ["clusters_", "classes_", "p_"]

    # System & Special Methods.

    @save_vastorbit_logs
    def __init__(
        self, name: str = None, overwrite_model: bool = False, p: int = 2
    ) -> None:
        super().__init__(name, overwrite_model)
        self.parameters = {"p": p}

    def drop(self) -> bool:
        """
        ``NearestCentroid`` models are
        not stored in the VAST DB.

        The method will always return
        ``False``.
        """
        return False

    # Attributes Methods.

    def _compute_attributes(self) -> None:
        """
        Computes the model's attributes.
        """
        func = "APPROX_PERCENTILE" if (self.parameters["p"] == 1) else "AVG"
        func_params = ", 0.5" if (self.parameters["p"] == 1) else ""
        X_str = ", ".join(
            [f"{func}({column}{func_params}) AS {column}" for column in self.X]
        )
        centroids = TableSample.read_sql(
            query=f"""
            SELECT 
                {X_str}, 
                {self.y} 
            FROM {self.input_relation} 
            WHERE {self.y} IS NOT NULL 
            GROUP BY {self.y} 
            ORDER BY {self.y} ASC""",
            title="Getting Model Centroids.",
        )
        self.clusters_ = centroids.to_numpy()[:, 0:-1].astype(float)
        self.classes_ = self._array_to_int(centroids.to_numpy()[:, -1])
        self.p_ = self.parameters["p"]

    # Prediction / Transformation Methods.

    def _get_y_proba(
        self,
        pos_label: Optional[PythonScalar] = None,
    ) -> str:
        """
        Returns the input that
        represents the model's
        probabilities.
        """
        idx = self.get_match_index(pos_label, self.classes_, False)
        return self.deploySQL(allSQL=True)[idx]

    # I/O Methods.

    def to_memmodel(self) -> mm.NearestCentroid:
        """
        Converts the model to an InMemory object
        that can be used for different types of
        predictions.

        Returns
        -------
        InMemoryModel
            Representation of the model.

        Examples
        --------
        If we consider that you've built a model named
        ``model``, then it is easy to export it using
        the following syntax.

        .. code-block:: python

            model.to_memmodel()

        .. note::

            ``MemModel`` objects serve as in-memory
            representations of machine learning models.
            They can be used for both in-database and
            in-memory prediction tasks. These objects
            can be pickled in the same way that you
            would pickle a ``scikit-learn`` model.

        .. note::

            Look at
            :py:class:`~vastorbit.machine_learning.memmodel.cluster.NearestCentroid`
            for more information.
        """
        return mm.NearestCentroid(
            self.clusters_,
            self.classes_,
            self.p_,
        )
