"""
SPDX-License-Identifier: Apache-2.0
"""

import copy
import inspect
from abc import abstractmethod
from typing import Any, Callable, Literal, Optional, Union
import numpy as np


import vastorbit._config.config as conf
from vastorbit._typing import (
    ArrayLike,
    NoneType,
    PlottingObject,
    PythonNumber,
    PythonScalar,
    SQLColumns,
    SQLRelation,
    SQLExpression,
)
from vastorbit._utils._gen import gen_name, gen_tmp_name
from vastorbit._utils._sql._format import (
    clean_query,
    format_type,
    quote_ident,
)
from vastorbit._utils._sql._sys import _executeSQL

from vastorbit.core.tablesample.base import TableSample
from vastorbit.core.vastframe.base import VastFrame

import vastorbit.machine_learning.metrics as mt

from vastorbit.plotting._utils import PlottingUtils

from vastorbit.sql.drop import drop

if conf.get_import_success("graphviz"):
    from graphviz import Source

##
#  ___      ___  ___      ___     ______    ________    _______  ___
# |"  \    /"  ||"  \    /"  |   /    " \  |"      "\  /"     "||"  |
#  \   \  //  /  \   \  //   |  // ____  \ (.  ___  :)(: ______)||  |
#   \\  \/. ./   /\\  \/.    | /  /    ) :)|: \   ) || \/    |  |:  |
#    \.    //   |: \.        |(: (____/ // (| (___\ || // ___)_  \  |___
#     \\   /    |.  \    /:  | \        /  |:       :)(:      "|( \_|:  \
#      \__/     |___|\__/|___|  \"_____/   (________/  \_______) \_______)
#
##


class VASTModel(PlottingUtils):
    """
    Base Class for VAST Models.
    """

    # Properties.

    @property
    def _is_native(self) -> Literal[True]:
        return True

    @property
    def _is_using_native(self) -> Literal[False]:
        return False

    @property
    def object_type(self) -> Literal["VASTModel"]:
        return "VASTModel"

    @property
    def _sklearn_model(self) -> Literal[None]:
        return None

    def _get_sklearn_params(self) -> dict:
        """
        Returns the model parameters restricted (and translated) to those
        accepted by the backing scikit-learn estimator.

        VastOrbit wrappers expose a native parameter API (e.g. ``method`` on
        ``Scaler``, ``init='k-means++'`` on ``KMeans``, ``drop_first`` on
        ``OneHotEncoder``). Some of those parameters are consumed by the
        wrapper's own SQL / transform logic and have no scikit-learn
        equivalent, and a few use different value names. This forwards only
        the parameters scikit-learn actually accepts, translating known value
        mismatches, so building ``self._sklearn_model(**...)`` never fails on
        an unexpected keyword.
        """
        params = self.get_params()
        sklearn_model = self._sklearn_model
        if isinstance(sklearn_model, NoneType):
            return params
        accepted = set(inspect.signature(sklearn_model).parameters)
        out = {}
        for key, value in params.items():
            if key not in accepted:
                continue  # native-only parameter; not a scikit-learn argument
            if key == "init" and value == "k-means++":
                value = "k-means++"  # VastOrbit -> scikit-learn naming
            if key == "max_features" and value == "max":
                # VastOrbit "max" (use all features) -> scikit-learn None.
                value = None
            if key == "class_weight" and isinstance(value, (list, tuple)):
                # VastOrbit accepts a per-class weight list; scikit-learn wants
                # a {class_index: weight} mapping.
                value = {i: w for i, w in enumerate(value)}
            out[key] = value
        return out

    @property
    @abstractmethod
    def _fit_sql(self) -> str:
        """Must be overridden in child class"""
        raise NotImplementedError

    @property
    @abstractmethod
    def _model_category(self) -> str:
        """Must be overridden in child class"""
        raise NotImplementedError

    @property
    @abstractmethod
    def _model_subcategory(self) -> str:
        """Must be overridden in child class"""
        raise NotImplementedError

    @property
    @abstractmethod
    def _model_type(self) -> str:
        """Must be overridden in child class"""
        raise NotImplementedError

    @property
    def _attributes(self) -> list:
        """Must be overridden in the final class"""
        return []

    # Formatting Methods.

    @staticmethod
    def _array_to_int(object_: np.ndarray) -> np.ndarray:
        """
        Converts the input numpy.array values to integer,
        if possible.
        """
        res = copy.deepcopy(object_)
        try:
            return res.astype(int)
        except ValueError:
            return res

    @staticmethod
    def _format_vector(X: ArrayLike, vector: list[tuple]) -> np.ndarray:
        """
        Format the 2D vector to match with the input columns'
        names.
        """
        res = []
        for x in X:
            for y in vector:
                if quote_ident(y[0]).lower() == x.lower():
                    res += [y[1]]
        return np.array(res)

    @staticmethod
    def get_match_index(x: str, col_list: list, str_check: bool = True) -> None:
        """
        Returns the matching index.
        This function is used to simplify
        the overall code.

        Parameters
        ----------
        x: str
            Column's name.
        col_list: list
            List of columns.
        str_check: bool, optional
            If set to ``True``,
            checks if the formatted
            ``str`` is in the formatted
            ``list``. No need for an
            exact match.

        Returns
        -------
        int
            index.

        Examples
        --------
        The following code demonstrates
        the usage of the function.

        .. ipython:: python

            # Import the VAST Model.
            from vastorbit.machine_learning.vast.base import VASTModel

            # Match
            VASTModel.get_match_index('b', ['"A"', '"B"', '"C"'])

            # str_check = False
            VASTModel.get_match_index('b', ['"A"', '"B"', '"C"'], str_check = False)

            # No Match
            VASTModel.get_match_index('d', ['"A"', '"B"', '"C"'])

        .. note::

            These functions serve as utilities to
            construct others, simplifying the overall
            code.
        """
        for idx, col in enumerate(col_list):
            if (str_check and quote_ident(x.lower()) == quote_ident(col.lower())) or (
                x == col
            ):
                return idx

    # System & Special Methods.

    def __init__(
        self, name: str = None, overwrite_model: bool = False, **kwargs
    ) -> None:
        self.model_name = name
        if not self.model_name:
            self.model_name = gen_tmp_name(
                schema=conf.get_option("temp_schema"), name=self._model_type
            )
        self.overwrite_model = overwrite_model
        self.parameters = kwargs

    def __repr__(self) -> str:
        """
        Returns the model Representation.
        """
        return f"<{self._model_type}>"

    def drop(self) -> bool:
        """
        Drops the model from
        the VAST database.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        You can easily drop the model:

        .. ipython:: python

            model.drop()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return drop(self.model_name, method="model")

    # Attributes Methods.

    def get_attributes(self, attr_name: Optional[str] = None) -> Any:
        """
        Returns the model attributes.

        Parameters
        ----------
        attr_name: str, optional
            Attribute name.

        Returns
        -------
        Any
            model attribute.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        We can easily get the
        model attributes:

        .. ipython:: python

            model.get_attributes()

        To access a specific attribute:

        .. ipython:: python

            model.get_attributes('coef_')

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        if not attr_name:
            return self._attributes
        elif attr_name in self._attributes:
            if hasattr(self, attr_name):
                return copy.deepcopy(getattr(self, attr_name))
            else:
                raise AttributeError("The attribute is not yet computed.")
        elif attr_name + "_" in self._attributes:
            return self.get_attributes(attr_name + "_")
        else:
            raise AttributeError("The attribute is not yet computed.")

    def _is_binary_classifier(self) -> Literal[False]:
        """
        Returns ``True`` if the model
        is a ``BinaryClassifier``.
        """
        return False

    # Parameters Methods.

    def get_params(self) -> dict:
        """
        Returns the parameters
        of the model.

        Returns
        -------
        dict
            model parameters.

        Examples
        --------
        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can easily get the
        model parameters:

        .. ipython:: python

            model.get_params()

        Let's change some of the
        parameter.

        .. ipython:: python

            model.set_params(
                solver = 'lbfgs',
                max_iter = 200,
            )

        The parameters have changed:

        .. ipython:: python

            model.get_params()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return copy.deepcopy(self.parameters)

    def set_params(self, parameters: Optional[dict] = None, **kwargs) -> None:
        """
        Sets the parameters
        of the model.

        Parameters
        ----------
        parameters: dict, optional
            New parameters.
        ``**kwargs``
            New parameters can also
            be passed as arguments,
            Example:
            ``set_params(param1 = val1, param2 = val2)``

        Examples
        --------
        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can easily get the
        model parameters:

        .. ipython:: python

            model.get_params()

        Let's change some of the
        parameter.

        .. ipython:: python

            model.set_params(
                solver = 'lbfgs',
                max_iter = 200,
            )

        The parameters have changed:

        .. ipython:: python

            model.get_params()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        parameters = format_type(parameters, dtype=dict)
        new_parameters = copy.deepcopy({**self.parameters, **parameters, **kwargs})
        self.__init__(**new_parameters)

    # Model's Summary.

    def summarize(self) -> str:
        """
        Summarizes the model.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        Let's summarize the model.

        .. ipython:: python

            model.summarize()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        lines = [f"=== {self._model_type} ===", f"model_name: {self.model_name}"]
        try:
            params = self.get_params()
            if params:
                lines.append("")
                lines.append("Parameters:")
                for key, val in params.items():
                    lines.append(f"  {key}: {val}")
        except Exception:
            pass
        try:
            attr_names = self._attributes
            if attr_names:
                lines.append("")
                lines.append("Attributes:")
                for attr in attr_names:
                    try:
                        value = self.get_attributes(attr)
                    except Exception:
                        value = "<not computed>"
                    svalue = str(value).replace("\n", " ")
                    if len(svalue) > 200:
                        svalue = svalue[:200] + "..."
                    lines.append(f"  {attr}: {svalue}")
        except Exception:
            pass
        return "\n".join(lines)

    # I/O Methods.

    def deploySQL(self, X: Optional[SQLColumns] = None) -> str:
        """
        Returns the SQL code
        needed to deploy the
        model.

        Parameters
        ----------
        X: SQLColumns, optional
            ``list`` of the columns used
            to deploy the model.
            If empty, the model predictors
            are used.

        Returns
        -------
        str
            the SQL code needed
            to deploy the model.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        Get the VAST SQL code
        needed to deploy the model.

        .. ipython:: python

            model.deploySQL()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        X = format_type(X, dtype=list, na_out=self.X)
        X = quote_ident(X)
        sql = self.to_memmodel().predict_sql(X)
        return clean_query(sql)

    @staticmethod
    def export_models(
        name: str,
        path: str,
        kind: Literal["pmml", "VAST", "VAST_models", "tensorflow", "tf", None] = None,
    ) -> bool:
        """
        Exports machine
        learning models.

        Parameters
        ----------
        name: str
            Model's name.
        path: str
            Absolute path of an output
            directory to store the
            exported models.

            .. warning::

                This function operates solely
                on the server side and is not
                accessible locally.
                The ``path`` provided should
                match the location where the
                file(s) will be exported on
                the server.
        kind: str, optional
            One of the following:
             - pmml
             - VAST
             - tensorflow

        Returns
        -------
        bool
            ``True`` if the model
            was successfully
            exported.

        Examples
        --------
        Let's consider we've fitted a
        VAST model named 'my_model'.
        It is stored in the 'my_schema'
        schema and available in the
        Database.

        You can export it easily:

        .. code-block:: python

            from vastorbit.machine_learning.vast.base import VASTModel

            VASTModel.export_models(
                name = 'my_schema.my_model',
                kind = 'pmml', # Pick up the export type.
            )

        .. warning::

            This function operates solely
            on the server side and is not
            accessible locally.
        """
        if isinstance(kind, NoneType):
            params = ""
        else:
            lookup_table = {"tf": "tensorflow", "VAST": "VAST_models"}
            kind = str(kind).lower()
            if kind in lookup_table:
                kind = lookup_table[kind]
            params = f" USING PARAMETERS category = '{kind}'"
        result = _executeSQL(
            query=f"""
                SELECT EXPORT_MODELS('{path}',
                                     '{name}'{params})""",
            method="fetchfirstelem",
            print_time_sql=False,
        )
        return result == "Success"

    @staticmethod
    def import_models(
        path: str,
        schema: Optional[str] = None,
        kind: Literal["pmml", "VAST", "VAST_models", "tensorflow", "tf", None] = None,
    ) -> bool:
        """
        Imports machine
        learning models.

        Parameters
        ----------
        path: str
            Absolute path of an output
            directory to store the
            exported models.

            .. warning::

                This function operates solely
                on the server side and is not
                accessible locally.
                The ``path`` provided should
                match the location where the
                file(s) will be exported on
                the server.
        schema: str, optional
            Schema name.
        kind: str, optional
            One of the following:
             - pmml
             - VAST
             - tensorflow

        Returns
        -------
        bool
            ``True`` if the model
            was successfully
            imported.

        Examples
        --------
        Let's consider we've fitted a
        VAST model named 'my_model'.
        We want to import it in the
        'my_schema' schema.

        You can import it easily:

        .. code-block:: python

            from vastorbit.machine_learning.vast.base import VASTModel

            VASTModel.import_models(
                path = 'server_location'
                schema = 'my_schema',
                kind = 'pmml', # Pick up the import type.
            )

        .. warning::

            This function operates solely
            on the server side and is not
            accessible locally.
        """
        if isinstance(schema, NoneType):
            schema = conf.get_option("temp_schema")
        schema = schema.replace("'", "''")
        params = f" USING PARAMETERS new_schema='{schema}'"
        if not (isinstance(kind, NoneType)):
            lookup_table = {"tf": "tensorflow", "VAST": "VAST_models"}
            kind = str(kind).lower()
            if kind in lookup_table:
                kind = lookup_table[kind]
            params += f", category = '{kind}'"
        result = _executeSQL(
            query=f"""SELECT IMPORT_MODELS('{path}'{params})""",
            method="fetchfirstelem",
            print_time_sql=False,
        )
        return result == "Success"

    def to_binary(self, path: str):
        """
        Exports the model to the
        VAST Binary format.

        Parameters
        ----------
        path: str
            Absolute path of an output
            directory to store the
            exported models.

            .. warning::

                This function operates solely
                on the server side and is not
                accessible locally.
                The ``path`` provided should
                match the location where the
                file(s) will be exported on
                the server.

        Returns
        -------
        bool
            ``True`` if the model
            was successfully
            exported.

        Examples
        --------
        Let's consider we've fitted a
        VAST model ``model``.

        You can export it easily to
        the VAST binary format
        by using:

        .. code-block:: python

            model.to_binary(path = 'server_location')

        .. warning::

            This function operates solely
            on the server side and is not
            accessible locally.
        """
        return self.export_models(name=self.model_name, path=path, kind="VAST")

    def to_python(
        self,
        return_proba: bool = False,
        return_distance_clusters: bool = False,
    ) -> Callable:
        """
        Returns the Python function
        needed for in-memory scoring
        without using built-in VAST
        functions.

        Parameters
        ----------
        return_proba: bool, optional
            If set to ``True`` and the
            model is a classifier, the
            function returns the model
            probabilities.
        return_distance_clusters: bool, optional
            If set to ``True`` and the
            model is cluster-based, the
            function returns the model
            clusters distances.

        Returns
        -------
        Callable
            Python function.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        Get the Python function
        needed to deploy the model.

        .. ipython:: python

            model.to_python()

        Use the function to make
        predictions:

        .. ipython:: python

            # Building a dataset
            data = [
                [1.0, 2.3, 3.2, 1.9, 1.0, 0.0]
            ]
            # Making in-memory predictions
            model.to_python()(data)

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        model = self.to_memmodel()
        if return_proba:
            return model.predict_proba
        elif hasattr(model, "predict") and not return_distance_clusters:
            return model.predict
        else:
            return model.transform

    def to_sql(
        self,
        X: Optional[SQLColumns] = None,
        return_proba: bool = False,
        return_distance_clusters: bool = False,
    ) -> SQLExpression:
        """
        Returns the SQL code needed
        to deploy the model without
        using built-in VAST
        functions.

        Parameters
        ----------
        X: SQLColumns, optional
            Input predictor's name.
        return_proba: bool, optional
            If set to ``True`` and the
            model is a classifier, the
            function returns the class
            probabilities.
        return_distance_clusters: bool, optional
            If set to ``True`` and the
            model is cluster-based, the
            function returns the model
            clusters distances.

        Returns
        -------
        SQLExpression
            SQL code.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        Get the SQL code needed
        to deploy the model.

        .. ipython:: python

            model.to_sql()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        X = format_type(X, dtype=list)
        if len(X) == 0:
            X = self.X
        model = self.to_memmodel()
        if return_proba:
            return model.predict_proba_sql(X)
        elif hasattr(model, "predict") and not return_distance_clusters:
            return model.predict_sql(X)
        else:
            return model.transform_sql(X)

    # Plotting Methods.

    def _get_plot_args(self, method: Optional[str] = None) -> list:
        """
        Returns the args used
        by plotting methods.
        """
        if method == "contour":
            args = [self.X, self.deploySQL(X=self.X)]
        else:
            raise NotImplementedError
        return args

    def _get_plot_kwargs(
        self,
        nbins: int = 30,
        chart: Optional[PlottingObject] = None,
        method: Optional[str] = None,
    ) -> dict:
        """
        Returns the kwargs used
        by plotting methods.
        """
        res = {"nbins": nbins, "chart": chart}
        if method == "contour":
            if self._model_subcategory == "CLASSIFIER":
                res["func_name"] = f"p({self.y} = 1)"
            else:
                res["func_name"] = self.y
        else:
            raise NotImplementedError
        return res

    def contour(
        self,
        nbins: int = 100,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> PlottingObject:
        """
        Draws the model's contour plot.

        Parameters
        ----------
        nbins: int, optional
            Number of bins used
            to discretize the
            two predictors.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to
            pass to the Plotting functions.

        Returns
        -------
        obj
            Plotting Object.

        Examples
        --------
        Let's consider we've fitted a model
        ``model``.

        **Contour plot** is another useful
        plot that can be produced for models
        with two predictors.

        .. code-block:: python

            model.contour()

        .. important::

            Machine learning models with two
            predictors can usually benefit
            from their own contour plot. This
            visual representation aids in
            exploring predictions and gaining
            a deeper understanding of how these
            models perform in different scenarios.
            Please refer to
            :ref:`chart_gallery.contour`
            for more examples.
        """
        return VastFrame(self.input_relation).contour(
            *self._get_plot_args(method="contour"),
            **self._get_plot_kwargs(nbins=nbins, chart=chart, method="contour"),
            **style_kwargs,
        )


class Supervised(VASTModel):
    # Properties

    @property
    @abstractmethod
    def _predict_sql(self) -> str:
        """Must be overridden in child class"""
        raise NotImplementedError

    # System & Special Methods.

    @property
    def _model_category(self) -> Literal["SUPERVISED"]:
        return "SUPERVISED"

    # Model Fitting Method.

    def fit(
        self,
        input_relation: SQLRelation,
        X: SQLColumns,
        y: str,
        test_relation: SQLRelation = "",
        return_report: bool = False,
    ) -> Optional[str]:
        """
        Trains the model.

        Parameters
        ----------
        input_relation: SQLRelation
            Training relation.
        X: SQLColumns
            List of the predictors.
        y: str
            Response column.
        test_relation: SQLRelation, optional
            Relation used to
            test the model.
        return_report: bool, optional
            [For native models]
            When set to ``True``,
            the model summary
            will be returned.
            Otherwise, it will
            be printed.

        Returns
        -------
        str
            model's summary.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """

        # Initialization
        X = format_type(X, dtype=list)
        self.X = quote_ident(X)
        self.y = quote_ident(y)
        if isinstance(input_relation, VastFrame):
            self.input_relation = input_relation.current_relation()
        else:
            self.input_relation = input_relation
            _relation = input_relation
        if isinstance(test_relation, VastFrame):
            self.test_relation = test_relation.current_relation()
        elif test_relation:
            self.test_relation = test_relation
        else:
            self.test_relation = self.input_relation

        if not (isinstance(self._sklearn_model, NoneType)):
            vdf = VastFrame(self.input_relation)

            # CRITICAL FIX: Fetch X and y together in ONE query to preserve row order
            all_cols = self.X + [self.y]
            data = vdf[all_cols].to_numpy()

            # Split into X and y. Fetching X and y in one query preserves row
            # order, but if the response is categorical the combined array is
            # promoted to a string dtype; cast the predictors back to float so
            # the scikit-learn estimator receives numeric X.
            # CategoricalNB operates on (possibly string) categories rather than
            # floats. Ordinal-encode the predictors to integer codes and remember
            # the encoder so the in-database SQL can reference the original labels.
            if getattr(self, "parameters", {}).get("nbtype") == "categorical":
                from sklearn.preprocessing import OrdinalEncoder

                self._ordinal_encoder = OrdinalEncoder()
                X = self._ordinal_encoder.fit_transform(data[:, :-1])
            else:
                X = data[:, :-1].astype(float)  # All columns except last
            y = data[:, -1]  # Last column

            # scikit-learn estimators reject NaN/Inf. Drop rows with missing
            # values in the predictors (and in the response when it is numeric)
            # so models fit on data containing nulls — e.g. lagged/differenced
            # series or columns with blanks — instead of raising. A categorical
            # (string) response only filters on X.
            finite_mask = np.isfinite(X).all(axis=1)
            if y.dtype.kind in "fiu":
                y = y.astype(float)
                finite_mask &= np.isfinite(y)
            if not finite_mask.all():
                X = X[finite_mask]
                y = y[finite_mask]

            model = self._sklearn_model(**self._get_sklearn_params())
            model.fit(X, y)
            self._model = model
            self._X = X
            self._y = y

        # Fitting
        self._compute_attributes()
        return None


class Tree:
    # Properties.

    @property
    def _attributes(self) -> list:
        """Must be overridden in the final class"""
        return []

    # System & Special Methods.

    def _compute_trees_arrays(
        self, tree: TableSample, X: list, return_probability: bool = False
    ) -> list[list]:
        """
        Takes as input a tree which is represented by a
        TableSample.  It returns a list of arrays. Each
        index of the arrays represents a node value.
        """
        for i in range(len(tree["tree_id"])):
            tree.values["left_child_id"] = [
                i if node_id == tree.values["node_id"][i] else node_id
                for node_id in tree.values["left_child_id"]
            ]
            tree.values["right_child_id"] = [
                i if node_id == tree.values["node_id"][i] else node_id
                for node_id in tree.values["right_child_id"]
            ]
            tree.values["node_id"][i] = i

            for j, xj in enumerate(X):
                if (
                    quote_ident(tree["split_predictor"][i]).lower()
                    == quote_ident(xj).lower()
                ):
                    tree["split_predictor"][i] = j

            if self._model_type == "GradientBoostingClassifier" and isinstance(
                tree["log_odds"][i], str
            ):
                val, all_val = tree["log_odds"][i].split(","), {}
                for v in val:
                    all_val[v.split(":")[0]] = float(v.split(":")[1])
                tree.values["log_odds"][i] = all_val
        if self._model_type == "IsolationForest":
            tree.values["prediction"], n = [], len(tree.values["leaf_path_length"])
            for i in range(n):
                # Check if any training_row_count is NaN
                if not isinstance(
                    tree.values["training_row_count"][i], NoneType
                ) and np.isnan(tree.values["training_row_count"][i]):
                    # Check if the node is root
                    if not (tree.values["node_depth"][i] == 0):
                        tree.values["training_row_count"][i] = 0
                    else:
                        # If ``training_row_count`` is nan and the node is root, then discard the tree.
                        return None
                if not isinstance(tree.values["leaf_path_length"][i], NoneType):
                    tree.values["prediction"] += [
                        [
                            int(float(tree.values["leaf_path_length"][i])),
                            int(float(tree.values["training_row_count"][i])),
                        ]
                    ]
                else:
                    tree.values["prediction"] += [None]
        trees_arrays = [
            tree["left_child_id"],
            tree["right_child_id"],
            tree["split_predictor"],
            tree["split_value"],
            tree["prediction"],
            tree["is_categorical_split"],
        ]
        if self._model_type == "GradientBoostingClassifier":
            trees_arrays += [tree["log_odds"]]
        if return_probability:
            trees_arrays += [tree["probability/variance"]]
        return trees_arrays

    # Features Importance Methods.

    def _get_features_importance(self, tree_id: Optional[int] = None) -> np.ndarray:
        """
        Returns model's features importances.
        """
        if isinstance(tree_id, NoneType):
            return copy.deepcopy(self.feature_importances_)
        elif isinstance(tree_id, int) and (0 <= tree_id < self.n_estimators_):
            return copy.deepcopy(self.feature_importances_trees_[tree_id])
        else:
            raise ValueError

    def _get_tree_classes(self, tree_arrays: list) -> np.ndarray:
        """
        Extracts unique class labels from the output of _compute_trees_arrays.
        Returns a sorted numpy array of unique class labels.
        """
        value_array = tree_arrays[4]
        unique_values = set()
        for val in value_array:
            if not isinstance(val, NoneType):
                unique_values.add(val)
        return np.array(sorted(unique_values))

    def features_importance(
        self,
        tree_id: Optional[int] = None,
        show: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> TableSample:
        """
        Computes the model's
        features importance.

        Parameters
        ----------
        tree_id: int
            Tree ID.
        show: bool
            If set to ``True``,
            draw the features
            importance.
        chart: PlottingObject, optional
            The chart object
            to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        TableSample
            features importance.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's divide the dataset into
        training and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        We import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import RandomForestClassifier

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import RandomForestClassifier

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = RandomForestClassifier(
                n_estimators = 5
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        We can conveniently get
        the features importance:

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.features_importance()
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_rf_classifier_feature.html")

        .. code-block:: python

            result = model.features_importance()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_rf_classifier_feature.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        fi = self._get_features_importance(tree_id=tree_id)
        if show:
            data = {
                "importance": fi,
            }
            layout = {"columns": copy.deepcopy(self.X)}
            vo_plt, kwargs = self.get_plotting_lib(
                class_name="ImportanceBarChart",
                chart=chart,
                style_kwargs=style_kwargs,
            )
            return vo_plt.ImportanceBarChart(data=data, layout=layout).draw(**kwargs)
        importances = {
            "index": [quote_ident(x)[1:-1].lower() for x in self.X],
            "importance": list(abs(fi)),
            "sign": list(np.sign(fi)),
        }
        return TableSample(values=importances).sort(column="importance", desc=True)

    # Plotting Methods.

    def plot(
        self,
        max_nb_points: int = 100,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> PlottingObject:
        """
        Draws the model.

        Parameters
        ----------
        max_nb_points: int
            Maximum number of
            points to display.
        chart: PlottingObject, optional
            The chart object
            to plot on.
        ``**style_kwargs``
            Any optional parameter to
            pass to the Plotting functions.

        Returns
        -------
        obj
            Plotting Object.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's divide the dataset into
        training and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        We import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import RandomForestClassifier

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import RandomForestClassifier

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = RandomForestClassifier(
                n_estimators = 5
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        If the model allows, you can also
        generate relevant plots. For example,
        regression plots can be found in the
        :ref:`chart_gallery.regression_plot`
        or :ref:`chart_gallery.classification_plot`.

        .. code-block:: python

            model.plot()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        if self._model_subcategory == "REGRESSOR":
            vdf = VastFrame(self.input_relation)
            vdf["_prediction"] = self.deploySQL()
            vo_plt, kwargs = self.get_plotting_lib(
                class_name="RegressionTreePlot",
                chart=chart,
                style_kwargs=style_kwargs,
            )
            return vo_plt.RegressionTreePlot(
                vdf=vdf,
                columns=self.X + [self.y] + ["_prediction"],
                max_nb_points=max_nb_points,
            ).draw(**kwargs)
        else:
            raise NotImplementedError

    # Trees Representation Methods.

    def get_tree(self, tree_id: int = 0) -> TableSample:
        """
        Returns a table with all
        the input tree information.

        Parameters
        ----------
        tree_id: int, optional
            Unique tree  identifier,
            an ``integer`` in the range
            ``[0, n_estimators - 1]``.

        Returns
        -------
        TableSample
            tree.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's divide the dataset into
        training and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        We import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import RandomForestClassifier

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import RandomForestClassifier

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = RandomForestClassifier(
                n_estimators = 5
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        To get the input tree:

        .. ipython:: python
            :suppress:

            result = model.get_tree(tree_id = 0)
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_rf_classifier_tree_score_1.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.get_tree(tree_id = 0)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_rf_classifier_tree_score_1.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        n_est = getattr(self, "n_estimators_", 1)
        if not (isinstance(tree_id, int) and 0 <= tree_id < n_est):
            raise ValueError(
                "Parameter 'tree_id' must be an integer in the range "
                f"[0, {n_est - 1}]."
            )

        if hasattr(self._model, "estimators_"):
            # RandomForest -> 1-D estimators_; GradientBoosting (GradientBoosting*) -> 2-D,
            # so ravel handles both. IsolationForest also exposes estimators_.
            skl_tree = np.ravel(self._model.estimators_)[tree_id].tree_
        else:
            # Single decision tree model.
            skl_tree = self._model.tree_

        children_left = skl_tree.children_left
        children_right = skl_tree.children_right
        feature = skl_tree.feature
        threshold = skl_tree.threshold
        value = skl_tree.value
        n_node_samples = skl_tree.n_node_samples
        impurity = skl_tree.impurity
        n_nodes = skl_tree.node_count

        # Node depth via iterative traversal (sklearn TREE_LEAF == -1).
        node_depth = [0] * n_nodes
        stack = [(0, 0)]
        while stack:
            nid, depth = stack.pop()
            node_depth[nid] = depth
            if children_left[nid] != -1:
                stack.append((int(children_left[nid]), depth + 1))
                stack.append((int(children_right[nid]), depth + 1))

        is_classifier = "Classifier" in self._model_type
        is_isolation = self._model_type == "IsolationForest"

        cols = {
            "tree_id": [],
            "node_id": [],
            "node_depth": [],
            "is_leaf": [],
            "left_child_id": [],
            "right_child_id": [],
            "split_predictor": [],
            "split_value": [],
            "is_categorical_split": [],
            "prediction": [],
            "probability/variance": [],
            "training_row_count": [],
        }
        if is_isolation:
            cols["leaf_path_length"] = []
        if self._model_type == "GradientBoostingClassifier":
            cols["log_odds"] = []

        for i in range(n_nodes):
            is_leaf = children_left[i] == -1
            cols["tree_id"].append(tree_id)
            cols["node_id"].append(i)
            cols["node_depth"].append(node_depth[i])
            cols["is_leaf"].append(bool(is_leaf))
            # scikit-learn splits are always numeric (no native categorical
            # split); leaf nodes have no split at all and are marked None so the
            # JSON/tree export routes them through the leaf-value branch instead
            # of trying to float() a non-existent numeric threshold.
            cols["is_categorical_split"].append(None if is_leaf else False)
            cols["training_row_count"].append(int(n_node_samples[i]))

            if not is_leaf:
                cols["left_child_id"].append(int(children_left[i]))
                cols["right_child_id"].append(int(children_right[i]))
                cols["split_predictor"].append(self.X[int(feature[i])])
                cols["split_value"].append(float(threshold[i]))
                cols["prediction"].append(None)
                cols["probability/variance"].append(None)
                if is_isolation:
                    cols["leaf_path_length"].append(None)
                if self._model_type == "GradientBoostingClassifier":
                    cols["log_odds"].append(None)
                continue

            # Leaf node.
            cols["left_child_id"].append(None)
            cols["right_child_id"].append(None)
            cols["split_predictor"].append(None)
            cols["split_value"].append(None)
            if is_isolation:
                # IsolationForest scores from path length / sub-sample size.
                cols["prediction"].append(None)
                cols["probability/variance"].append(None)
                cols["leaf_path_length"].append(node_depth[i])
            elif is_classifier:
                counts = np.asarray(value[i][0], dtype=float)
                total = counts.sum() or 1.0
                k = int(np.argmax(counts))
                cols["prediction"].append(self.classes_[k])
                cols["probability/variance"].append(float(counts[k] / total))
                if self._model_type == "GradientBoostingClassifier":
                    cols["log_odds"].append(
                        ",".join(
                            f"{self.classes_[j]}:{float(value[i][0][j])}"
                            for j in range(len(counts))
                        )
                    )
            else:  # regressor
                cols["prediction"].append(float(value[i][0][0]))
                cols["probability/variance"].append(float(impurity[i]))

        return TableSample(values=cols)

    def to_graphviz(
        self,
        tree_id: int = 0,
        classes_color: Optional[list] = None,
        round_pred: int = 2,
        percent: bool = False,
        vertical: bool = True,
        node_style: dict | None = None,
        edge_style: Optional[dict] = None,
        leaf_style: Optional[dict] = None,
    ) -> str:
        """
        Returns the code for a Graphviz tree.

        Parameters
        ----------
        tree_id: int, optional
            Unique tree identifier,
            an integer in the range
            ``[0, n_estimators - 1]``.
        classes_color: ArrayLike, optional
            Colors that represent
            the different classes.
        round_pred: int, optional
            The number of decimals
            to round the prediction
            to. ``0`` rounds to an
            ``integer``.
        percent: bool, optional
            If set to ``True``, the
            probabilities are returned
            as percents.
        vertical: bool, optional
            If set to ``True``, the
            function generates a
            vertical tree.
        node_style: dict, optional
            ``dictionary`` of options
            to customize each node of
            the tree. For a list of
            options, see the:
            `Graphviz API <https://graphviz.org/doc/info/attrs.html>`__ .
        edge_style: dict, optional
            ``dictionary`` of options
            to customize each edge of
            the tree. For a list of
            options, see the:
            `Graphviz API <https://graphviz.org/doc/info/attrs.html>`__ .
        leaf_style: dict, optional
            ``dictionary`` of options
            to customize each leaf of
            the tree. For a list of
            options, see the:
            `Graphviz API <https://graphviz.org/doc/info/attrs.html>`__ .

        Returns
        -------
        str
            Graphviz code.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's divide the dataset into
        training and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        We import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import RandomForestClassifier

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import RandomForestClassifier

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = RandomForestClassifier(
                n_estimators = 5
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        Export the input tree to graphviz:

        .. ipython:: python

            model.to_graphviz(tree_id = 0)

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        if node_style is None:
            node_style = {"shape": "box", "style": "filled"}
        return self.trees_[tree_id].to_graphviz(
            feature_names=self.X,
            classes_color=classes_color,
            round_pred=round_pred,
            percent=percent,
            vertical=vertical,
            node_style=node_style,
            edge_style=edge_style,
            leaf_style=leaf_style,
        )

    def plot_tree(
        self,
        tree_id: int = 0,
        pic_path: Optional[str] = None,
        *args,
        **kwargs,
    ) -> "Source":
        """
        Draws the input tree.
        Requires the graphviz
        module.

        Parameters
        ----------
        tree_id: int, optional
            Unique tree identifier,
            an integer in the range
            ``[0, n_estimators - 1]``.
        pic_path: str, optional
            Absolute path to save
            the image of the tree.
        *args, ``**kwargs``: Any, optional
            Arguments to pass to
            the ``to_graphviz``
            method.

        Returns
        -------
        graphviz.Source
            graphviz object.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's divide the dataset into
        training and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        We import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import RandomForestClassifier

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import RandomForestClassifier

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = RandomForestClassifier(
                n_estimators = 5
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        To plot the input tree:

        .. code-block:: python

            model.plot_tree()

        .. ipython:: python
            :suppress:

            res = model.plot_tree(tree_id = 0)
            res.render(filename='figures/machine_learning_VAST_tree_rf_classifier_', format='png')


        .. image:: /../figures/machine_learning_VAST_tree_rf_classifier_.png

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return self.trees_[tree_id].plot_tree(
            pic_path=pic_path,
            feature_names=self.X,
            *args,
            **kwargs,
        )


class BinaryClassifier(Supervised):
    """
    Base Class for VAST Binary Classifier.
    """

    # Properties.

    @property
    def classes_(self) -> np.ndarray:
        return np.array([0, 1])

    # Attributes Methods.

    def _is_binary_classifier(self) -> Literal[True]:
        """
        Returns ``True`` if the
        model is a ``BinaryClassifier``.
        """
        return True

    # I/O Methods.

    def deploySQL(
        self, X: Optional[SQLColumns] = None, cutoff: Optional[PythonNumber] = None
    ) -> str:
        """
        Returns  the  SQL code  needed to deploy  the  model.

        Parameters
        ----------
        X: SQLColumns, optional
            List of the  columns used to deploy the model. If
            empty, the model predictors are used.
        cutoff: PythonNumber, optional
                Probability cutoff. If this number is not between
            0 and 1,  the method retruns the  probability
            of class 1.

        Returns
        -------
        str
                the SQL code needed to deploy the model.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        To get the Model VAST
        SQL, use below:

        .. ipython:: python

            model.deploySQL()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        X = format_type(X, dtype=list, na_out=self.X)
        X = quote_ident(X)
        sql = self.to_memmodel().predict_proba_sql(X)[1]
        if not isinstance(cutoff, NoneType) and 0 <= cutoff <= 1:
            sql = f"""
                (CASE 
                    WHEN {sql} >= {cutoff} 
                        THEN 1 
                    WHEN {sql} IS NULL 
                        THEN NULL 
                    ELSE 0 
                END)"""
        return clean_query(sql)

    # Model Evaluation Methods.

    def classification_report(
        self,
        metrics: Union[
            None, str, list[Literal[tuple(mt.FUNCTIONS_CLASSIFICATION_DICTIONNARY)]]
        ] = None,
        cutoff: PythonNumber = 0.5,
        nbins: int = 9999,
    ) -> Union[float, TableSample]:
        """
        Computes a classification report
        using multiple model evaluation
        metrics (``auc``, ``accuracy``,
        ``f1``...).

        Parameters
        ----------
        metrics: list, optional
            List  of the  metrics  used to compute the  final
            report.

            - accuracy:
                Accuracy.

                .. math::

                    Accuracy = \\frac{TP + TN}{TP + TN + FP + FN}

            - aic:
                Akaike's  Information  Criterion

                .. math::

                    AIC = 2k - 2\\ln(\\hat{L})

            - auc:
                Area Under the Curve (ROC).

                .. math::

                    AUC = \\int_{0}^{1} TPR(FPR) \\, dFPR

            - ba:
                Balanced Accuracy.

                .. math::

                    BA = \\frac{TPR + TNR}{2}

            - best_cutoff:
                Cutoff  which optimised the  ROC
                Curve prediction.

            - bic:
                Bayesian  Information  Criterion

                .. math::

                    BIC = -2\\ln(\\hat{L}) + k \\ln(n)

            - bm:
                Informedness

                .. math::

                    BM = TPR + TNR - 1

            - csi:
                Critical Success Index

                .. math::

                    index = \\frac{TP}{TP + FN + FP}

            - f1:
                F1 Score

                .. math::

                    F_1 Score = 2 \\times \\frac{Precision \\times Recall}{Precision + Recall}

            - fdr:
                False Discovery Rate

                .. math::

                    FDR = 1 - PPV

            - fm:
                Fowlkes-Mallows index

                .. math::

                    FM = \\sqrt{PPV * TPR}

            - fnr:
                False Negative Rate

                .. math::

                    FNR = \\frac{FN}{FN + TP}

            - for:
                False Omission Rate

                .. math::

                    FOR = 1 - NPV

            - fpr:
                False Positive Rate

                .. math::

                    FPR = \\frac{FP}{FP + TN}

            - logloss:
                Log Loss.

                .. math::

                    Loss = -\\frac{1}{N} \\sum_{i=1}^{N} \\left( y_i \\log(p_i) + (1 - y_i) \\log(1 - p_i) \\right)

            - lr+:
                Positive Likelihood Ratio.

                .. math::

                    LR+ = \\frac{TPR}{FPR}

            - lr-:
                Negative Likelihood Ratio.

                .. math::

                    LR- = \\frac{FNR}{TNR}

            - dor:
                Diagnostic Odds Ratio.

                .. math::

                    DOR = \\frac{TP \\times TN}{FP \\times FN}

            - mc:
                Matthews Correlation Coefficient
                .. math::

                    MCC = \\frac{TP \\times TN - FP \\times FN}{\\sqrt{(TP + FP)(TP + FN)(TN + FP)(TN + FN)}}

            - mk:
                Markedness

                .. math::

                    MK = PPV + NPV - 1

            - npv:
                Negative Predictive Value

                .. math::

                    NPV = \\frac{TN}{TN + FN}

            - prc_auc:
                Area Under the Curve (PRC)

                .. math::

                    AUC = \\int_{0}^{1} Precision(Recall) \\, dRecall

            - precision:
                Precision

                .. math::

                    Precision = TP / (TP + FP)

            - pt:
                Prevalence Threshold.

                .. math::

                    threshold = \\frac{\\sqrt{FPR}}{\\sqrt{TPR} + \\sqrt{FPR}}

            - recall:
                Recall.

                .. math::
                    Recall = \\frac{TP}{TP + FN}

            - specificity:
                Specificity.

                .. math::

                    Specificity = \\frac{TN}{TN + FP}

        cutoff: PythonNumber, optional
            Probability cutoff.
        nbins: int, optional
            [Used to compute ROC AUC, PRC AUC and the best cutoff]
            An  integer  value  that   determines  the  number  of
            decision  boundaries. Decision  boundaries are set  at
            equally  spaced intervals between 0 and 1,  inclusive.
            Greater values for nbins give more precise estimations
            of   the   metrics,  but   can  potentially   decrease
            performance. The maximum value is 999,999. If negative,
            the maximum value is used.

        Returns
        -------
        TableSample
            report.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        We can get all the classification
        metrics using the ``classification_report``:

        .. ipython:: python
            :suppress:

            result = model.classification_report()
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_class_classification_report.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.classification_report()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_class_classification_report.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.classification_report(
            self.y,
            [self.deploySQL(), self.deploySQL(cutoff=cutoff)],
            self.test_relation,
            metrics=metrics,
            cutoff=cutoff,
            nbins=nbins,
        )

    report = classification_report

    def confusion_matrix(self, cutoff: PythonNumber = 0.5) -> TableSample:
        """
        Computes the model confusion matrix.

        Parameters
        ----------
        cutoff: PythonNumber, optional
            Probability cutoff.

        Returns
        -------
        TableSample
            confusion matrix.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        To get the confusion matrix:

        .. ipython:: python

            model.confusion_matrix()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.confusion_matrix(
            self.y,
            self.deploySQL(cutoff=cutoff),
            self.test_relation,
        )

    def score(
        self,
        metric: Literal[tuple(mt.FUNCTIONS_CLASSIFICATION_DICTIONNARY)] = "accuracy",
        cutoff: PythonNumber = 0.5,
        nbins: int = 9999,
    ) -> float:
        """
        Computes the model score.

        Parameters
        ----------
        metric: str, optional
            The metric used to compute the score.

            - accuracy:
                Accuracy.

                .. math::

                    Accuracy = \\frac{TP + TN}{TP + TN + FP + FN}

            - aic:
                Akaike's  Information  Criterion

                .. math::

                    AIC = 2k - 2\\ln(\\hat{L})

            - auc:
                Area Under the Curve (ROC).

                .. math::

                    AUC = \\int_{0}^{1} TPR(FPR) \\, dFPR

            - ba:
                Balanced Accuracy.

                .. math::

                    BA = \\frac{TPR + TNR}{2}

            - best_cutoff:
                Cutoff  which optimised the  ROC
                Curve prediction.

            - bic:
                Bayesian  Information  Criterion

                .. math::

                    BIC = -2\\ln(\\hat{L}) + k \\ln(n)

            - bm:
                Informedness

                .. math::

                    BM = TPR + TNR - 1

            - csi:
                Critical Success Index

                .. math::

                    index = \\frac{TP}{TP + FN + FP}

            - f1:
                F1 Score

                .. math::

                    F_1 Score = 2 \\times \\frac{Precision \\times Recall}{Precision + Recall}

            - fdr:
                False Discovery Rate

                .. math::

                    FDR = 1 - PPV

            - fm:
                Fowlkes-Mallows index

                .. math::

                    FM = \\sqrt{PPV * TPR}

            - fnr:
                False Negative Rate

                .. math::

                    FNR = \\frac{FN}{FN + TP}

            - for:
                False Omission Rate

                .. math::

                    FOR = 1 - NPV

            - fpr:
                False Positive Rate

                .. math::

                    FPR = \\frac{FP}{FP + TN}

            - logloss:
                Log Loss.

                .. math::

                    Loss = -\\frac{1}{N} \\sum_{i=1}^{N} \\left( y_i \\log(p_i) + (1 - y_i) \\log(1 - p_i) \\right)

            - lr+:
                Positive Likelihood Ratio.

                .. math::

                    LR+ = \\frac{TPR}{FPR}

            - lr-:
                Negative Likelihood Ratio.

                .. math::

                    LR- = \\frac{FNR}{TNR}

            - dor:
                Diagnostic Odds Ratio.

                .. math::

                    DOR = \\frac{TP \\times TN}{FP \\times FN}

            - mc:
                Matthews Correlation Coefficient
                .. math::

                    MCC = \\frac{TP \\times TN - FP \\times FN}{\\sqrt{(TP + FP)(TP + FN)(TN + FP)(TN + FN)}}

            - mk:
                Markedness

                .. math::

                    MK = PPV + NPV - 1

            - npv:
                Negative Predictive Value

                .. math::

                    NPV = \\frac{TN}{TN + FN}

            - prc_auc:
                Area Under the Curve (PRC)

                .. math::

                    AUC = \\int_{0}^{1} Precision(Recall) \\, dRecall

            - precision:
                Precision

                .. math::

                    Precision = TP / (TP + FP)

            - pt:
                Prevalence Threshold.

                .. math::

                    threshold = \\frac{\\sqrt{FPR}}{\\sqrt{TPR} + \\sqrt{FPR}}

            - recall:
                Recall.

                .. math::
                    Recall = \\frac{TP}{TP + FN}

            - specificity:
                Specificity.

                .. math::

                    Specificity = \\frac{TN}{TN + FP}

        cutoff: PythonNumber, optional
            Cutoff for which the tested category will be
            accepted as a prediction.
        nbins: int, optional
            [Only  when  method  is set  to  auc|prc_auc|best_cutoff]
            An  integer value that determines the number of  decision
            boundaries. Decision boundaries are set at equally spaced
            intervals between 0 and 1,  inclusive. Greater values for
            nbins give more precise  estimations of the AUC,  but can
            potentially  decrease performance.  The maximum value  is
            999,999. If negative, the maximum value is used.

        Returns
        -------
        float
            score

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        To get the score:

        .. ipython:: python

            model.score()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        fun = mt.FUNCTIONS_CLASSIFICATION_DICTIONNARY[metric]
        if metric in (
            "log_loss",
            "logloss",
            "aic",
            "bic",
            "auc",
            "roc_auc",
            "prc_auc",
            "best_cutoff",
            "best_threshold",
        ):
            args2 = self.deploySQL()
        else:
            args2 = self.deploySQL(cutoff=cutoff)
        args = [self.y, args2, self.test_relation]
        kwargs = {}
        if metric in mt.FUNCTIONS_CLASSIFICATION_DICTIONNARY and (
            metric not in ("aic", "bic")
        ):
            kwargs["pos_label"] = 1
        if metric in ("aic", "bic"):
            args += [len(self.X)]
        elif metric in ("auc", "roc_auc", "prc_auc", "best_cutoff", "best_threshold"):
            kwargs["nbins"] = nbins
        return fun(*args, **kwargs)

    # Prediction / Transformation Methods.

    def predict(
        self,
        vdf: SQLRelation,
        X: Optional[SQLColumns] = None,
        name: Optional[str] = None,
        cutoff: PythonNumber = 0.5,
        inplace: bool = True,
    ) -> VastFrame:
        """
        Makes predictions on the input relation.

        Parameters
        ----------
        vdf: SQLRelation
            Object used to run  the prediction.  You can
            also  specify a  customized  relation,  but you
            must  enclose  it with an alias.  For  example,
            ``(SELECT 1) x`` is valid, whereas ``(SELECT 1)``
            and "SELECT 1" are invalid.
        X: SQLColumns, optional
            List of the columns  used to deploy the models.
            If empty, the model predictors are used.
        name: str, optional
            Name of the added VastColumn. If empty, a name
            is generated.
        cutoff: float, optional
            Probability cutoff.
        inplace: bool, optional
            If set to True, the prediction is added to
            the VastFrame.

        Returns
        -------
        VastFrame
            the input object.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        .. code-block:: python

            train, test = data.train_test_split(test_size = 0.5)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.5)

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        .. ipython:: python
            :suppress:

            result = model.predict(
                test,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "prediction",
            )
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_prediction.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.predict(
                test,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "prediction",
            )

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_prediction.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        # Inititalization
        X = format_type(X, dtype=list, na_out=self.X)
        if not 0 <= cutoff <= 1:
            raise ValueError(
                "Incorrect parameter 'cutoff'.\nThe cutoff "
                "must be between 0 and 1, inclusive."
            )
        if isinstance(vdf, str):
            vdf = VastFrame(vdf)
            inplace = True
        X = quote_ident(X)
        if not name:
            name = gen_name([self._model_type, self.model_name])

        # In Place
        vdf_return = vdf if inplace else vdf.copy()

        # Result
        return vdf_return.eval(name, self.deploySQL(X=X, cutoff=cutoff))

    def predict_proba(
        self,
        vdf: SQLRelation,
        X: Optional[SQLColumns] = None,
        name: Optional[str] = None,
        pos_label: Optional[PythonScalar] = None,
        inplace: bool = True,
    ) -> VastFrame:
        """
        Returns the model's  probabilities  using the input
        relation.

        Parameters
        ----------
        vdf: SQLRelation
            Object  used to run  the prediction.  You can
            also  specify a  customized  relation,  but you
            must  enclose  it with an alias.  For  example,
            ``(SELECT 1) x`` is valid, whereas ``(SELECT 1)``
            and "SELECT 1" are invalid.
        X: SQLColumns, optional
            List of the columns  used to deploy the models.
            If empty, the model predictors are used.
        name: str, optional
            Name of the added VastColumn. If empty, a name
            is generated.
        pos_label: PythonScalar, optional
            Class  label.  For binary classification,  this
            can be either 1 or 0.
        inplace: bool, optional
            If set to True, the prediction is added to
            the VastFrame.

        Returns
        -------
        VastFrame
            the input object.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        .. code-block:: python

            train, test = data.train_test_split(test_size = 0.5)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.5)

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        .. ipython:: python
            :suppress:

            result = model.predict_proba(
                test,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "prediction",
            )
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_prediction.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.predict_proba(
                test,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "prediction",
            )

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_prediction.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        # Inititalization
        X = format_type(X, dtype=list, na_out=self.X)
        if pos_label not in [1, 0, "0", "1", None]:
            raise ValueError(
                "Incorrect parameter 'pos_label'.\nThe class label "
                "can only be 1 or 0 in case of Binary Classification."
            )
        if isinstance(vdf, str):
            vdf = VastFrame(vdf)
            inplace = True
        X = quote_ident(X)
        if not name:
            name = gen_name([self._model_type, self.model_name])

        # In Place
        vdf_return = vdf if inplace else vdf.copy()

        # Result
        name_tmp = name
        if pos_label in [0, "0", None]:
            if isinstance(pos_label, NoneType):
                name_tmp = f"{name}_0"
            vdf_return.eval(name_tmp, f"1 - {self.deploySQL(X=X)}")
        if pos_label in [1, "1", None]:
            if isinstance(pos_label, NoneType):
                name_tmp = f"{name}_1"
            vdf_return.eval(name_tmp, self.deploySQL(X=X))

        return vdf_return

    # Plotting Methods.

    def cutoff_curve(
        self,
        nbins: int = 30,
        show: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> TableSample:
        """
        Draws the model Cutoff curve.

        Parameters
        ----------
        nbins: int, optional
            The number of bins.
        show: bool, optional
            If set to True,  the  Plotting
            object is returned.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        TableSample
            cutoff curve data points.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                data,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        To get the cutoff curve:

        .. code-block:: python

            model.cutoff_curve()

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.cutoff_curve()
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_roc.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_roc.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.roc_curve(
            self.y,
            self.deploySQL(),
            self.test_relation,
            nbins=nbins,
            cutoff_curve=True,
            show=show,
            chart=chart,
            **style_kwargs,
        )

    def lift_chart(
        self,
        nbins: int = 1000,
        show: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> TableSample:
        """
        Draws the model Lift Chart.

        Parameters
        ----------
        nbins: int, optional
            The number of bins.
        show: bool, optional
            If set to True,  the  Plotting
            object  is returned.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        TableSample
                lift chart data points.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                data,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        To get the Lift chart:

        .. code-block:: python

            model.lift_chart()

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.lift_chart()
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_lift_chart.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_lift_chart.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.lift_chart(
            self.y,
            self.deploySQL(),
            self.test_relation,
            nbins=nbins,
            show=show,
            chart=chart,
            **style_kwargs,
        )

    def prc_curve(
        self,
        nbins: int = 30,
        show: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> TableSample:
        """
        Draws the model PRC curve.

        Parameters
        ----------
        nbins: int, optional
            The number of bins.
        show: bool, optional
            If set to True,  the  Plotting
            object  is returned.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        TableSample
                PRC curve data points.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                data,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        To get the PRC curve:

        .. code-block:: python

            model.prc_curve()

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.prc_curve()
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_prc_curve.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_prc_curve.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.prc_curve(
            self.y,
            self.deploySQL(),
            self.test_relation,
            nbins=nbins,
            show=show,
            chart=chart,
            **style_kwargs,
        )

    def roc_curve(
        self,
        nbins: int = 30,
        show: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> TableSample:
        """
        Draws the model ROC curve.

        Parameters
        ----------
        nbins: int, optional
            The number of bins.
        show: bool, optional
            If set to True,  the  Plotting
            object  is returned.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        TableSample
            ROC curve data points.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import LogisticRegression

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = LogisticRegression(
                tol = 1e-6,
                max_iter = 100,
                solver = 'lbfgs',
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                data,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "good",
                test,
            )

        To get the ROC curve:

        .. code-block:: python

            model.roc_curve()

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.roc_curve()
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_roc_curve.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_roc_curve.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.roc_curve(
            self.y,
            self.deploySQL(),
            self.test_relation,
            nbins=nbins,
            show=show,
            chart=chart,
            **style_kwargs,
        )


class MulticlassClassifier(Supervised):
    """
    Base Class for VAST Multiclass Classifiers.
    """

    # System & Special Methods.

    def _check_pos_label(self, pos_label: PythonScalar) -> PythonScalar:
        """
        Checks if the pos_label is correct.
        """
        if isinstance(pos_label, NoneType) and self._is_binary_classifier():
            # Default to the actual positive class (the second sorted class),
            # not a hardcoded 1 — binary responses are not always labelled {0,1}
            # (e.g. {2,4} or string labels), and a literal 1 would then fail the
            # class-membership check on the re-validation in _get_sql_plot.
            return self.classes_[1]
        if isinstance(pos_label, NoneType):
            return None
        if str(pos_label) not in [str(c) for c in self.classes_]:
            raise ValueError(
                "Parameter 'pos_label' must be one of the response column classes."
            )
        return pos_label

    # Attributes Methods.

    def _get_classes(self) -> np.ndarray:
        """
        Returns the model's classes.
        """
        classes = _executeSQL(
            query=f"""
                SELECT 
                    /*+LABEL('learn.VASTModel.fit')*/ 
                    DISTINCT {self.y} 
                FROM {self.input_relation} 
                WHERE {self.y} IS NOT NULL 
                ORDER BY 1""",
            method="fetchall",
            print_time_sql=False,
        )
        classes = np.array([c[0] for c in classes])
        return self._array_to_int(classes)

    def _is_binary_classifier(self) -> bool:
        """
        Returns ``True`` if the
        model is a ``BinaryClassifier``.
        """
        if len(self.classes_) == 2 and self.classes_[0] == 0 and self.classes_[1] == 1:
            return True
        return False

    # I/O Methods.

    def deploySQL(
        self,
        X: Optional[SQLColumns] = None,
        pos_label: Optional[PythonScalar] = None,
        cutoff: Optional[PythonNumber] = None,
        allSQL: bool = False,
    ) -> SQLExpression:
        """
        Returns the SQL code needed to deploy the model.

        Parameters
        ----------
        X: SQLColumns, optional
            List of the columns used to deploy the model.
            If empty, the model predictors are used.
        pos_label: PythonScalar, optional
            Label to consider as positive. All the other
            classes  are  merged and  considered  as
            negative for multiclass classification.
        cutoff: PythonNumber, optional
            Cutoff for which the tested category will be
            accepted  as a prediction. If the cutoff  is
            not  between 0 and 1,  a probability is
            returned.
        allSQL: bool, optional
            If set to True, the output is a list of
            the different SQL codes needed to deploy the
            different categories score.

        Returns
        -------
        SQLExpression
            the SQL code needed to deploy the model.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import RandomForestClassifier

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = RandomForestClassifier(n_estimators = 5)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        To get the Model VAST
        SQL, use below:

        .. ipython:: python

            model.deploySQL()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        X = format_type(X, dtype=list, na_out=self.X)
        X = quote_ident(X)
        sql = self.to_memmodel().predict_proba_sql(X)
        if not allSQL:
            if pos_label in list(self.classes_):
                if not self._is_native:
                    sql = sql[self.get_match_index(pos_label, self.classes_, False)]
                else:
                    sql = sql[0].format(pos_label)
                if isinstance(cutoff, (int, float)) and 0.0 <= cutoff <= 1.0:
                    q = ""
                    if isinstance(pos_label, str):
                        q = "'"
                    sql = f"""
                        (CASE 
                            WHEN {sql} >= {cutoff} 
                                THEN {q}{pos_label}{q}
                            WHEN {sql} IS NULL 
                                THEN NULL 
                            ELSE {{}}
                        END)"""
                    if len(self.classes_) > 2:
                        sql = sql.format(f"'Non-{pos_label}'")
                    else:
                        if self.classes_[0] != pos_label:
                            non_pos_label = self.classes_[0]
                        else:
                            non_pos_label = self.classes_[1]
                        if isinstance(non_pos_label, str):
                            non_pos_label = f"'{non_pos_label}'"
                        sql = sql.format(non_pos_label)
            else:
                sql = self.to_memmodel().predict_sql(X)
        return clean_query(sql)

    # Model Evaluation Methods.

    def _get_final_relation(
        self,
        pos_label: Optional[PythonScalar] = None,
    ) -> str:
        """
        Returns  the  final  relation  used to do  the
        predictions.
        """
        return self.test_relation

    def _get_y_proba(
        self,
        pos_label: Optional[PythonScalar] = None,
    ) -> str:
        """
        Returns the input which represents the  model's
        probabilities.
        """
        return self.deploySQL(allSQL=True)[0].format(pos_label)

    def _get_y_score(
        self,
        pos_label: Optional[PythonScalar] = None,
        cutoff: Optional[PythonNumber] = None,
        allSQL: bool = False,
    ) -> str:
        """
        Returns  the input which represents the model's
        scoring.
        """
        return self.deploySQL(pos_label=pos_label, cutoff=cutoff, allSQL=allSQL)

    def classification_report(
        self,
        metrics: Union[
            None, str, list[Literal[tuple(mt.FUNCTIONS_CLASSIFICATION_DICTIONNARY)]]
        ] = None,
        cutoff: PythonNumber = None,
        labels: Union[None, str, list[str]] = None,
        nbins: int = 9999,
    ) -> Union[float, TableSample]:
        """
        Computes a classification report using multiple model
        evaluation metrics (``auc``, ``accuracy``, ``f1``...).
        For  multiclass classification,  it considers  each
        category as positive and switches to the next one during
        the computation.

        Parameters
        ----------
        metrics: list, optional
            List of  the metrics  used to compute the  final
            report.

            - accuracy:
                Accuracy.

                .. math::

                    Accuracy = \\frac{TP + TN}{TP + TN + FP + FN}

            - aic:
                Akaike's  Information  Criterion

                .. math::

                    AIC = 2k - 2\\ln(\\hat{L})

            - auc:
                Area Under the Curve (ROC).

                .. math::

                    AUC = \\int_{0}^{1} TPR(FPR) \\, dFPR

            - ba:
                Balanced Accuracy.

                .. math::

                    BA = \\frac{TPR + TNR}{2}

            - best_cutoff:
                Cutoff  which optimised the  ROC
                Curve prediction.

            - bic:
                Bayesian  Information  Criterion

                .. math::

                    BIC = -2\\ln(\\hat{L}) + k \\ln(n)

            - bm:
                Informedness

                .. math::

                    BM = TPR + TNR - 1

            - csi:
                Critical Success Index

                .. math::

                    index = \\frac{TP}{TP + FN + FP}

            - f1:
                F1 Score

                .. math::

                    F_1 Score = 2 \\times \\frac{Precision \\times Recall}{Precision + Recall}

            - fdr:
                False Discovery Rate

                .. math::

                    FDR = 1 - PPV

            - fm:
                Fowlkes-Mallows index

                .. math::

                    FM = \\sqrt{PPV * TPR}

            - fnr:
                False Negative Rate

                .. math::

                    FNR = \\frac{FN}{FN + TP}

            - for:
                False Omission Rate

                .. math::

                    FOR = 1 - NPV

            - fpr:
                False Positive Rate

                .. math::

                    FPR = \\frac{FP}{FP + TN}

            - logloss:
                Log Loss.

                .. math::

                    Loss = -\\frac{1}{N} \\sum_{i=1}^{N} \\left( y_i \\log(p_i) + (1 - y_i) \\log(1 - p_i) \\right)

            - lr+:
                Positive Likelihood Ratio.

                .. math::

                    LR+ = \\frac{TPR}{FPR}

            - lr-:
                Negative Likelihood Ratio.

                .. math::

                    LR- = \\frac{FNR}{TNR}

            - dor:
                Diagnostic Odds Ratio.

                .. math::

                    DOR = \\frac{TP \\times TN}{FP \\times FN}

            - mc:
                Matthews Correlation Coefficient
                .. math::

                    MCC = \\frac{TP \\times TN - FP \\times FN}{\\sqrt{(TP + FP)(TP + FN)(TN + FP)(TN + FN)}}

            - mk:
                Markedness

                .. math::

                    MK = PPV + NPV - 1

            - npv:
                Negative Predictive Value

                .. math::

                    NPV = \\frac{TN}{TN + FN}

            - prc_auc:
                Area Under the Curve (PRC)

                .. math::

                    AUC = \\int_{0}^{1} Precision(Recall) \\, dRecall

            - precision:
                Precision

                .. math::

                    Precision = TP / (TP + FP)

            - pt:
                Prevalence Threshold.

                .. math::

                    threshold = \\frac{\\sqrt{FPR}}{\\sqrt{TPR} + \\sqrt{FPR}}

            - recall:
                Recall.

                .. math::
                    Recall = \\frac{TP}{TP + FN}

            - specificity:
                Specificity.

                .. math::

                    Specificity = \\frac{TN}{TN + FP}

        cutoff: PythonNumber, optional
            Cutoff for which the tested category is accepted
            as a prediction.  For multiclass  classification, each
            tested category becomes  the positives  and the others
            are  merged  into  the   negatives.  The  cutoff
            represents the classes  threshold.  If  it  is  empty,
            the  regular  cutoff (1 / number of classes) is used.
        labels: str | list, optional
            List  of the  different  labels to be used during  the
            computation.
        nbins: int, optional
            [Used to compute ROC AUC, PRC AUC and the best cutoff]
            An  integer  value  that   determines  the  number  of
            decision  boundaries.  Decision boundaries are set  at
            equally spaced intervals  between 0 and 1,  inclusive.
            Greater values for nbins give more precise estimations
            of   the  metrics,   but   can  potentially   decrease
            performance.
            The maximum value is 999,999. If negative, the maximum
            value is used.

        Returns
        -------
        TableSample
            report.

        Examples
        --------
        For this example, we will
        use the Iris dataset.

        .. ipython:: python

            import vastorbit.datasets as vod
            data = vod.load_iris()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "SepalLengthCm",
                    "SepalWidthCm",
                    "PetalLengthCm",
                    "PetalWidthCm",
                ],
                "Species",
                test,
            )

        We can get all the classification
        metrics using the ``classification_report``:

        .. ipython:: python
            :suppress:

            result = model.classification_report()
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_class_classification_report.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.classification_report()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_class_classification_report.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        if isinstance(labels, NoneType):
            labels = self.classes_
        elif isinstance(labels, str):
            labels = [labels]
        return mt.classification_report(
            estimator=self,
            metrics=metrics,
            labels=labels,
            cutoff=cutoff,
            nbins=nbins,
        )

    report = classification_report

    def confusion_matrix(
        self,
        pos_label: Optional[PythonScalar] = None,
        cutoff: Optional[PythonNumber] = None,
    ) -> TableSample:
        """
        Computes the model confusion matrix.

        Parameters
        ----------
        pos_label: PythonScalar, optional
            Label  to consider  as positive.  All the other  classes
            are merged and considered as negative for multiclass
            classification.  If  the 'pos_label' is not defined, the
            entire confusion matrix is drawn.
        cutoff: PythonNumber, optional
            Cutoff for which the tested category is accepted as
            a prediction. It is only used if 'pos_label' is defined.

        Returns
        -------
        TableSample
            confusion matrix.

        Examples
        --------
        For this example, we will
        use the Iris dataset.

        .. ipython:: python

            import vastorbit.datasets as vod
            data = vod.load_iris()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "SepalLengthCm",
                    "SepalWidthCm",
                    "PetalLengthCm",
                    "PetalWidthCm",
                ],
                "Species",
                test,
            )

        We can get the confusion matrix:

        .. ipython:: python

            model.confusion_matrix()

        To get the confusion matrix of a particular
        class:

        .. ipython:: python

            model.confusion_matrix(pos_label= "Iris-setosa")

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        if hasattr(self, "_confusion_matrix"):
            return self._confusion_matrix(
                pos_label=pos_label,
                cutoff=cutoff,
            )
        elif isinstance(pos_label, NoneType):
            return mt.confusion_matrix(
                self.y, self.deploySQL(), self.test_relation, labels=self.classes_
            )
        else:
            pos_label = self._check_pos_label(pos_label=pos_label)
            if isinstance(cutoff, NoneType):
                cutoff = 1.0 / len(self.classes_)
            return mt.confusion_matrix(
                self.y,
                self.deploySQL(pos_label=pos_label, cutoff=cutoff),
                self.test_relation,
                pos_label=pos_label,
            )

    def score(
        self,
        metric: Literal[tuple(mt.FUNCTIONS_CLASSIFICATION_DICTIONNARY)] = "accuracy",
        average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
        pos_label: Optional[PythonScalar] = None,
        cutoff: PythonNumber = 0.5,
        nbins: int = 9999,
    ) -> Union[float, list[float]]:
        """
        Computes the model score.

        Parameters
        ----------
        metric: str, optional
            The metric used to compute the score.

            - accuracy:
                Accuracy.

                .. math::

                    Accuracy = \\frac{TP + TN}{TP + TN + FP + FN}

            - aic:
                Akaike's  Information  Criterion

                .. math::

                    AIC = 2k - 2\\ln(\\hat{L})

            - auc:
                Area Under the Curve (ROC).

                .. math::

                    AUC = \\int_{0}^{1} TPR(FPR) \\, dFPR

            - ba:
                Balanced Accuracy.

                .. math::

                    BA = \\frac{TPR + TNR}{2}

            - best_cutoff:
                Cutoff  which optimised the  ROC
                Curve prediction.

            - bic:
                Bayesian  Information  Criterion

                .. math::

                    BIC = -2\\ln(\\hat{L}) + k \\ln(n)

            - bm:
                Informedness

                .. math::

                    BM = TPR + TNR - 1

            - csi:
                Critical Success Index

                .. math::

                    index = \\frac{TP}{TP + FN + FP}

            - f1:
                F1 Score

                .. math::

                    F_1 Score = 2 \\times \\frac{Precision \\times Recall}{Precision + Recall}

            - fdr:
                False Discovery Rate

                .. math::

                    FDR = 1 - PPV

            - fm:
                Fowlkes-Mallows index

                .. math::

                    FM = \\sqrt{PPV * TPR}

            - fnr:
                False Negative Rate

                .. math::

                    FNR = \\frac{FN}{FN + TP}

            - for:
                False Omission Rate

                .. math::

                    FOR = 1 - NPV

            - fpr:
                False Positive Rate

                .. math::

                    FPR = \\frac{FP}{FP + TN}

            - logloss:
                Log Loss.

                .. math::

                    Loss = -\\frac{1}{N} \\sum_{i=1}^{N} \\left( y_i \\log(p_i) + (1 - y_i) \\log(1 - p_i) \\right)

            - lr+:
                Positive Likelihood Ratio.

                .. math::

                    LR+ = \\frac{TPR}{FPR}

            - lr-:
                Negative Likelihood Ratio.

                .. math::

                    LR- = \\frac{FNR}{TNR}

            - dor:
                Diagnostic Odds Ratio.

                .. math::

                    DOR = \\frac{TP \\times TN}{FP \\times FN}

            - mc:
                Matthews Correlation Coefficient
                .. math::

                    MCC = \\frac{TP \\times TN - FP \\times FN}{\\sqrt{(TP + FP)(TP + FN)(TN + FP)(TN + FN)}}

            - mk:
                Markedness

                .. math::

                    MK = PPV + NPV - 1

            - npv:
                Negative Predictive Value

                .. math::

                    NPV = \\frac{TN}{TN + FN}

            - prc_auc:
                Area Under the Curve (PRC)

                .. math::

                    AUC = \\int_{0}^{1} Precision(Recall) \\, dRecall

            - precision:
                Precision

                .. math::

                    Precision = TP / (TP + FP)

            - pt:
                Prevalence Threshold.

                .. math::

                    threshold = \\frac{\\sqrt{FPR}}{\\sqrt{TPR} + \\sqrt{FPR}}

            - recall:
                Recall.

                .. math::
                    Recall = \\frac{TP}{TP + FN}

            - specificity:
                Specificity.

                .. math::

                    Specificity = \\frac{TN}{TN + FP}

        average: str, optional
            The method used to  compute the final score for
            multiclass-classification.

            - binary:
                considers one of the classes  as
                positive  and  use  the   binary
                confusion  matrix to compute the
                score.
            - micro:
                positive  and   negative  values
                globally.
            - macro:
                average  of  the  score of  each
                class.
            - scores:
                scores  for   all  the  classes.
            - weighted:
                weighted average of the score of
                each class.

            If empty,  the result will depend on the  input
            metric.  Whenever  it  is  possible, the  exact
            score is computed.  Otherwise, the behaviour is
            similar to the 'scores' option.
        pos_label: PythonScalar, optional
            Label  to  consider   as  positive.  All the
            other classes will be  merged and considered
            as negative  for multiclass  classification.
        cutoff: PythonNumber, optional
            Cutoff for which the tested category is
            accepted as a prediction.
        nbins: int, optional
            [Only  when  method  is set  to  auc|prc_auc|best_cutoff]
            An  integer value that determines the number of  decision
            boundaries. Decision boundaries are set at equally spaced
            intervals between 0 and 1,  inclusive. Greater values for
            nbins give more precise  estimations of the AUC,  but can
            potentially  decrease performance.  The maximum value  is
            999,999. If negative, the maximum value is used.

        Returns
        -------
        float
            score.

        Examples
        --------
        For this example, we will
        use the Iris dataset.

        .. ipython:: python

            import vastorbit.datasets as vod
            data = vod.load_iris()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "SepalLengthCm",
                    "SepalWidthCm",
                    "PetalLengthCm",
                    "PetalWidthCm",
                ],
                "Species",
                test,
            )

        We can get the score:

        .. ipython:: python

            model.score()

        To get the score of a particular
        class:

        .. ipython:: python

            model.score(pos_label= "Iris-setosa")

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        fun = mt.FUNCTIONS_CLASSIFICATION_DICTIONNARY[metric]
        pos_label = self._check_pos_label(pos_label=pos_label)
        if metric in (
            "auc",
            "roc_auc",
            "prc_auc",
            "best_cutoff",
            "best_threshold",
            "logloss",
            "log_loss",
        ):
            if self._model_type == "KNeighborsClassifier":
                y_score = self._get_y_score(
                    pos_label=pos_label, cutoff=cutoff, allSQL=True
                )
            else:
                y_score = self._get_y_score(allSQL=True)
        else:
            y_score = self._get_y_score(pos_label=pos_label, cutoff=cutoff)
        final_relation = self._get_final_relation(pos_label=pos_label)
        args = [self.y, y_score, final_relation]
        kwargs = {}
        if metric not in ("aic", "bic"):
            # Always provide the class labels: ``_get_yscore`` needs them to map
            # ``pos_label`` to the correct per-class score column when the score
            # vector has more than two entries (multiclass). Nulling ``labels``
            # for native models with a set ``pos_label`` made that mapping
            # impossible and raised "Wrong parameter 'y_score'".
            labels = self.classes_
            kwargs = {
                "average": average,
                "labels": labels,
                "pos_label": pos_label,
            }
        if metric in ("aic", "bic"):
            args += [len(self.X)]
        elif metric in ("auc", "roc_auc", "prc_auc", "best_cutoff", "best_threshold"):
            kwargs["nbins"] = nbins
        return fun(*args, **kwargs)

    # Prediction / Transformation Methods.

    def predict(
        self,
        vdf: SQLRelation,
        X: Optional[SQLColumns] = None,
        name: Optional[str] = None,
        cutoff: Optional[PythonNumber] = None,
        inplace: bool = True,
    ) -> VastFrame:
        """
        Predicts using the input relation.

        Parameters
        ----------
        vdf: SQLRelation
            Object  used to run  the prediction.  You can
            also  specify a  customized  relation,  but you
            must  enclose  it with an alias.  For  example,
            ``(SELECT 1) x`` is valid, whereas ``(SELECT 1)``
            and "SELECT 1" are invalid.
        X: SQLColumns, optional
            List of the columns  used to deploy the models.
            If empty, the model predictors are used.
        name: str, optional
            Name of the added VastColumn. If empty, a name
            is generated.
        cutoff: PythonNumber, optional
            Cutoff  for which  the tested category is
            accepted  as a  prediction.  This parameter  is
            only used for binary classification.
        inplace: bool, optional
            If set to True, the prediction is added to
            the VastFrame.

        Returns
        -------
        VastFrame
            the input object.

        Examples
        --------
        For this example, we will
        use the Iris dataset.

        .. ipython:: python

            import vastorbit.datasets as vod
            data = vod.load_iris()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "SepalLengthCm",
                    "SepalWidthCm",
                    "PetalLengthCm",
                    "PetalWidthCm",
                ],
                "Species",
                test,
            )

        We can then get the prediction:

        .. ipython:: python
            :suppress:

            result = model.predict(test, name = "prediction")
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_class_predict.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.predict(test, name = "prediction"

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_class_predict.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        # Using special method in case of non-native models
        if hasattr(self, "_predict"):
            return self._predict(
                vdf=vdf, X=X, name=name, cutoff=cutoff, inplace=inplace
            )

        # Inititalization
        X = format_type(X, dtype=list, na_out=self.X)
        X = quote_ident(X)
        if not name:
            name = gen_name([self._model_type, self.model_name])
        if isinstance(cutoff, NoneType):
            cutoff = 1.0 / len(self.classes_)
        elif not 0 <= cutoff <= 1:
            raise ValueError(
                "Incorrect parameter 'cutoff'.\nThe cutoff "
                "must be between 0 and 1, inclusive."
            )
        if isinstance(vdf, str):
            vdf = VastFrame(vdf)
            inplace = True

        # In Place
        vdf_return = vdf if inplace else vdf.copy()

        # Check if it is a Binary Classifier
        pos_label = None
        if (
            len(self.classes_) == 2
            and self.classes_[0] in [0, "0"]
            and self.classes_[1] in [1, "1"]
        ):
            pos_label = 1

        # Result
        return vdf_return.eval(
            name, self.deploySQL(X=X, pos_label=pos_label, cutoff=cutoff)
        )

    def predict_proba(
        self,
        vdf: SQLRelation,
        X: Optional[SQLColumns] = None,
        name: Optional[str] = None,
        pos_label: Optional[PythonScalar] = None,
        inplace: bool = True,
    ) -> VastFrame:
        """
        Returns the model's probabilities using the input
        relation.

        Parameters
        ----------
        vdf: SQLRelation
            Object  used to run  the prediction.  You can
            also  specify a  customized  relation,  but you
            must  enclose  it with an alias.  For  example,
            ``(SELECT 1) x`` is valid, whereas ``(SELECT 1)``
            and "SELECT 1" are invalid.
        X: SQLColumns, optional
            List of the columns  used to deploy the models.
            If empty, the model predictors are used.
        name: str, optional
            Name of the added VastColumn. If empty, a name
            is generated.
        pos_label: PythonScalar, optional
            Class  label.  For binary classification,  this
            can be either 1 or 0.
        inplace: bool, optional
            If set to True, the prediction is added to
            the VastFrame.

        Returns
        -------
        VastFrame
            the input object.

        Examples
        --------
        For this example, we will
        use the Iris dataset.

        .. ipython:: python

            import vastorbit.datasets as vod
            data = vod.load_iris()
            train, test = data.train_test_split(test_size = 0.2)

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                train,
                [
                    "SepalLengthCm",
                    "SepalWidthCm",
                    "PetalLengthCm",
                    "PetalWidthCm",
                ],
                "Species",
                test,
            )

        We can then get the prediction:

        .. ipython:: python
            :suppress:

            result = model.predict_proba(test, name = "prediction")
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_class_predict.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.predict_proba(test, name = "prediction"

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_class_predict.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        if hasattr(self, "_predict_proba"):
            return self._predict_proba(
                vdf=vdf,
                X=X,
                name=name,
                pos_label=pos_label,
                inplace=inplace,
            )
        # Inititalization
        X = format_type(X, dtype=list, na_out=self.X)
        X = quote_ident(X)
        assert pos_label is None or pos_label in self.classes_, ValueError(
            "Incorrect parameter 'pos_label'.\nThe class label "
            f"must be in [{'|'.join([str(c) for c in self.classes_])}]. "
            f"Found '{pos_label}'."
        )
        if isinstance(vdf, str):
            vdf = VastFrame(vdf)
            inplace = True
        if not name:
            name = gen_name([self._model_type, self.model_name])

        # In Place
        vdf_return = vdf if inplace else vdf.copy()

        # Result
        if isinstance(pos_label, NoneType):
            for c in self.classes_:
                name_tmp = gen_name([name, c])
                vdf_return.eval(name_tmp, self.deploySQL(pos_label=c, cutoff=None, X=X))
        else:
            vdf_return.eval(name, self.deploySQL(pos_label=pos_label, cutoff=None, X=X))

        return vdf_return

    # Plotting Methods.

    def _get_sql_plot(self, pos_label: PythonScalar) -> str:
        """
        Returns the SQL needed to draw the plot.
        """
        pos_label = self._check_pos_label(pos_label)
        if not self._is_native:
            return self.deploySQL(allSQL=True)[
                self.get_match_index(pos_label, self.classes_, False)
            ]
        else:
            return self.deploySQL(allSQL=True)[0].format(pos_label)

    def _get_plot_args(
        self, pos_label: Optional[PythonScalar] = None, method: Optional[str] = None
    ) -> list:
        """
        Returns the args used by plotting methods.
        """
        pos_label = self._check_pos_label(pos_label)
        if method == "contour":
            args = [
                self.X,
                self.deploySQL(X=self.X, pos_label=pos_label),
            ]
        else:
            args = [
                self.y,
                self._get_sql_plot(pos_label),
                self.test_relation,
                pos_label,
            ]
        return args

    def _get_plot_kwargs(
        self,
        pos_label: Optional[PythonScalar] = None,
        nbins: int = 30,
        chart: Optional[PlottingObject] = None,
        method: Optional[str] = None,
    ) -> dict:
        """
        Returns the kwargs used by plotting methods.
        """
        pos_label = self._check_pos_label(pos_label)
        res = {"nbins": nbins, "chart": chart}
        if method == "contour":
            res["func_name"] = f"p({self.y} = '{pos_label}')"
        elif method == "cutoff":
            res["cutoff_curve"] = True
        return res

    def contour(
        self,
        pos_label: Optional[PythonScalar] = None,
        nbins: int = 100,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> PlottingObject:
        """
        Draws the model's contour plot.

        Parameters
        ----------
        pos_label: PythonScalar, optional
            To draw the contour plot,
            one of the response column
            classes must be the positive
            class. The parameter ``pos_label``
            represents this class.
        nbins: int, optional
            Number of bins used to discretize
            the two predictors.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        obj
            Plotting Object.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                data,
                [
                    "fixed_acidity",
                    "pH",
                ],
                "quality",
            )

        To get the contour plot:

        .. code-block:: python

            model.contour(pos_label = 6)

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.contour(pos_label = 6)
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_contour.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_binary_classifier_contour.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        pos_label = self._check_pos_label(pos_label=pos_label)
        return VastFrame(self.input_relation).contour(
            *self._get_plot_args(pos_label=pos_label, method="contour"),
            **self._get_plot_kwargs(
                pos_label=pos_label, nbins=nbins, chart=chart, method="contour"
            ),
            **style_kwargs,
        )

    def cutoff_curve(
        self,
        pos_label: Optional[PythonScalar] = None,
        nbins: int = 30,
        show: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> TableSample:
        """
        Draws the model Cutoff curve.

        Parameters
        ----------
        pos_label: PythonScalar, optional
            To draw the Cutoff curve,
            one of the response column
            classes must be the positive
            class. The parameter ``pos_label``
            represents this class.
        nbins: int, optional
            An ``integer`` value that
            determines the number of
            decision boundaries.
            Decision boundaries are
            set at equally-spaced
            intervals between ``0``
            and ``1``, inclusive.
        show: bool, optional
            If set to ``True``, the
            Plotting object is returned.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        TableSample
            Cutoff curve data points.

        Examples
        --------
        For this example, we will
        use the Iris dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_iris()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                data,
                [
                    "SepalLengthCm",
                    "SepalWidthCm",
                    "PetalLengthCm",
                    "PetalWidthCm",
                ],
                "Species",
            )

        To get the cutoff curve:

        .. code-block:: python

            model.cutoff_curve(pos_label= "Iris-setosa")

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.cutoff_curve(pos_label= "Iris-setosa")
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_classifier_cutoff.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_classifier_cutoff.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.roc_curve(
            *self._get_plot_args(pos_label=pos_label, method="cutoff"),
            show=show,
            **self._get_plot_kwargs(nbins=nbins, chart=chart, method="cutoff"),
            **style_kwargs,
        )

    def lift_chart(
        self,
        pos_label: Optional[PythonScalar] = None,
        nbins: int = 1000,
        show: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> TableSample:
        """
        Draws the model Lift Chart.

        Parameters
        ----------
        pos_label: PythonScalar, optional
            To draw the Lift chart,
            one of the response column
            classes must be the positive
            class. The parameter ``pos_label``
            represents this class.
        nbins: int, optional
            An ``integer`` value that
            determines the number of
            decision boundaries.
            Decision boundaries are
            set at equally-spaced
            intervals between ``0``
            and ``1``, inclusive.
        show: bool, optional
            If set to ``True``, the
            Plotting object is returned.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        TableSample
            lift chart data points.

        Examples
        --------
        For this example, we will
        use the Iris dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_iris()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                data,
                [
                    "SepalLengthCm",
                    "SepalWidthCm",
                    "PetalLengthCm",
                    "PetalWidthCm",
                ],
                "Species",
            )

        To get the Lift chart:

        .. code-block:: python

            model.lift_chart(pos_label= "Iris-setosa")

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.lift_chart(pos_label= "Iris-setosa")
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_classifier_lift.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_classifier_lift.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.lift_chart(
            *self._get_plot_args(pos_label=pos_label),
            show=show,
            **self._get_plot_kwargs(nbins=nbins, chart=chart),
            **style_kwargs,
        )

    def prc_curve(
        self,
        pos_label: Optional[PythonScalar] = None,
        nbins: int = 30,
        show: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> TableSample:
        """
        Draws the model PRC curve.

        Parameters
        ----------
        pos_label: PythonScalar, optional
            To draw the PRC curve,
            one of the response column
            classes must be the positive
            class. The parameter ``pos_label``
            represents this class.
        nbins: int, optional
            An ``integer`` value that
            determines the number of
            decision boundaries.
            Decision boundaries are
            set at equally-spaced
            intervals between ``0``
            and ``1``, inclusive.
        show: bool, optional
            If set to ``True``, the
            Plotting object is returned.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        TableSample
            PRC curve data points.

        Examples
        --------
        For this example, we will
        use the Iris dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_iris()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                data,
                [
                    "SepalLengthCm",
                    "SepalWidthCm",
                    "PetalLengthCm",
                    "PetalWidthCm",
                ],
                "Species",
            )

        To get the PRC curve:

        .. code-block:: python

            model.prc_curve(pos_label= "Iris-setosa")

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.prc_curve(pos_label= "Iris-setosa")
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_classifier_prc_curve.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_classifier_prc_curve.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.prc_curve(
            *self._get_plot_args(pos_label=pos_label),
            show=show,
            **self._get_plot_kwargs(nbins=nbins, chart=chart),
            **style_kwargs,
        )

    def roc_curve(
        self,
        pos_label: Optional[PythonScalar] = None,
        nbins: int = 30,
        show: bool = True,
        chart: Optional[PlottingObject] = None,
        **style_kwargs,
    ) -> TableSample:
        """
        Draws the model ROC curve.

        Parameters
        ----------
        pos_label: PythonScalar, optional
            To draw the ROC curve,
            one of the response column
            classes must be the positive
            class. The parameter ``pos_label``
            represents this class.
        nbins: int, optional
            An ``integer`` value that
            determines the number of
            decision boundaries.
            Decision boundaries are
            set at equally-spaced
            intervals between ``0``
            and ``1``, inclusive.
        show: bool, optional
            If set to ``True``, the
            Plotting object is returned.
        chart: PlottingObject, optional
            The chart object to plot on.
        ``**style_kwargs``
            Any optional parameter to pass
            to the Plotting functions.

        Returns
        -------
        TableSample
            ROC curve data points.

        Examples
        --------
        For this example, we will
        use the Iris dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_iris()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_iris.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import NearestCentroid

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = NearestCentroid(p = 2)

        We can now fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(
                data,
                [
                    "SepalLengthCm",
                    "SepalWidthCm",
                    "PetalLengthCm",
                    "PetalWidthCm",
                ],
                "Species",
            )

        To get the PRC curve:

        .. code-block:: python

            model.roc_curve(pos_label= "Iris-setosa")

        .. ipython:: python
            :suppress:

            vo.set_option("plotting_lib", "plotly")
            fig = model.roc_curve(pos_label= "Iris-setosa")
            fig.write_html("SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_classifier_roc_curve.html")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_base_multi_classifier_roc_curve.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        return mt.roc_curve(
            *self._get_plot_args(pos_label=pos_label),
            show=show,
            **self._get_plot_kwargs(nbins=nbins, chart=chart),
            **style_kwargs,
        )


class Regressor(Supervised):
    """
    Base Class for VAST Regressors.
    """

    # Model Evaluation Methods.

    def regression_report(
        self,
        metrics: Union[
            str,
            Literal[None, "anova", "details"],
            list[Literal[tuple(mt.FUNCTIONS_REGRESSION_DICTIONNARY)]],
        ] = None,
    ) -> Union[float, TableSample]:
        """
        Computes a regression report
        using multiple metrics to
        evaluate the model (``r2``,
        ``mse``, ``max error``...).

        Parameters
        ----------
        metrics: str | list, optional
           The metrics used to compute
           the regression report.

           - None:
               Computes the model different metrics.
           - anova:
               Computes the model ANOVA table.
           - details:
               Computes the model details.

            It can also be a ``list`` of the
            metrics used to compute the final
            report.

            - aic:
                Akaike's Information Criterion

                .. math::

                    AIC = 2k - 2\\ln(\\hat{L})

            - bic:
                Bayesian Information Criterion

                .. math::

                    BIC = -2\\ln(\\hat{L}) + k \\ln(n)

            - max:
                Max Error.

                .. math::

                    ME = \\max_{i=1}^{n} \\left| y_i - \\hat{y}_i \\right|

            - mae:
                Mean Absolute Error.

                .. math::

                    MAE = \\frac{1}{n} \\sum_{i=1}^{n} \\left| y_i - \\hat{y}_i \\right|

            - median:
                Median Absolute Error.

                .. math::

                    MedAE = \\text{median}_{i=1}^{n} \\left| y_i - \\hat{y}_i \\right|

            - mse:
                Mean Squared Error.

                .. math::

                    MsE = \\frac{1}{n} \\sum_{i=1}^{n} \\left( y_i - \\hat{y}_i \\right)^2

            - msle:
                Mean Squared Log Error.

                .. math::

                    MSLE = \\frac{1}{n} \\sum_{i=1}^{n} (\\log(1 + y_i) - \\log(1 + \\hat{y}_i))^2

            - r2:
                R squared coefficient.

                .. math::

                    R^2 = 1 - \\frac{\\sum_{i=1}^{n} (y_i - \\hat{y}_i)^2}{\\sum_{i=1}^{n} (y_i - \\bar{y})^2}

            - r2a:
                R2 adjusted

                .. math::

                    \\text{Adjusted } R^2 = 1 - \\frac{(1 - R^2)(n - 1)}{n - k - 1}

            - qe:
                quantile error, the quantile must be
                included in the name. Example:
                qe50.1% will  return the quantile
                error using q=0.501.

            - rmse:
                Root-mean-squared error

                .. math::

                    RMSE = \\sqrt{\\frac{1}{n} \\sum_{i=1}^{n} (y_i - \\hat{y}_i)^2}

            - var:
                Explained Variance

                .. math::

                    \\text{Explained Variance}   = 1 - \\frac{Var(y - \\hat{y})}{Var(y)}

        Returns
        -------
        TableSample
            report.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        We can get the entire report using:

        .. ipython:: python
            :suppress:

            result = model.report()
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_linear_model_lr_report.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            result = model.report()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_linear_model_lr_report.html

        We can easily get the ANOVA table using:

        .. ipython:: python
            :suppress:

            result = model.report(metrics = "anova")
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_linear_model_lr_report_anova.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            result = model.report(metrics = "anova")

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_linear_model_lr_report_anova.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        prediction = self.deploySQL()
        if self._model_type == "KNeighborsRegressor":
            test_relation = self.deploySQL()
            prediction = "predict_neighbors"
        else:
            test_relation = self.test_relation
        if metrics == "anova":
            return mt.anova_table(self.y, prediction, test_relation, len(self.X))
        elif metrics == "details":
            vdf = VastFrame(f"SELECT {self.y} FROM {self.input_relation}")
            n = vdf[self.y].count()
            kurt = vdf[self.y].kurt()
            skew = vdf[self.y].skew()
            jb = vdf[self.y].agg(["jb"])[self.y][0]
            R2 = self.score(metric="r2")
            R2_adj = 1 - ((1 - R2) * (n - 1) / (n - len(self.X) - 1))
            anova_T = mt.anova_table(self.y, prediction, test_relation, len(self.X))
            F = anova_T["F"][0]
            p_F = anova_T["p_value"][0]
            return TableSample(
                {
                    "index": [
                        "Dep. Variable",
                        "Model",
                        "No. Observations",
                        "No. Predictors",
                        "R-squared",
                        "Adj. R-squared",
                        "F-statistic",
                        "Prob (F-statistic)",
                        "Kurtosis",
                        "Skewness",
                        "Jarque-Bera (JB)",
                    ],
                    "value": [
                        self.y,
                        self._model_type,
                        n,
                        len(self.X),
                        R2,
                        R2_adj,
                        F,
                        p_F,
                        kurt,
                        skew,
                        jb,
                    ],
                }
            )
        elif isinstance(metrics, NoneType) or isinstance(
            metrics, (str, list, np.ndarray)
        ):
            return mt.regression_report(
                self.y, prediction, test_relation, metrics=metrics, k=len(self.X)
            )

    report = regression_report

    def score(
        self,
        metric: Literal[
            tuple(mt.FUNCTIONS_REGRESSION_DICTIONNARY)
            + ("r2a", "r2_adj", "rsquared_adj", "r2adj", "r2adjusted", "rmse")
        ] = "r2",
    ) -> float:
        """
        Computes the model score.

        Parameters
        ----------
        metric: str, optional
            The metric used to compute the score.

            - aic:
                Akaike's Information Criterion

                .. math::

                    AIC = 2k - 2\\ln(\\hat{L})

            - bic:
                Bayesian Information Criterion

                .. math::

                    BIC = -2\\ln(\\hat{L}) + k \\ln(n)

            - max:
                Max Error.

                .. math::

                    ME = \\max_{i=1}^{n} \\left| y_i - \\hat{y}_i \\right|

            - mae:
                Mean Absolute Error.

                .. math::

                    MAE = \\frac{1}{n} \\sum_{i=1}^{n} \\left| y_i - \\hat{y}_i \\right|

            - median:
                Median Absolute Error.

                .. math::

                    MedAE = \\text{median}_{i=1}^{n} \\left| y_i - \\hat{y}_i \\right|

            - mse:
                Mean Squared Error.

                .. math::

                    MsE = \\frac{1}{n} \\sum_{i=1}^{n} \\left( y_i - \\hat{y}_i \\right)^2

            - msle:
                Mean Squared Log Error.

                .. math::

                    MSLE = \\frac{1}{n} \\sum_{i=1}^{n} (\\log(1 + y_i) - \\log(1 + \\hat{y}_i))^2

            - r2:
                R squared coefficient.

                .. math::

                    R^2 = 1 - \\frac{\\sum_{i=1}^{n} (y_i - \\hat{y}_i)^2}{\\sum_{i=1}^{n} (y_i - \\bar{y})^2}

            - r2a:
                R2 adjusted

                .. math::

                    \\text{Adjusted } R^2 = 1 - \\frac{(1 - R^2)(n - 1)}{n - k - 1}

            - qe:
                quantile error, the quantile must be
                included in the name. Example:
                qe50.1% will  return the quantile
                error using q=0.501.

            - rmse:
                Root-mean-squared error

                .. math::

                    RMSE = \\sqrt{\\frac{1}{n} \\sum_{i=1}^{n} (y_i - \\hat{y}_i)^2}

            - var:
                Explained Variance

                .. math::

                    \\text{Explained Variance}   = 1 - \\frac{Var(y - \\hat{y})}{Var(y)}

        Returns
        -------
        float
            score.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        Let's compute the model score:

        .. ipython:: python

            model.score()

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        # Initialization
        metric = str(metric).lower()
        if metric in ["r2adj", "r2adjusted"]:
            metric = "r2a"
        adj, root = False, False
        if metric in ("r2a", "r2adj", "r2adjusted", "r2_adj", "rsquared_adj"):
            metric, adj = "r2", True
        elif metric == "rmse":
            metric, root = "mse", True
        fun = mt.FUNCTIONS_REGRESSION_DICTIONNARY[metric]

        # Scoring
        if self._model_type == "KNeighborsRegressor":
            test_relation, prediction = self.deploySQL(), "predict_neighbors"
        else:
            test_relation, prediction = self.test_relation, self.deploySQL()
        arg = [self.y, prediction, test_relation]
        if metric in ("aic", "bic") or adj:
            arg += [len(self.X)]
        if root or adj:
            arg += [True]
        return fun(*arg)

    # Prediction / Transformation Methods.

    def predict(
        self,
        vdf: SQLRelation,
        X: Optional[SQLColumns] = None,
        name: Optional[str] = None,
        inplace: bool = True,
    ) -> VastFrame:
        """
        Predicts using the
        input relation.

        Parameters
        ----------
        vdf: SQLRelation
            Object used to run the prediction.
            You can also  specify a customized
            relation, but you must enclose it
            with an alias. For example,
            ``(SELECT 1) x`` is valid, whereas
            ``(SELECT 1)`` and ``SELECT 1``
            are invalid.
        X: SQLColumns, optional
            ``list`` of the columns used to
            deploy the models. If empty, the
            model predictors are used.
        name: str, optional
            Name of the added
            :py:class`VastColumn`.
            If empty, a name is generated.
        inplace: bool, optional
            If set to True, the prediction
            is added to the
            :py:class`VastFrame`.

        Returns
        -------
        VastFrame
            the input object.

        Examples
        --------
        We import :py:mod:`vastorbit`:

        .. code-block:: python

            import vastorbit as vo

        For this example, we will
        use the winequality dataset.

        .. code-block:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Divide your dataset into training
        and testing subsets.

        .. code-block:: python

            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        .. ipython:: python
            :suppress:

            import vastorbit as vo
            import vastorbit.datasets as vod
            data = vod.load_winequality()
            train, test = data.train_test_split(test_size = 0.2)

        Let's import the model:

        .. code-block::

            from vastorbit.machine_learning.vast import LinearRegression

        Then we can create the model:

        .. code-block::

            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        .. ipython:: python
            :suppress:

            from vastorbit.machine_learning.vast import LinearRegression
            model = LinearRegression(
                tol = 1e-6,
                fit_intercept = True,
            )

        We can now fit the model:

        .. ipython:: python

            model.fit(
                train,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "quality",
                test,
            )

        Prediction is straight-forward:

        .. ipython:: python
            :suppress:

            result = model.predict(
                test,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "prediction",
            )
            html_file = open("SPHINX_DIRECTORY/figures/machine_learning_VAST_linear_model_lr_prediction.html", "w")
            html_file.write(result._repr_html_())
            html_file.close()

        .. code-block:: python

            model.predict(
                test,
                [
                    "fixed_acidity",
                    "volatile_acidity",
                    "citric_acid",
                    "residual_sugar",
                    "chlorides",
                    "density",
                ],
                "prediction",
            )

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/machine_learning_VAST_linear_model_lr_prediction.html

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """
        if hasattr(self, "_predict"):
            return self._predict(vdf=vdf, X=X, name=name, inplace=inplace)
        X = format_type(X, dtype=list, na_out=self.X)
        X = quote_ident(X)
        if isinstance(vdf, str):
            vdf = VastFrame(vdf)
            inplace = True
        if not name:
            name = gen_name([self._model_type, self.model_name])
        if inplace:
            return vdf.eval(name, self.deploySQL(X=X))
        else:
            return vdf.copy().eval(name, self.deploySQL(X=X))


class Unsupervised(VASTModel):

    # System & Special Methods.

    @property
    def _model_category(self) -> Literal["UNSUPERVISED"]:
        return "UNSUPERVISED"

    # Model Fitting Method.

    def fit(
        self,
        input_relation: SQLRelation,
        X: Optional[SQLColumns] = None,
        return_report: bool = False,
    ) -> Optional[str]:
        """
        Trains the model.

        Parameters
        ----------
        input_relation: SQLRelation
            Training relation.
        X: SQLColumns, optional
            ``list`` of the predictors.
            If empty, all the numerical
            columns are used.
        return_report: bool, optional
            [For native models]
            When set to ``True``, the
            model summary will be returned.
            Otherwise, it will be printed.

        Returns
        -------
        str
            model's summary.

        Examples
        --------
        For this example, we will
        use the winequality dataset.

        .. ipython:: python

            import vastorbit.datasets as vod

            data = vod.load_winequality()

        .. raw:: html
            :file: SPHINX_DIRECTORY/figures/datasets_loaders_load_winequality.html

        Let's import the model:

        .. ipython:: python

            from vastorbit.machine_learning.vast import KMeans

        Then we can create the model:

        .. ipython:: python
            :okwarning:

            model = KMeans(
                n_clusters = 8,
                init = "k-means++",
                max_iter = 300,
                tol = 1e-4,
            )

        We can then fit the model:

        .. ipython:: python
            :okwarning:

            model.fit(data, X = ["density", "sulphates"])

        .. important::

            For this example, a specific model is
            utilized, and it may not correspond
            exactly to the model you are working
            with. To see a comprehensive example
            specific to your class of interest,
            please refer to that particular class.
        """

        # Initialization
        X = format_type(X, dtype=list)
        if isinstance(input_relation, VastFrame):
            self.input_relation = input_relation.current_relation()
        else:
            self.input_relation = input_relation

        # Per the docstring, an empty X means "use all numerical columns".
        # Without this, self.X stays empty while scikit-learn is still fit on
        # the numerical columns, so the fitted parameter vectors and self.X end
        # up with different lengths and transform()/deploySQL() later raise
        # "length of parameter 'X' must be equal to the length of the vector".
        if not X:
            X = VastFrame(self.input_relation).numcol()
        self.X = quote_ident(X)

        if not (isinstance(self._sklearn_model, NoneType)):
            vdf = VastFrame(self.input_relation)
            X = vdf[self.X].to_numpy()
            model = self._sklearn_model(**self._get_sklearn_params())
            model.fit(X)
            self._model = model
            self._X = X

        # Fitting

        self._compute_attributes()
        return None
