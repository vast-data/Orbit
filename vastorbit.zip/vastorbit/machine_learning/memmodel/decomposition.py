"""
SPDX-License-Identifier: Apache-2.0
"""

from typing import Literal

import numpy as np
from numpy.linalg import svd

from vastorbit._typing import ArrayLike

from vastorbit.machine_learning.memmodel.base import InMemoryModel


class PCA(InMemoryModel):
    """
    :py:class:`~vastorbit.machine_learning.memmodel.base.InMemoryModel`
    implementation of the
    ``PCA`` algorithm.

    Parameters
    ----------
    principal_components: ArrayLike
        Matrix of the principal
        components.
    mean: ArrayLike
        List of the averages of
        each input feature.

    .. note::

        :py:class:`~vastorbit.machine_learning.memmodel.decomposition.PCA`
        are defined entirely by their
        attributes. For example,
        ``principal_components`` and
        ``mean`` define a PCA model.

    Attributes
    ----------
    Attributes are identical to the input
    parameters, followed by an underscore
    ('_').

    Examples
    --------

    **Initalization**

    Import the required module.

    .. ipython:: python

        from vastorbit.machine_learning.memmodel.decomposition import PCA

    A :py:class:`~vastorbit.machine_learning.memmodel.decomposition.PCA`
    model is defined by
    its ``principal_components``
    and ``mean`` value.
    In this example, we will use
    the following:

    .. ipython:: python

        principal_components = [
            [0.4, 0.5],
            [0.3, 0.2],
        ]
        mean = [0.1, 0.3]

    Let's create a
    :py:class:`~vastorbit.machine_learning.memmodel.decomposition.PCA`
    model.

    .. ipython:: python

        model_pca = PCA(principal_components, mean)

    Create a dataset.

    .. ipython:: python

        data = [[4, 5]]

    **Making In-Memory Transformation**

    Use
    :py:meth:`~vastorbit.machine_learning.memmodel.decomposition.PCA.transform`
    method to do transformation.

    .. ipython:: python

        model_pca.transform(data)

    **Deploy SQL Code**

    Let's use the following column
    names:

    .. ipython:: python

        cnames = ['col1', 'col2']

    Use
    :py:meth:`~vastorbit.machine_learning.memmodel.decomposition.PCA.transform_sql`
    method to get the SQL code
    needed to deploy the model
    using its attributes.

    .. ipython:: python

        model_pca.transform_sql(cnames)

    **Perform an Oblimin Rotation**

    Use
    :py:meth:`~vastorbit.machine_learning.memmodel.decomposition.PCA.rotate`
    method to perform Oblimin (Varimax,
    Quartimax) rotation on PCA matrix.

    .. ipython:: python

        model_pca.rotate()

    .. note::

        You can determine the type of
        rotation by adjusting value
        of gamma in
        :py:meth:`~vastorbit.machine_learning.memmodel.decomposition.PCA.rotate`
        method. It must be between
        ``0.0`` and ``1.0``.

    Use ``gamma = 0.0``, for
    Quartimax rotation:

    .. ipython:: python

        gamma = 0.0
        model_pca.rotate(gamma)

    Use ``gamma = 1.0``, for
    Varimax rotation:

    .. ipython:: python

        gamma = 1.0
        model_pca.rotate(gamma)

    Use
    :py:meth:`~vastorbit.machine_learning.memmodel.decomposition.PCA.get_attributes`
    method to check the attributes
    of the rotated model.

    .. ipython:: python

        model_pca.get_attributes()

    .. hint::
        This object can be pickled
        and used in any in-memory
        environment, just like
        `SKLEARN <https://scikit-learn.org/>`__
        models.
    """

    # Properties.

    @property
    def object_type(self) -> Literal["PCA"]:
        return "PCA"

    @property
    def _attributes(self) -> list[str]:
        return ["principal_components_", "mean_"]

    # System & Special Methods.

    def __init__(self, principal_components: ArrayLike, mean: ArrayLike) -> None:
        self.principal_components_ = np.array(principal_components)
        self.mean_ = np.array(mean)

    # Prediction | Transformation Methods - IN MEMORY.

    def transform(self, X: ArrayLike) -> np.ndarray:
        """
        Transforms and applies the
        :py:class:`~vastorbit.machine_learning.memmodel.decomposition.PCA`
        model to the input matrix.

        Parameters
        ----------
        X: ArrayLike
            The data on which to
            make the transformation.

        Returns
        -------
        numpy.array
            Transformed values.

        Examples
        --------
        Import the required module.

        .. ipython:: python

            from vastorbit.machine_learning.memmodel.decomposition import PCA

        We will use the
        following attributes:

        .. ipython:: python

            principal_components = [
                [0.4, 0.5],
                [0.3, 0.2],
            ]
            mean = [0.1, 0.3]

        Let's create a model.

        .. ipython:: python

            model_pca = PCA(principal_components, mean)

        Create a dataset.

        .. ipython:: python

            data = [[4, 5]]

        Transform the data.

        .. ipython:: python

            model_pca.transform(data)

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.memmodel.decomposition.PCA`
            for more information about the
            different methods and usages.
        """
        X_trans = []
        n = self.principal_components_.shape[1]
        for i in range(n):
            X_trans += [
                np.sum((X - self.mean_) * self.principal_components_[:, i], axis=1)
            ]
        return np.column_stack(X_trans)

    # Prediction | Transformation Methods - IN DATABASE.

    def transform_sql(self, X: ArrayLike) -> list[str]:
        """
        Transforms and returns the
        SQL needed to deploy the
        :py:class:`~vastorbit.machine_learning.memmodel.decomposition.PCA`
        model.

        Parameters
        ----------
        X: ArrayLike
            The names or values of
            the input predictors.

        Returns
        -------
        list
            SQL code.

        Examples
        --------
        Import the required module.

        .. ipython:: python

            from vastorbit.machine_learning.memmodel.decomposition import PCA

        We will use the
        following attributes:

        .. ipython:: python

            principal_components = [
                [0.4, 0.5],
                [0.3, 0.2],
            ]
            mean = [0.1, 0.3]

        Let's create a model.

        .. ipython:: python

            model_pca = PCA(principal_components, mean)

        Create a dataset.

        .. ipython:: python

            data = [[4, 5]]

        Let's use the following column
        names:

        .. ipython:: python

            cnames = ['col1', 'col2']

        Get the SQL code needed
        to deploy the model.

        .. ipython:: python

            model_pca.transform_sql(cnames)

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.memmodel.decomposition.PCA`
            for more information about the
            different methods and usages.
        """
        if len(X) != len(self.mean_):
            raise ValueError(
                "The length of parameter 'X' must be equal to the length "
                "of the vector 'mean'."
            )
        sql = []
        m, n = self.principal_components_.shape
        for i in range(n):
            sql_tmp = []
            for j in range(m):
                sql_tmp += [
                    f"({X[j]} - {self.mean_[j]}) * {self.principal_components_[:, i][j]}"
                ]
            sql += [" + ".join(sql_tmp)]
        return sql

    def inverse_transform_sql(self, X: ArrayLike) -> list[str]:
        """
        Returns the SQL needed to reconstruct the original features from the
        principal components (inverse PCA transform). ``X`` holds the names of
        the ``n_components`` component columns; the result has one expression
        per original feature: ``mean_j + SUM_i comp_i * principal_components_[j, i]``.
        """
        m, n = self.principal_components_.shape
        if len(X) != n:
            raise ValueError(
                "The length of parameter 'X' must be equal to the number of "
                "principal components."
            )
        sql = []
        for j in range(m):
            terms = [
                f"{X[i]} * {self.principal_components_[:, i][j]}" for i in range(n)
            ]
            sql += [f"({' + '.join(terms)}) + {self.mean_[j]}"]
        return sql

    # Special Methods - Matrix Rotation.

    @staticmethod
    def matrix_rotation(
        Phi: ArrayLike, gamma: float = 1.0, q: int = 20, tol: float = 1e-6
    ) -> None:
        """
        Performs an Oblimin (Varimax,
        Quartimax) rotation on the
        input matrix.

        Refer to
        :py:meth:`~vastorbit.machine_learning.memmodel.decomposition.PCA.rotate`
        for more information.
        """
        # This piece of code was taken from
        # https://en.wikipedia.org/wiki/Talk:Varimax_rotation
        Phi = np.array(Phi)
        p, k = Phi.shape
        R = np.eye(k)
        d = 0
        for _i in range(q):
            d_old = d
            Lambda = np.dot(Phi, R)
            u, s, vh = svd(
                np.dot(
                    Phi.T,
                    np.asarray(Lambda) ** 3
                    - (gamma / p)
                    * np.dot(Lambda, np.diag(np.diag(np.dot(Lambda.T, Lambda)))),
                )
            )
            R = np.dot(u, vh)
            d = np.sum(s)
            if d_old != 0 and d / d_old < 1 + tol:
                break
        return np.dot(Phi, R)

    def rotate(self, gamma: float = 1.0, q: int = 20, tol: float = 1e-6) -> None:
        """
        Performs an Oblimin (Varimax,
        Quartimax) rotation on the
        :py:class:`~vastorbit.machine_learning.memmodel.decomposition.PCA`
        matrix.

        Parameters
        ----------
        gamma: float, optional
            Oblimin rotation factor,
            determines the type of
            rotation.
            It must be between ``0.0``
            and ``1.0``.

            - ``gamma = 0.0`` results in
                a Quartimax rotation.

            - ``gamma = 1.0`` results in
                a Varimax rotation.

        q: int, optional
            Maximum number of iterations.
        tol: float, optional
            The  algorithm stops when the
            Frobenius norm of gradient is
            less than ``tol``.

        Examples
        --------
        Import the required module.

        .. ipython:: python

            from vastorbit.machine_learning.memmodel.decomposition import PCA

        We will use the
        following attributes:

        .. ipython:: python

            principal_components = [
                [0.4, 0.5],
                [0.3, 0.2],
            ]
            mean = [0.1, 0.3]

        Let's create a model.

        .. ipython:: python

            model_pca = PCA(principal_components, mean)

        Create a dataset.

        .. ipython:: python

            data = [[4, 5]]

        Let's use the following column
        names:

        .. ipython:: python

            cnames = ['col1', 'col2']

        Rotate the matrix.

        .. ipython:: python

            model_pca.rotate()

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.memmodel.decomposition.PCA`
            for more information about the
            different methods and usages.
        """
        res = self.matrix_rotation(self.principal_components_, gamma, q, tol)
        self.principal_components_ = res


class SVD(InMemoryModel):
    """
    :py:class:`~vastorbit.machine_learning.memmodel.base.InMemoryModel`
    implementation of the
    ``SVD`` Algorithm.

    Parameters
    ----------
    vectors: ArrayLike
        Matrix of the right
        singular vectors.
    values: ArrayLike
        List of the singular
        values for each input
        feature.

    .. note::

        :py:class:`~vastorbit.machine_learning.memmodel.decomposition.SVD`
        are defined entirely by their
        attributes. For example, ``vectors``
        and ``values`` define a SVD model.

    Attributes
    ----------
    Attributes are identical to the input
    parameters, followed by an underscore
    ('_').

    Examples
    --------

    **Initalization**

    Import the required module.

    .. ipython:: python

        from vastorbit.machine_learning.memmodel.decomposition import SVD

    A :py:class:`~vastorbit.machine_learning.memmodel.decomposition.SVD`
    model is defined by
    its vectors and values.
    In this example, we will
    use the following:

    .. ipython:: python

        vectors = [
            [0.4, 0.5],
            [0.3, 0.2],
        ]
        values = [0.1, 0.3]

    Let's create a
    :py:class:`~vastorbit.machine_learning.memmodel.decomposition.SVD`
    model.

    .. ipython:: python

        model_svd = SVD(vectors, values)

    Create a dataset.

    .. ipython:: python

        data = [[0.3, 0.5]]

    **Making In-Memory Transformation**

    Use
    :py:meth:`~vastorbit.machine_learning.memmodel.decomposition.SVD.transform`
    method to do transformation.

    .. ipython:: python

        model_svd.transform(data)

    **Deploy SQL Code**

    Let's use the following column names:

    .. ipython:: python

        cnames = ['col1', 'col2']

    Use
    :py:meth:`~vastorbit.machine_learning.memmodel.decomposition.SVD.transform_sql`
    method to get the SQL code
    needed to deploy the model
    using its attributes.

    .. ipython:: python

        model_svd.transform_sql(cnames)

    Use
    :py:meth:`~vastorbit.machine_learning.memmodel.decomposition.SVD.get_attributes`
    method to check the
    attributes of the
    rotated model.

    .. ipython:: python

        model_svd.get_attributes()

    .. hint::

        This object can be pickled
        and used in any in-memory
        environment, just like
        `SKLEARN <https://scikit-learn.org/>`__
        models.
    """

    # Properties.

    @property
    def object_type(self) -> Literal["SVD"]:
        return "SVD"

    @property
    def _attributes(self) -> list[str]:
        return ["vectors_", "values_"]

    # System & Special Methods.

    def __init__(self, vectors: ArrayLike, values: ArrayLike) -> None:
        self.vectors_ = np.array(vectors)
        self.values_ = np.array(values)

    # Prediction | Transformation Methods - IN MEMORY.

    def transform(self, X: ArrayLike) -> np.ndarray:
        """
        Transforms and applies the
        :py:class:`~vastorbit.machine_learning.memmodel.decomposition.SVD`
        model to the input matrix.

        Parameters
        ----------
        X: ArrayLike
            The data on which to
            make the transformation.

        Returns
        -------
        numpy.array
            Transformed values.

        Examples
        --------
        Import the required module.

        .. ipython:: python

            from vastorbit.machine_learning.memmodel.decomposition import SVD

        We will use the
        following attributes:

        .. ipython:: python

            vectors = [
                [0.4, 0.5],
                [0.3, 0.2],
            ]
            values = [0.1, 0.3]

        Let's create a model.

        .. ipython:: python

            model_svd = SVD(vectors, values)

        Create a dataset.

        .. ipython:: python

            data = [[0.3, 0.5]]

        Transform the data.

        .. ipython:: python

            model_svd.transform(data)

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.memmodel.decomposition.SVD`
            for more information about the
            different methods and usages.
        """
        X_trans = []
        n = self.vectors_.shape[1]
        for i in range(n):
            X_trans += [np.sum(X * self.vectors_[:, i] / self.values_[i], axis=1)]
        return np.column_stack(X_trans)

    # Prediction | Transformation Methods - IN DATABASE.

    def transform_sql(self, X: ArrayLike) -> list[str]:
        """
        Transforms and returns
        the SQL needed to deploy
        the
        :py:class:`~vastorbit.machine_learning.memmodel.decomposition.SVD`
        model.

        Parameters
        ----------
        X: ArrayLike
            The names or values of
            the input predictors.

        Returns
        -------
        list
            SQL code.

        Examples
        --------
        Import the required module.

        .. ipython:: python

            from vastorbit.machine_learning.memmodel.decomposition import SVD

        We will use the
        following attributes:

        .. ipython:: python

            vectors = [
                [0.4, 0.5],
                [0.3, 0.2],
            ]
            values = [0.1, 0.3]

        Let's create a model.

        .. ipython:: python

            model_svd = SVD(vectors, values)

        Let's use the following column names:

        .. ipython:: python

            cnames = ['col1', 'col2']

        Get the SQL code needed
        to deploy the model.

        .. ipython:: python

            model_svd.transform_sql(cnames)

        .. note::

            Refer to
            :py:class:`~vastorbit.machine_learning.memmodel.decomposition.SVD`
            for more information about the
            different methods and usages.
        """
        if len(X) != len(self.vectors_):
            raise ValueError(
                "The length of parameter 'X' must be equal to the length "
                "of the vector 'values'."
            )
        sql = []
        m, n = self.vectors_.shape
        for i in range(n):
            sql_tmp = []
            for j in range(m):
                sql_tmp += [f"{X[j]} * {self.vectors_[:, i][j]} / {self.values_[i]}"]
            sql += [" + ".join(sql_tmp)]
        return sql

    def inverse_transform_sql(self, X: ArrayLike) -> list[str]:
        """
        Returns the SQL needed to reconstruct the original features from the SVD
        components (inverse transform). ``X`` holds the names of the
        ``n_components`` component columns; the result has one expression per
        original feature: ``SUM_i comp_i * values_[i] * vectors_[j, i]``.
        """
        m, n = self.vectors_.shape
        if len(X) != n:
            raise ValueError(
                "The length of parameter 'X' must be equal to the number of "
                "SVD components."
            )
        sql = []
        for j in range(m):
            terms = [
                f"{X[i]} * {self.values_[i]} * {self.vectors_[:, i][j]}"
                for i in range(n)
            ]
            sql += [" + ".join(terms)]
        return sql
