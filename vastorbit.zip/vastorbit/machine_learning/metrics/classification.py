"""
SPDX-License-Identifier: Apache-2.0
"""

from typing import Callable, Literal, Optional, Union, TYPE_CHECKING
import numpy as np
from vastorbit._typing import (
    ArrayLike,
    NoneType,
    PythonNumber,
    PythonScalar,
    SQLRelation,
)
from vastorbit._utils._sql._collect import save_vastorbit_logs
from vastorbit._utils._sql._sys import _executeSQL

from vastorbit.core.tablesample.base import TableSample

if TYPE_CHECKING:
    from vastorbit.machine_learning.vast.base import VASTModel

"""
Confusion Matrix Functions.
"""


PARAMETER_DESCRIPTIONS = {
    "y_true": """    y_true: str
        Response column.""",
    "y_score": """    y_score: str
        Prediction.""",
    "input_relation": """    input_relation: SQLRelation
        Relation used for scoring. This relation can 
        be a view, table, or a customized relation (if 
        an alias is used at the end of the relation). 
        For example: (SELECT ... FROM ...) x""",
    "average": """    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.
            micro    : positive  and   negative  values 
                    globally.
            macro    : average  of  the  score of  each 
                    class.
            weighted : weighted average of the score of 
                    each class.
            scores   : scores  for   all  the  classes.""",
    "labels": """    labels: ArrayLike
        List   of   the  response  column   categories.""",
    "cm_pos_label": """    pos_label: str / PythonNumber, optional
        To compute the one dimensional confusion 
        matrix, one  of the response column classes must
        be the positive class. The parameter 'pos_label' 
        represents this class.""",
}


def _compute_tn_fn_fp_tp_from_cm(cm: ArrayLike) -> tuple:
    """
    helper function to compute the final score.
    """
    return round(cm[0][0]), round(cm[1][0]), round(cm[0][1]), round(cm[1][1])


def _compute_tn_fn_fp_tp(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    pos_label: PythonScalar = 1,
) -> tuple:
    """
    A helper function that  computes the confusion matrix
    for  the specified 'pos_label' class and returns  its
    values as a tuple of the following:
    true negatives, false negatives, false positives, and
    true positives.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation  to use for scoring. This  relation can be a
        view,  table, or a  customized relation (if an  alias
        is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    pos_label: PythonScalar, optional
        To  compute the confusion matrix, one of the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    tuple
        tn, fn, fp, tp
    """
    cm = confusion_matrix(y_true, y_score, input_relation, pos_label=pos_label)
    return _compute_tn_fn_fp_tp_from_cm(cm)


def _compute_classes_tn_fn_fp_tp_from_cm(cm: ArrayLike) -> list[tuple]:
    """
    helper function to compute the final score.
    """
    m = cm.shape[1]
    res = []
    for i in range(m):
        tp = cm[i][i]
        fp = cm[:, i].sum() - cm[i][i]
        fn = cm[i, :].sum() - cm[i][i]
        tn = cm.sum() - fp - fn - tp
        res += [(round(tn), round(fn), round(fp), round(tp))]
    return res


def _compute_classes_tn_fn_fp_tp(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    labels: ArrayLike,
) -> list[tuple]:
    """
    A helper function that  computes the confusion matrix
    and returns  its values  as a tuple of the following:
    true negatives, false negatives, false positives, and
    true positives.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation  to use for scoring. This  relation can be a
        view,  table, or a  customized relation (if an  alias
        is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    labels: ArrayLike
        List of the response column categories.

    Returns
    -------
    list of tuple
        tn, fn, fp, tp for each class
    """
    cm = confusion_matrix(y_true, y_score, input_relation, labels=labels)
    return _compute_classes_tn_fn_fp_tp_from_cm(cm)


def _compute_final_score_from_cm(
    metric: Callable,
    cm: ArrayLike,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    multi: bool = False,
) -> Union[float, list[float]]:
    """
    Computes the final score by using the different results
    of the multi-confusion matrix.
    """
    if metric is _accuracy_score and isinstance(average, NoneType):
        return np.trace(cm) / np.sum(cm)
    elif metric is _balanced_accuracy_score and isinstance(average, NoneType):
        return _compute_final_score_from_cm(
            metric=_recall_score, cm=cm, average="macro", multi=multi
        )
    elif multi:
        confusion_list = _compute_classes_tn_fn_fp_tp_from_cm(cm)
        if average == "binary":
            if len(confusion_list) > 1:
                raise IndexError(
                    "Too many values in 'confusion_list' for parameter average='binary'."
                )
            args = confusion_list[0]
            return metric(*args)
        elif average == "weighted":
            score = sum((args[1] + args[3]) * metric(*args) for args in confusion_list)
            total = sum((args[1] + args[3]) for args in confusion_list)
            return score / total
        elif average == "macro":
            return np.mean([metric(*args) for args in confusion_list])
        elif average == "micro":
            args = [sum(args[i] for args in confusion_list) for i in range(4)]
            return metric(*args)
        elif isinstance(average, NoneType) or average == "scores":
            return [metric(*args) for args in confusion_list]
        else:
            raise ValueError(
                f"Wrong value for parameter 'average'. Expecting: micro|macro|weighted|scores. Got {average}."
            )
    else:
        return metric(*_compute_tn_fn_fp_tp_from_cm(cm))


def _compute_final_score(
    metric: Callable,
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the final score by using the different results
    of the multi-confusion matrix.
    """
    if (
        not (isinstance(pos_label, NoneType))
        and not (isinstance(average, NoneType))
        and average != "binary"
    ):
        raise ValueError(
            "The 'pos_label' parameter can only be used when the 'average' "
            "parameter is set to 'binary' or left undefined. This error can "
            "also occur when you are using a binary classifier; in that case, "
            "the 'average' parameter can only be set to 'binary' or left undefined."
        )
    if not (isinstance(pos_label, NoneType)) and not (isinstance(labels, NoneType)):
        labels = None
    if (
        isinstance(pos_label, NoneType)
        and isinstance(labels, NoneType)
        and average == "binary"
    ):
        pos_label = 1
    elif isinstance(pos_label, NoneType) and isinstance(labels, NoneType):
        labels = _executeSQL(
            query=f"""SELECT DISTINCT({y_true}) FROM {input_relation} WHERE {y_true} IS NOT NULL""",
            title="Computing 'y_true' distinct categories.",
            method="fetchall",
        )
        labels = np.array(labels)[:, 0]
    if isinstance(pos_label, NoneType):
        kwargs, multi = {"labels": labels}, True
    else:
        kwargs, multi = {"pos_label": pos_label}, False
    cm = confusion_matrix(y_true, y_score, input_relation, **kwargs)
    return _compute_final_score_from_cm(metric, cm, average=average, multi=multi)


@save_vastorbit_logs
def confusion_matrix(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> np.ndarray:
    """
    Computes the confusion matrix using SQL.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction column.
    input_relation: SQLRelation
        Relation used for scoring. This relation
        can be a view, table, or a customized relation
        (if an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    labels: ArrayLike, optional
        List of the response column categories.
    pos_label: PythonScalar, optional
        Label used to identify the positive class. If
        pos_label is NULL then the global accuracy is
        computed.

    Returns
    -------
    numpy.ndarray
        Confusion matrix as 2D array.
        For binary: [[TN, FP], [FN, TP]]
        For multi-class: rows=actual, cols=predicted

    Examples
    --------
    Binary Classification:

    .. code-block:: python

        import vastorbit as vo
        from vastorbit.machine_learning.metrics import confusion_matrix

        data = vo.VastFrame({
            "y_true": [1, 1, 0, 0, 1],
            "y_pred": [1, 1, 1, 0, 1],
        })

        cm = confusion_matrix(
            y_true="y_true",
            y_score="y_pred",
            input_relation=data,
        )
        print(cm)
        # [[1 1]
        #  [0 3]]

    Multi-class Classification:

    .. code-block:: python

        data = vo.VastFrame({
            "y_true": [1, 2, 0, 0, 1],
            "y_pred": [1, 2, 0, 1, 1],
        })

        cm = confusion_matrix(
            y_true="y_true",
            y_score="y_pred",
            labels=[0, 1, 2],
            input_relation=data,
        )
        print(cm)
        # [[2 0 0]
        #  [1 1 0]
        #  [0 0 1]]
    """

    # Set default pos_label for binary classification
    if isinstance(pos_label, NoneType) and isinstance(labels, NoneType):
        pos_label = 1

    # Binary classification
    if not isinstance(pos_label, NoneType):
        _q = ""
        if isinstance(pos_label, str):
            _q = "'"
        query = f"""
            SELECT 
                actual,
                predicted,
                COUNT(*) as count
            FROM (
                SELECT 
                    CASE 
                        WHEN CAST({y_true} AS VARCHAR) = '{pos_label}' THEN 1
                        WHEN {y_true} IS NULL THEN NULL
                        ELSE 0 
                    END AS actual,
                    CASE 
                        WHEN CAST({y_score} AS VARCHAR) = '{pos_label}' THEN 1
                        WHEN {y_score} IS NULL THEN NULL
                        ELSE 0 
                    END AS predicted
                FROM {input_relation}
                WHERE {y_true} IS NOT NULL AND {y_score} IS NOT NULL
            ) classified
            GROUP BY actual, predicted
            ORDER BY actual, predicted
        """

        res = _executeSQL(
            query=query,
            title="Computing Confusion Matrix.",
            method="fetchall",
        )

        # Build 2x2 confusion matrix
        # Initialize with zeros
        cm = np.zeros((2, 2), dtype=int)

        # Fill in the counts
        for row in res:
            actual, predicted, count = row
            if actual is not None and predicted is not None:
                cm[int(actual), int(predicted)] = int(count)

        return cm

    # Multi-class classification
    elif not isinstance(labels, NoneType) and len(labels) > 0:
        num_classes = len(labels)

        # Build CASE statements for label encoding
        actual_case = "CASE "
        predicted_case = "CASE "

        for idx, label in enumerate(labels):
            _q = ""
            if isinstance(label, str):
                _q = "'"
            actual_case += f"WHEN CAST({y_true} AS VARCHAR) = '{label}' THEN {idx} "
            predicted_case += f"WHEN CAST({y_score} AS VARCHAR) = '{label}' THEN {idx} "

        actual_case += "ELSE NULL END"
        predicted_case += "ELSE NULL END"

        query = f"""
            SELECT 
                actual,
                predicted,
                COUNT(*) as count
            FROM (
                SELECT 
                    {actual_case} AS actual,
                    {predicted_case} AS predicted
                FROM {input_relation}
                WHERE {y_true} IS NOT NULL AND {y_score} IS NOT NULL
            ) classified
            WHERE actual IS NOT NULL AND predicted IS NOT NULL
            GROUP BY actual, predicted
            ORDER BY actual, predicted
        """

        res = _executeSQL(
            query=query,
            title="Computing Confusion Matrix.",
            method="fetchall",
        )

        # Build confusion matrix
        cm = np.zeros((num_classes, num_classes), dtype=int)

        # Fill in the counts
        for row in res:
            actual, predicted, count = row
            if actual is not None and predicted is not None:
                cm[int(actual), int(predicted)] = int(count)

        return cm

    else:
        raise ValueError("Parameters 'labels' and 'pos_label' cannot both be empty.")


"""
Confusion Matrix Metrics.
"""


def _accuracy_score(tn: int, fn: int, fp: int, tp: int) -> float:
    return (tp + tn) / (tp + tn + fn + fp)


@save_vastorbit_logs
def accuracy_score(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> float:
    """
    Computes the Accuracy score.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation  used for  scoring.  This  relation
        can  be a view, table, or a customized  relation
        (if an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        Label used to identify the positive class. If
        pos_label is NULL then the global accuracy is
        be computed.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import accuracy_score

    Now we can conveniently calculate the score:

    .. ipython:: python

        accuracy_score(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "accuracy",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _accuracy_score,
        **locals(),
    )


def _balanced_accuracy_score(tn: int, fn: int, fp: int, tp: int) -> float:
    return (_recall_score(**locals()) + _specificity_score(**locals())) / 2


@save_vastorbit_logs
def balanced_accuracy_score(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> float:
    """
    Computes the Balanced Accuracy.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import balanced_accuracy_score

    Now we can conveniently calculate the score:

    .. ipython:: python

        balanced_accuracy_score(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "balanced_accuracy",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _balanced_accuracy_score,
        **locals(),
    )


def _critical_success_index(tn: int, fn: int, fp: int, tp: int) -> float:
    return tp / (tp + fn + fp) if (tp + fn + fp != 0) else 0.0


@save_vastorbit_logs
def critical_success_index(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Critical Success Index.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import critical_success_index

    Now we can conveniently calculate the score:

    .. ipython:: python

        critical_success_index(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "critical_success_index",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _critical_success_index,
        **locals(),
    )


def _diagnostic_odds_ratio(tn: int, fn: int, fp: int, tp: int) -> float:
    lrp, lrn = (
        _positive_likelihood_ratio(**locals()),
        _negative_likelihood_ratio(**locals()),
    )
    return lrp / lrn if lrn != 0.0 else np.inf


@save_vastorbit_logs
def diagnostic_odds_ratio(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Diagnostic odds ratio.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import diagnostic_odds_ratio

    Now we can conveniently calculate the score:

    .. ipython:: python

        diagnostic_odds_ratio(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "diagnostic_odds_ratio",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _diagnostic_odds_ratio,
        **locals(),
    )


def _f1_score(tn: int, fn: int, fp: int, tp: int) -> float:
    p, r = _precision_score(**locals()), _recall_score(**locals())
    return 2 * (p * r) / (p + r) if (p + r != 0) else 0.0


@save_vastorbit_logs
def f1_score(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the F1 score.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import f1_score

    Now we can conveniently calculate the score:

    .. ipython:: python

        f1_score(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "f1_score",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _f1_score,
        **locals(),
    )


def _false_negative_rate(tn: int, fn: int, fp: int, tp: int) -> float:
    return 1 - _recall_score(**locals())


@save_vastorbit_logs
def false_negative_rate(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the False Negative Rate.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import false_negative_rate

    Now we can conveniently calculate the score:

    .. ipython:: python

        false_negative_rate(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "false_negative_rate",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(_false_negative_rate, **locals())


def _false_positive_rate(tn: int, fn: int, fp: int, tp: int) -> float:
    return 1 - _specificity_score(**locals())


@save_vastorbit_logs
def false_positive_rate(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the False Positive Rate.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import false_positive_rate

    Now we can conveniently calculate the score:

    .. ipython:: python

        false_positive_rate(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "false_positive_rate",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _false_positive_rate,
        **locals(),
    )


def _false_discovery_rate(tn: int, fn: int, fp: int, tp: int) -> float:
    return 1 - _precision_score(**locals())


@save_vastorbit_logs
def false_discovery_rate(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the False Discovery Rate.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import false_discovery_rate

    Now we can conveniently calculate the score:

    .. ipython:: python

        false_discovery_rate(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "false_discovery_rate",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _false_discovery_rate,
        **locals(),
    )


def _false_omission_rate(tn: int, fn: int, fp: int, tp: int) -> float:
    return 1 - _negative_predictive_score(**locals())


@save_vastorbit_logs
def false_omission_rate(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the False Omission Rate.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import false_omission_rate

    Now we can conveniently calculate the score:

    .. ipython:: python

        false_omission_rate(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "false_omission_rate",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _false_omission_rate,
        **locals(),
    )


def _fowlkes_mallows_index(tn: int, fn: int, fp: int, tp: int) -> float:
    return np.sqrt(_precision_score(**locals()) * _recall_score(**locals()))


@save_vastorbit_logs
def fowlkes_mallows_index(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Fowlkes–Mallows index.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import fowlkes_mallows_index

    Now we can conveniently calculate the score:

    .. ipython:: python

        fowlkes_mallows_index(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "fowlkes_mallows_index",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _fowlkes_mallows_index,
        **locals(),
    )


def _informedness(tn: int, fn: int, fp: int, tp: int) -> float:
    return _recall_score(**locals()) + _specificity_score(**locals()) - 1


@save_vastorbit_logs
def informedness(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Informedness.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation used for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import informedness

    Now we can conveniently calculate the score:

    .. ipython:: python

        informedness(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "informedness",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _informedness,
        **locals(),
    )


def _markedness(tn: int, fn: int, fp: int, tp: int) -> float:
    ppv = tp / (tp + fp) if (tp + fp != 0) else 0.0
    npv = tn / (tn + fn) if (tn + fn != 0) else 0.0
    return ppv + npv - 1


@save_vastorbit_logs
def markedness(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Markedness.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import markedness

    Now we can conveniently calculate the score:

    .. ipython:: python

        markedness(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "markedness",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _markedness,
        **locals(),
    )


def _matthews_corrcoef(tn: int, fn: int, fp: int, tp: int) -> float:
    return (
        (tp * tn - fp * fn) / np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
        if (tp + fp != 0) and (tp + fn != 0) and (tn + fp != 0) and (tn + fn != 0)
        else 0.0
    )


@save_vastorbit_logs
def matthews_corrcoef(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Matthews Correlation Coefficient.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import matthews_corrcoef

    Now we can conveniently calculate the score:

    .. ipython:: python

        matthews_corrcoef(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "mcc",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _matthews_corrcoef,
        **locals(),
    )


def _negative_predictive_score(tn: int, fn: int, fp: int, tp: int) -> float:
    return tn / (tn + fn) if (tn + fn != 0) else 0.0


@save_vastorbit_logs
def negative_predictive_score(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Negative Predictive Score.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import negative_predictive_score

    Now we can conveniently calculate the score:

    .. ipython:: python

        negative_predictive_score(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "negative_predictive_value",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _negative_predictive_score,
        **locals(),
    )


def _negative_likelihood_ratio(tn: int, fn: int, fp: int, tp: int) -> float:
    return _false_negative_rate(**locals()) / _specificity_score(**locals())


@save_vastorbit_logs
def negative_likelihood_ratio(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Positive Likelihood ratio.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import negative_likelihood_ratio

    Now we can conveniently calculate the score:

    .. ipython:: python

        negative_likelihood_ratio(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "negative_likelihood_ratio",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _negative_likelihood_ratio,
        **locals(),
    )


def _positive_likelihood_ratio(tn: int, fn: int, fp: int, tp: int) -> float:
    tpr, fpr = _recall_score(**locals()), _false_positive_rate(**locals())
    return tpr / fpr if fpr != 0 else 0.0


@save_vastorbit_logs
def positive_likelihood_ratio(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Positive Likelihood ratio.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import positive_likelihood_ratio

    Now we can conveniently calculate the score:

    .. ipython:: python

        positive_likelihood_ratio(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "positive_likelihood_ratio",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _positive_likelihood_ratio,
        **locals(),
    )


def _precision_score(tn: int, fn: int, fp: int, tp: int) -> float:
    return tp / (tp + fp) if (tp + fp != 0) else 0.0


@save_vastorbit_logs
def precision_score(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Precision Score.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import precision_score

    Now we can conveniently calculate the score:

    .. ipython:: python

        precision_score(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "precision",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _precision_score,
        **locals(),
    )


def _prevalence_threshold(tn: int, fn: int, fp: int, tp: int) -> float:
    fpr, tpr = _false_positive_rate(**locals()), _recall_score(**locals())
    return np.sqrt(fpr) / (np.sqrt(tpr) + np.sqrt(fpr)) if ((tpr + fpr) != 0) else 0.0


@save_vastorbit_logs
def prevalence_threshold(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Prevalence Threshold.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import prevalence_threshold

    Now we can conveniently calculate the score:

    .. ipython:: python

        prevalence_threshold(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "prevalence_threshold",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _prevalence_threshold,
        **locals(),
    )


def _recall_score(tn: int, fn: int, fp: int, tp: int) -> float:
    return tp / (tp + fn) if (tp + fn != 0) else 0.0


@save_vastorbit_logs
def recall_score(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Recall score.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import recall_score

    Now we can conveniently calculate the score:

    .. ipython:: python

        recall_score(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "recall",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _recall_score,
        **locals(),
    )


def _specificity_score(tn: int, fn: int, fp: int, tp: int) -> float:
    return tn / (tn + fp) if (tn + fp != 0) else 0.0


@save_vastorbit_logs
def specificity_score(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> Union[float, list[float]]:
    """
    Computes the Specificity score.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import specificity_score

    Now we can conveniently calculate the score:

    .. ipython:: python
        :okwarning:

        specificity_score(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:

        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python
        :okwarning:

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "specificity",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_score(
        _specificity_score,
        **locals(),
    )


"""
AUC / Lift Metrics.
"""

# Special AUC / Lift Methods.


def _compute_area(X: list, Y: list) -> float:
    """
    Computes the area under the curve.
    """
    auc = 0
    for i in range(len(Y) - 1):
        if Y[i + 1] - Y[i] != 0.0:
            a = (X[i + 1] - X[i]) / (Y[i + 1] - Y[i])
            b = X[i + 1] - a * Y[i + 1]
            auc = (
                auc
                + a * (Y[i + 1] * Y[i + 1] - Y[i] * Y[i]) / 2
                + b * (Y[i + 1] - Y[i])
            )
    return min(abs(auc), 1.0)


def _compute_function_metrics(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    pos_label: Optional[PythonScalar] = None,
    nbins: int = 30,
    fun_sql_name: Optional[str] = None,
) -> list[list[float]]:
    """
    Returns the function metrics (ROC or PRC curve) using standard SQL.

    Parameters
    ----------
    y_true : str
        True label column
    y_score : str
        Predicted probability/score column
    input_relation : SQLRelation
        Input relation
    pos_label : PythonScalar, optional
        Positive class label (default: 1)
    nbins : int, optional
        Number of bins/thresholds (default: 30; max: 9999)
    fun_sql_name : str, optional
        Function name: 'roc' or 'prc'

    Returns
    -------
    list[list[float]]
        For ROC: [thresholds, fpr, tpr]
        For PRC: [thresholds, recall, precision]
    """
    if isinstance(pos_label, NoneType):
        pos_label = 1

    if nbins < 0:
        nbins = 9999

    if fun_sql_name == "roc":
        return _compute_roc_curve(y_true, y_score, input_relation, pos_label, nbins)
    elif fun_sql_name == "prc":
        return _compute_prc_curve(y_true, y_score, input_relation, pos_label, nbins)
    elif fun_sql_name in ("lift_curve", "lift_table", "lift"):
        return _compute_lift_curve(y_true, y_score, input_relation, pos_label, nbins)
    else:
        raise ValueError(f"Unknown function: {fun_sql_name}")


def _compute_roc_curve(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    pos_label: PythonScalar,
    nbins: int,
) -> list[list[float]]:
    """
    Compute ROC curve using standard SQL.

    ROC Curve:
    - X-axis: False Positive Rate (FPR) = FP / (FP + TN)
    - Y-axis: True Positive Rate (TPR) = TP / (TP + FN)
    - Vary threshold from max to min score
    """
    _q = ""
    if isinstance(pos_label, str):
        _q = "'"

    query = f"""
    WITH 
    -- Step 1: Prepare data with binary labels
    prepared_data AS (
        SELECT 
            CASE WHEN CAST({y_true} AS VARCHAR) = '{pos_label}' THEN 1 ELSE 0 END AS actual,
            CAST({y_score} AS DOUBLE) AS score
        FROM {input_relation}
        WHERE {y_true} IS NOT NULL AND {y_score} IS NOT NULL
    ),
    
    -- Step 2: Get thresholds using APPROX_PERCENTILE
    threshold_positions AS (
        SELECT 
            bucket,
            CAST(bucket AS DOUBLE) / {nbins} AS percentile
        FROM UNNEST(sequence(0, {nbins})) AS t(bucket)
    ),
    
    thresholds AS (
        SELECT 
            tp.bucket,
            tp.percentile,
            APPROX_PERCENTILE(pd.score, tp.percentile) AS threshold
        FROM threshold_positions tp
        CROSS JOIN prepared_data pd
        GROUP BY tp.bucket, tp.percentile
    ),
    
    -- Step 3: For each threshold, compute TP, FP, TN, FN
    metrics_per_threshold AS (
        SELECT 
            t.threshold,
            t.bucket,
            -- True Positives: actual=1 AND predicted=1 (score >= threshold)
            SUM(CASE WHEN d.actual = 1 AND d.score >= t.threshold THEN 1 ELSE 0 END) AS tp,
            -- False Positives: actual=0 AND predicted=1 (score >= threshold)
            SUM(CASE WHEN d.actual = 0 AND d.score >= t.threshold THEN 1 ELSE 0 END) AS fp,
            -- True Negatives: actual=0 AND predicted=0 (score < threshold)
            SUM(CASE WHEN d.actual = 0 AND d.score < t.threshold THEN 1 ELSE 0 END) AS tn,
            -- False Negatives: actual=1 AND predicted=0 (score < threshold)
            SUM(CASE WHEN d.actual = 1 AND d.score < t.threshold THEN 1 ELSE 0 END) AS fn,
            -- Total positives and negatives
            SUM(d.actual) AS total_positives,
            SUM(CASE WHEN d.actual = 0 THEN 1 ELSE 0 END) AS total_negatives
        FROM thresholds t
        CROSS JOIN prepared_data d
        GROUP BY t.threshold, t.bucket
    )
    
    -- Step 4: Compute TPR and FPR
    SELECT 
        threshold AS decision_boundary,
        -- False Positive Rate: FP / (FP + TN) = FP / total_negatives
        CASE 
            WHEN total_negatives > 0 
            THEN CAST(fp AS DOUBLE) / total_negatives 
            ELSE 0.0 
        END AS false_positive_rate,
        -- True Positive Rate: TP / (TP + FN) = TP / total_positives
        CASE 
            WHEN total_positives > 0 
            THEN CAST(tp AS DOUBLE) / total_positives 
            ELSE 0.0 
        END AS true_positive_rate
    FROM metrics_per_threshold
    ORDER BY bucket DESC
    """

    query_result = _executeSQL(
        query=query,
        title="Computing the ROC_CURVE.",
        method="fetchall",
    )

    # Format result: [thresholds, fpr, tpr]
    result = [
        [item[0] for item in query_result],  # decision_boundary
        [item[1] for item in query_result],  # false_positive_rate
        [item[2] for item in query_result],  # true_positive_rate
    ]

    return result


def _compute_prc_curve(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    pos_label: PythonScalar,
    nbins: int,
) -> list[list[float]]:
    """
    Compute Precision-Recall curve using standard SQL.

    PRC Curve:
    - X-axis: Recall = TP / (TP + FN)
    - Y-axis: Precision = TP / (TP + FP)
    - Vary threshold from max to min score
    """
    _q = ""
    if isinstance(pos_label, str):
        _q = "'"

    query = f"""
    WITH 
    -- Step 1: Prepare data with binary labels
    prepared_data AS (
        SELECT 
            CASE WHEN CAST({y_true} AS VARCHAR) = '{pos_label}' THEN 1 ELSE 0 END AS actual,
            CAST({y_score} AS DOUBLE) AS score
        FROM {input_relation}
        WHERE {y_true} IS NOT NULL AND {y_score} IS NOT NULL
    ),
    
    -- Step 2: Get thresholds using APPROX_PERCENTILE
    threshold_positions AS (
        SELECT 
            bucket,
            CAST(bucket AS DOUBLE) / {nbins} AS percentile
        FROM UNNEST(sequence(0, {nbins})) AS t(bucket)
    ),
    
    thresholds AS (
        SELECT 
            tp.bucket,
            tp.percentile,
            APPROX_PERCENTILE(pd.score, tp.percentile) AS threshold
        FROM threshold_positions tp
        CROSS JOIN prepared_data pd
        GROUP BY tp.bucket, tp.percentile
    ),
    
    -- Step 3: For each threshold, compute TP, FP, FN
    metrics_per_threshold AS (
        SELECT 
            t.threshold,
            t.bucket,
            -- True Positives: actual=1 AND predicted=1 (score >= threshold)
            SUM(CASE WHEN d.actual = 1 AND d.score >= t.threshold THEN 1 ELSE 0 END) AS tp,
            -- False Positives: actual=0 AND predicted=1 (score >= threshold)
            SUM(CASE WHEN d.actual = 0 AND d.score >= t.threshold THEN 1 ELSE 0 END) AS fp,
            -- False Negatives: actual=1 AND predicted=0 (score < threshold)
            SUM(CASE WHEN d.actual = 1 AND d.score < t.threshold THEN 1 ELSE 0 END) AS fn,
            -- Total positives
            SUM(d.actual) AS total_positives
        FROM thresholds t
        CROSS JOIN prepared_data d
        GROUP BY t.threshold, t.bucket
    )
    
    -- Step 4: Compute Precision and Recall
    SELECT 
        threshold AS decision_boundary,
        -- Recall: TP / (TP + FN) = TP / total_positives
        CASE 
            WHEN total_positives > 0 
            THEN CAST(tp AS DOUBLE) / total_positives 
            ELSE 0.0 
        END AS recall,
        -- Precision: TP / (TP + FP)
        CASE 
            WHEN (tp + fp) > 0 
            THEN CAST(tp AS DOUBLE) / (tp + fp)
            ELSE 1.0 
        END AS precision
    FROM metrics_per_threshold
    ORDER BY bucket DESC
    """

    query_result = _executeSQL(
        query=query,
        title="Computing the PRC_CURVE.",
        method="fetchall",
    )

    # Format result: [thresholds, recall, precision]
    # Add boundary points (0,1,0) at start and (1,0,1) at end
    result = [
        [0] + [item[0] for item in query_result] + [1],  # decision_boundary
        [1] + [item[1] for item in query_result] + [0],  # recall
        [0] + [item[2] for item in query_result] + [1],  # precision
    ]

    return result


def _compute_lift_curve(
    y_true: str,
    y_score: str,
    input_relation: SQLRelation,
    pos_label: PythonScalar,
    nbins: int,
) -> list[list[float]]:
    """
    Compute Lift curve using standard SQL.

    Lift Curve:
    - decision_boundary: Threshold value
    - positive_prediction_ratio: Percentage of population predicted as positive
    - lift: How much better than random (TP rate / overall positive rate)
    """
    _q = ""
    if isinstance(pos_label, str):
        _q = "'"

    query = f"""
    WITH 
    -- Step 1: Prepare data with binary labels
    prepared_data AS (
        SELECT 
            CASE WHEN CAST({y_true} AS VARCHAR) = '{pos_label}' THEN 1 ELSE 0 END AS actual,
            CAST({y_score} AS DOUBLE) AS score
        FROM {input_relation}
        WHERE {y_true} IS NOT NULL AND {y_score} IS NOT NULL
    ),
    
    -- Step 2: Get overall statistics
    overall_stats AS (
        SELECT 
            COUNT(*) AS total_count,
            SUM(actual) AS total_positives,
            CAST(SUM(actual) AS DOUBLE) / COUNT(*) AS baseline_rate
        FROM prepared_data
    ),
    
    -- Step 3: Get thresholds using APPROX_PERCENTILE
    threshold_positions AS (
        SELECT 
            bucket,
            CAST(bucket AS DOUBLE) / {nbins} AS percentile
        FROM UNNEST(sequence(0, {nbins})) AS t(bucket)
    ),
    
    thresholds AS (
        SELECT 
            tp.bucket,
            tp.percentile,
            APPROX_PERCENTILE(pd.score, tp.percentile) AS threshold
        FROM threshold_positions tp
        CROSS JOIN prepared_data pd
        GROUP BY tp.bucket, tp.percentile
    ),
    
    -- Step 4: For each threshold, compute metrics
    metrics_per_threshold AS (
        SELECT 
            t.threshold,
            t.bucket,
            -- Count predicted positives (score >= threshold)
            SUM(CASE WHEN d.score >= t.threshold THEN 1 ELSE 0 END) AS predicted_positives,
            -- Count true positives among predicted positives
            SUM(CASE WHEN d.actual = 1 AND d.score >= t.threshold THEN 1 ELSE 0 END) AS true_positives,
            -- Total records
            COUNT(*) AS total_records,
            -- Overall positive rate
            MAX(s.baseline_rate) AS baseline_rate
        FROM thresholds t
        CROSS JOIN prepared_data d
        CROSS JOIN overall_stats s
        GROUP BY t.threshold, t.bucket
    )
    
    -- Step 5: Compute decision_boundary, positive_prediction_ratio, and lift
    SELECT 
        threshold AS decision_boundary,
        
        -- Positive prediction ratio: % of population predicted as positive
        CASE 
            WHEN total_records > 0 
            THEN CAST(predicted_positives AS DOUBLE) / total_records
            ELSE 0.0 
        END AS positive_prediction_ratio,
        
        -- Lift: (TP rate in predicted positives) / (overall positive rate)
        CASE 
            WHEN predicted_positives > 0 AND baseline_rate > 0
            THEN (CAST(true_positives AS DOUBLE) / predicted_positives) / baseline_rate
            ELSE 1.0 
        END AS lift
    FROM metrics_per_threshold
    ORDER BY bucket DESC
    """

    query_result = _executeSQL(
        query=query,
        title="Computing the LIFT_CURVE.",
        method="fetchall",
    )

    # Format result: [decision_boundary, positive_prediction_ratio, lift]
    result = [
        [item[0] for item in query_result],  # decision_boundary
        [item[1] for item in query_result],  # positive_prediction_ratio
        [item[2] for item in query_result],  # lift
    ]

    return result


# Main AUC / Lift Methods.

# Functions to simplify the code.


def _check_labels(y_true, labels, input_relation):
    distinct_values = _executeSQL(
        query=f"SELECT DISTINCT {y_true} AS value FROM {input_relation}",
        method="fetchall",
    )
    if set(item[0] for item in distinct_values) != set(labels):
        raise ValueError("Mismatch between distinct values and provided labels")


@save_vastorbit_logs
def _compute_multiclass_metric(
    metric: Callable,
    y_true: str,
    y_score: Union[str, ArrayLike],
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    nbins: int = 9999,
) -> Union[float, list[float]]:
    """
    Computes the Multiclass metric.
    """
    if average == "weighted":
        confusion_list = _compute_classes_tn_fn_fp_tp(
            y_true, y_score[1], input_relation, labels
        )
        weights = [args[1] + args[3] for args in confusion_list]
    else:
        weights = [1.0 for args in labels]
    nbins_kw = {"nbins": nbins} if not isinstance(nbins, NoneType) else {}
    scores = [
        weights[i]
        * metric(
            y_true,
            y_score[0].format(labels[i]),
            input_relation,
            pos_label=labels[i],
            **nbins_kw,
        )
        for i in range(len(labels))
    ]
    return sum(scores) / sum(weights)


def _compute_micro_multiclass_metric(
    y_true: str,
    y_score: ArrayLike,
    input_relation: SQLRelation,
    labels: ArrayLike,
    nbins: int,
    fun_sql_name: Optional[str],
):
    if fun_sql_name == "roc":
        _X = ["decision_boundary", "false_positive_rate", "true_positive_rate"]
    elif fun_sql_name == "prc":
        _X = ["decision_boundary", "recall", "precision"]
    labels_query = ""
    for i in range(len(labels)):
        labels_query += f"""
                    WHEN {labels[i]} THEN {y_score[i]}"""
    decode_query = f"""
                    SELECT
                    CASE WHEN {y_true} = distinct_values.value THEN 1 ELSE 0 END AS decoded_value,
                    CASE distinct_values.value
                    {labels_query}
                    ELSE NULL
                    END AS prob_value
                    FROM
                    {input_relation},
                    (SELECT DISTINCT {y_true} AS value FROM {input_relation}) AS distinct_values"""

    if fun_sql_name == "roc":
        final_select = """
            SELECT
                threshold AS decision_boundary,
                CASE WHEN total_negatives > 0
                     THEN CAST(fp AS DOUBLE) / total_negatives ELSE 0.0 END AS false_positive_rate,
                CASE WHEN total_positives > 0
                     THEN CAST(tp AS DOUBLE) / total_positives ELSE 0.0 END AS true_positive_rate
            FROM metrics_per_threshold
            ORDER BY bucket DESC"""
    else:
        final_select = """
            SELECT
                threshold AS decision_boundary,
                CASE WHEN total_positives > 0
                     THEN CAST(tp AS DOUBLE) / total_positives ELSE 0.0 END AS recall,
                CASE WHEN (tp + fp) > 0
                     THEN CAST(tp AS DOUBLE) / (tp + fp) ELSE 1.0 END AS precision
            FROM metrics_per_threshold
            ORDER BY bucket DESC"""

    query = f"""
        WITH prepared_data AS (
            SELECT
                obs AS actual,
                CAST(prob AS DOUBLE) AS score
            FROM (
                SELECT
                    t.decoded_value AS obs,
                    t.prob_value AS prob
                FROM (
                {decode_query}) AS t) AS subquery
            WHERE prob IS NOT NULL
        ),
        threshold_positions AS (
            SELECT bucket, CAST(bucket AS DOUBLE) / {nbins} AS percentile
            FROM UNNEST(sequence(0, {nbins})) AS tt(bucket)
        ),
        thresholds AS (
            SELECT tp.bucket, tp.percentile,
                   APPROX_PERCENTILE(pd.score, tp.percentile) AS threshold
            FROM threshold_positions tp
            CROSS JOIN prepared_data pd
            GROUP BY tp.bucket, tp.percentile
        ),
        metrics_per_threshold AS (
            SELECT
                t.threshold,
                t.bucket,
                SUM(CASE WHEN d.actual = 1 AND d.score >= t.threshold THEN 1 ELSE 0 END) AS tp,
                SUM(CASE WHEN d.actual = 0 AND d.score >= t.threshold THEN 1 ELSE 0 END) AS fp,
                SUM(CASE WHEN d.actual = 0 AND d.score < t.threshold THEN 1 ELSE 0 END) AS tn,
                SUM(CASE WHEN d.actual = 1 AND d.score < t.threshold THEN 1 ELSE 0 END) AS fn,
                SUM(d.actual) AS total_positives,
                SUM(CASE WHEN d.actual = 0 THEN 1 ELSE 0 END) AS total_negatives
            FROM thresholds t
            CROSS JOIN prepared_data d
            GROUP BY t.threshold, t.bucket
        )
        {final_select}
        """
    query_result = _executeSQL(
        query=query,
        title="Computing the micro-average curve.",
        method="fetchall",
    )
    result = [
        [item[0] for item in query_result],
        [item[1] for item in query_result],
        [item[2] for item in query_result],
    ]
    if fun_sql_name == "prc":
        result[0] = [0] + result[0] + [1]
        result[1] = [1] + result[1] + [0]
        result[2] = [0] + result[2] + [1]
    return result


def _get_yscore(
    y_score: Union[str, ArrayLike],
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
) -> str:
    """
    Returns the 'y_score' to use to compute the final metric.
    """
    if isinstance(y_score, str):
        return y_score
    elif (len(y_score) == 2) and ("{}" in y_score[0]):
        return y_score[0].format(pos_label)
    elif not isinstance(labels, NoneType) and pos_label in labels:
        idx = list(labels).index(pos_label)
        return y_score[idx]
    elif len(y_score) == 2:
        return y_score[1]
    else:
        raise ValueError("Wrong parameter 'y_score'.")


@save_vastorbit_logs
def _compute_final_auc_score(
    y_true: str,
    y_score: Union[str, ArrayLike],
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
    nbins: int = 9999,
    fun_sql_name: Literal["roc", "prc", None] = None,
) -> Union[float, list[float]]:
    """
    Method used to simplify the code and compute
    the AUC.
    """
    if (
        not isinstance(pos_label, NoneType)
        or isinstance(labels, NoneType)
        and isinstance(y_score, str)
    ):
        false_positive, true_positive = _compute_function_metrics(
            y_true=y_true,
            y_score=_get_yscore(y_score, labels, pos_label),
            input_relation=input_relation,
            pos_label=pos_label,
            nbins=nbins,
            fun_sql_name=fun_sql_name,
        )[1:]
        return _compute_area(true_positive, false_positive)
    elif isinstance(y_score, str):
        raise ValueError(
            "Type Error: 'y_score' must be an ArrayLike, not a string. "
            "It is expected to be a list of strings, with each string "
            "representing the probabilities of the classes."
        )
    elif average == "micro":
        _check_labels(y_true=y_true, labels=labels, input_relation=input_relation)
        _, false_positive, true_positive = _compute_micro_multiclass_metric(
            y_true, y_score, input_relation, labels, nbins, fun_sql_name=fun_sql_name
        )
        return _compute_area(true_positive, false_positive)
    elif average == "macro":
        _check_labels(y_true=y_true, labels=labels, input_relation=input_relation)
        fpr = {}
        tpr = {}
        for i in range(len(y_score)):
            fpr[i], tpr[i] = _compute_function_metrics(
                y_true=y_true,
                y_score=y_score[i],
                input_relation=input_relation,
                pos_label=labels[i],
                nbins=nbins,
                fun_sql_name=fun_sql_name,
            )[1:]

        fpr_grid = np.linspace(0.0, 1.0, nbins)
        mean_tpr = np.zeros_like(fpr_grid)

        for i in range(len(y_score)):
            sorted_pairs = sorted(zip(fpr[i], tpr[i]))
            fpr_sorted, tpr_sorted = zip(*sorted_pairs)
            mean_tpr += np.interp(
                fpr_grid, fpr_sorted, tpr_sorted
            )  # linear interpolation

        # Average it and compute AUC
        mean_tpr /= len(y_score)
        roc_auc = _compute_area(mean_tpr.tolist()[::-1], fpr_grid.tolist()[::-1])
        return roc_auc
    elif average in (
        "weighted",
        "scores",
        None,
    ):
        all_scores = []
        for i in range(len(y_score)):
            recall, precision = _compute_function_metrics(
                y_true=y_true,
                y_score=y_score[i],
                input_relation=input_relation,
                pos_label=labels[i],
                nbins=nbins,
                fun_sql_name=fun_sql_name,
            )[1:]
            all_scores += [_compute_area(precision, recall)]
        if average in (
            "scores",
            None,
        ):
            return all_scores
        else:
            cardinality = _executeSQL(
                query=f"""
                    SELECT
                        {y_true},
                        COUNT(*)
                    FROM {input_relation}
                    GROUP BY 1""",
                title="Computing the cardinality of all categories.",
                method="fetchall",
            )
            score = 0.0
            weights = 0.0
            for i, l in enumerate(labels):
                for c in cardinality:
                    if str(c[0]) == str(l):
                        score += c[1] * all_scores[i]
                        weights += c[1]
                        break
            return score / weights
    else:
        correct_values = [
            "None",
            "'binary'",
            "'micro'",
            "'macro'",
            "'scores'",
            "'weighted'",
        ]
        raise ValueError(
            f"Incorrect Parameter 'average': Found '{average}'; "
            f"Expected: {', '.join(correct_values)}"
        )


# Main functions.


@save_vastorbit_logs
def best_cutoff(
    y_true: str,
    y_score: Union[str, ArrayLike],
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
    nbins: int = 9999,
) -> Union[float, list[float]]:
    """
    Computes the ROC AUC (Area Under Curve).

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str | ArrayLike
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.
    nbins: int, optional
        An integer value that determines the number of
        decision boundaries.
        Decision boundaries  are set at equally spaced
        intervals between 0 and 1, inclusive.
        Greater  values  for nbins give  more  precise
        estimations  of the AUC,  but can  potentially
        decrease  performance.  The  maximum value  is
        9999.  If negative,  the  maximum value  is
        used.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import best_cutoff

    Now we can conveniently calculate the score:

    .. ipython:: python

        best_cutoff(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "best_cutoff",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    if not isinstance(pos_label, NoneType) or isinstance(labels, NoneType):
        threshold, false_positive, true_positive = _compute_function_metrics(
            y_true=y_true,
            y_score=_get_yscore(y_score, labels, pos_label),
            input_relation=input_relation,
            pos_label=pos_label,
            nbins=nbins,
            fun_sql_name="roc",
        )
        l = [abs(y - x) for x, y in zip(false_positive, true_positive)]
        best_threshold_arg = max(zip(l, range(len(l))))[1]
        best = max(threshold[best_threshold_arg], 0.001)
        return min(best, 0.999)
    else:
        return _compute_multiclass_metric(
            metric=best_cutoff,
            y_true=y_true,
            y_score=y_score,
            input_relation=input_relation,
            average=average,
            labels=labels,
            nbins=nbins,
        )


@save_vastorbit_logs
def average_precision_score(
    y_true: str,
    y_score: Union[str, ArrayLike],
    input_relation: SQLRelation,
    average: Literal[None, "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
    nbins: int = 9999,
) -> float:
    """
    Computes the Average precision Score.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str |  ArrayLike
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - scores:
            scores  for   all  the  classes.

        - weighted:
            weighted average of the score of each class.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.
    nbins: int, optional
        An integer value that determines the number of
        decision boundaries.
        Decision boundaries  are set at equally spaced
        intervals between 0 and 1, inclusive.
        Greater  values  for nbins give  more  precise
        estimations  of the AUC,  but can  potentially
        decrease  performance.  The  maximum value  is
        9999.  If negative,  the  maximum value  is
        used.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [1, 1, 1, 0, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import average_precision_score

    Now we can conveniently calculate the score:

    .. ipython:: python

        average_precision_score(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "average_precision_score",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    if not isinstance(pos_label, NoneType) or isinstance(labels, NoneType):
        recall, precision = _compute_function_metrics(
            y_true=y_true,
            y_score=_get_yscore(y_score, labels, pos_label),
            input_relation=input_relation,
            pos_label=pos_label,
            nbins=nbins,
            fun_sql_name="prc",
        )[1:]
        return -np.sum(np.diff(recall) * np.array(precision)[:-1])
    else:
        _check_labels(y_true=y_true, labels=labels, input_relation=input_relation)
    if average == "micro":
        _, recall, precision = _compute_micro_multiclass_metric(
            y_true, y_score, input_relation, labels, nbins, fun_sql_name="prc"
        )
        return -np.sum(np.diff(recall) * np.array(precision)[:-1])
    elif average == "macro":
        aps = 0
        for i, label in enumerate(labels):
            aps += average_precision_score(
                y_true=y_true,
                y_score=y_score[i],
                input_relation=input_relation,
                average=None,
                labels=None,
                pos_label=label,
                nbins=nbins,
            )
        return aps / len(labels)
    elif average == "weighted":
        aps = 0
        all_weights = 0
        for i, label in enumerate(labels):
            weight = len(input_relation[input_relation[y_true] == label])
            aps += weight * average_precision_score(
                y_true=y_true,
                y_score=y_score[i],
                input_relation=input_relation,
                average=None,
                labels=None,
                pos_label=label,
                nbins=nbins,
            )
            all_weights += weight
        return aps / all_weights
    else:
        aps = []
        for i, label in enumerate(labels):
            aps.append(
                average_precision_score(
                    y_true=y_true,
                    y_score=y_score[i],
                    input_relation=input_relation,
                    average=None,
                    labels=None,
                    pos_label=label,
                    nbins=nbins,
                )
            )
        return aps

    return None


@save_vastorbit_logs
def roc_auc_score(
    y_true: str,
    y_score: Union[str, ArrayLike],
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
    nbins: int = 9999,
) -> Union[float, list[float]]:
    """
    Computes the ROC AUC (Area Under Curve).

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str |  ArrayLike
        When 'pos_label' and 'labels' are not defined, it
        should be a list of  probabilities represented by
        SQL  code for  the different classes in  the same
        order   as  the  labels.  Otherwise,   'pos_label'
        represents   the   main   class,   and   'y_score'
        represents its probability.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.
    nbins: int, optional
        An integer value that determines the number of
        decision boundaries.
        Decision boundaries  are set at equally spaced
        intervals between 0 and 1, inclusive.
        Greater  values  for nbins give  more  precise
        estimations  of the AUC,  but can  potentially
        decrease  performance.  The  maximum value  is
        9999.  If negative,  the  maximum value  is
        used.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - probability of the true value

    .. important::

        This classification metric does not use the
        predicted value. Instead, it measures the performance
        of a classification model by evaluating the likelihood
        of the true labels given the predicted probabilities.

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_prob": [0.5, 0.9, 0.2, 0.5, 0.6],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import roc_auc_score

    Now we can conveniently calculate the score:

    .. ipython:: python

        roc_auc_score(
            y_true  = "y_true",
            y_score = "y_prob",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_prob",
            metric  = "roc_auc",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_auc_score(
        y_true=y_true,
        y_score=y_score,
        input_relation=input_relation,
        average=average,
        labels=labels,
        pos_label=pos_label,
        nbins=nbins,
        fun_sql_name="roc",
    )


@save_vastorbit_logs
def prc_auc_score(
    y_true: str,
    y_score: Union[str, ArrayLike],
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: Optional[PythonScalar] = None,
    nbins: int = 9999,
) -> Union[float, list[float]]:
    """
    Computes the area under the curve (AUC) of a
    Precision-Recall (PRC) curve.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str | ArrayLike
        When 'pos_label' and 'labels' are not defined, it
        should be a list of  probabilities represented by
        SQL  code for  the different classes in  the same
        order   as  the  labels.  Otherwise,   'pos_label'
        represents   the   main   class,   and   'y_score'
        represents its probability.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The method used to  compute the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of   the  response  column   categories.
    pos_label: PythonScalar, optional
        To  compute  the metric, one of  the  response
        column classes must be the positive class. The
        parameter 'pos_label' represents this class.
    nbins: int, optional
        An integer value that determines the number of
        decision boundaries.
        Decision boundaries  are set at equally spaced
        intervals between 0 and 1, inclusive.
        Greater  values  for nbins give  more  precise
        estimations  of the AUC,  but can  potentially
        decrease  performance.  The  maximum value  is
        9999.  If negative,  the  maximum value  is
        used.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - probability of the true value

    .. important::

        This classification metric does not use the
        predicted value. Instead, it measures the performance
        of a classification model by evaluating the likelihood
        of the true labels given the predicted probabilities.

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_pred": [0.5, 0.9, 0.2, 0.5, 0.6],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import prc_auc_score

    Now we can conveniently calculate the score:

    .. ipython:: python

        prc_auc_score(
            y_true  = "y_true",
            y_score = "y_pred",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_pred",
            metric  = "prc_auc",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    return _compute_final_auc_score(
        y_true=y_true,
        y_score=y_score,
        input_relation=input_relation,
        average=average,
        labels=labels,
        pos_label=pos_label,
        nbins=nbins,
        fun_sql_name="prc",
    )


# Logloss Metric.


@save_vastorbit_logs
def log_loss(
    y_true: str,
    y_score: Union[str, ArrayLike],
    input_relation: SQLRelation,
    average: Literal[None, "binary", "micro", "macro", "scores", "weighted"] = None,
    labels: Optional[ArrayLike] = None,
    pos_label: PythonScalar = 1,
) -> Union[float, list[float]]:
    """
    Computes the Log Loss.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str | ArrayLike
        Prediction Probability.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can be a
        view, table, or a customized relation (if an  alias
        is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    average: str, optional
        The  method  used  to  compute  the final score for
        multiclass-classification.

        - binary:
            considers one of the classes  as
            positive  and  use  the   binary
            confusion  matrix to compute the
            score.

        - micro:
            positive  and   negative  values globally.

        - macro:
            average  of  the  score of  each class.

        - score:
            scores  for   all  the  classes.

        - weighted :
            weighted average of the score of
            each class.

        - None:
            accuracy.

        If  empty,  the  behaviour  is  similar to  the
        'scores' option.
    labels: ArrayLike, optional
        List   of    the    response   column    categories.
    pos_label: PythonScalar, optional
        To compute the log loss,  one of the response column
        classes must  be  the  positive class. The parameter
        'pos_label' represents this class.

    Returns
    -------
    float
        score.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Let's create a small dataset that has:

    - true value
    - probability of the true value

    .. important::

        This classification metric does not use the
        predicted value. Instead, it measures the performance
        of a classification model by evaluating the likelihood
        of the true labels given the predicted probabilities.

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_prob": [0.5, 0.9, 0.2, 0.5, 0.6],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import log_loss

    Now we can conveniently calculate the score:

    .. ipython:: python

        log_loss(
            y_true  = "y_true",
            y_score = "y_prob",
            input_relation = data,
        )

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = "y_prob",
            metric  = "log_loss",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """
    if not isinstance(pos_label, NoneType) or isinstance(labels, NoneType):
        _q = ""
        if isinstance(pos_label, str):
            _q = "'"
        y_s = _get_yscore(y_score, labels, pos_label)
        return _executeSQL(
            query=f"""
                SELECT 
                    /*+LABEL('learn.metrics.logloss')*/ 
                    AVG(CASE 
                            WHEN CAST({y_true} AS VARCHAR) = '{pos_label}'
                            THEN - LN(CAST({y_s} AS DOUBLE) + 1e-90) 
                            ELSE - LN(CAST(1 - {y_s} AS DOUBLE) + 1e-90) 
                        END) 
                FROM {input_relation} 
                WHERE {y_true} IS NOT NULL 
                  AND {y_s} IS NOT NULL;""",
            title="Computing log loss.",
            method="fetchfirstelem",
        )
    else:
        return _compute_multiclass_metric(
            metric=log_loss,
            y_true=y_true,
            y_score=y_score,
            input_relation=input_relation,
            average=average,
            labels=labels,
            nbins=None,
        )


"""
Reports.
"""
FUNCTIONS_CONFUSION_DICTIONNARY = {
    "accuracy": _accuracy_score,
    "acc": _accuracy_score,
    "balanced_accuracy_score": _balanced_accuracy_score,
    "ba": _balanced_accuracy_score,
    "recall": _recall_score,
    "tpr": _recall_score,
    "precision": _precision_score,
    "ppv": _precision_score,
    "specificity": _specificity_score,
    "tnr": _specificity_score,
    "negative_predictive_value": _negative_predictive_score,
    "npv": _negative_predictive_score,
    "f1": _f1_score,
    "f1_score": _f1_score,
    "false_negative_rate": _false_negative_rate,
    "fnr": _false_negative_rate,
    "false_positive_rate": _false_positive_rate,
    "fpr": _false_positive_rate,
    "false_discovery_rate": _false_discovery_rate,
    "fdr": _false_discovery_rate,
    "false_omission_rate": _false_omission_rate,
    "for": _false_omission_rate,
    "positive_likelihood_ratio": _positive_likelihood_ratio,
    "lr+": _positive_likelihood_ratio,
    "negative_likelihood_ratio": _negative_likelihood_ratio,
    "lr-": _negative_likelihood_ratio,
    "diagnostic_odds_ratio": _diagnostic_odds_ratio,
    "dor": _diagnostic_odds_ratio,
    "mcc": _matthews_corrcoef,
    "bm": _informedness,
    "informedness": _informedness,
    "mk": _markedness,
    "markedness": _markedness,
    "ts": _critical_success_index,
    "csi": _critical_success_index,
    "critical_success_index": _critical_success_index,
    "fowlkes_mallows_index": _fowlkes_mallows_index,
    "fm": _fowlkes_mallows_index,
    "prevalence_threshold": _prevalence_threshold,
    "pt": _prevalence_threshold,
}

FUNCTIONS_OTHER_METRICS_DICTIONNARY = {
    "auc": roc_auc_score,
    "roc_auc": roc_auc_score,
    "prc_auc": prc_auc_score,
    "best_cutoff": best_cutoff,
    "best_threshold": best_cutoff,
    "log_loss": log_loss,
    "logloss": log_loss,
}


@save_vastorbit_logs
def classification_report(
    y_true: Optional[str] = None,
    y_score: Optional[list] = None,
    input_relation: Optional[SQLRelation] = None,
    metrics: Union[None, str, list[str]] = None,
    labels: Optional[ArrayLike] = None,
    cutoff: Optional[PythonNumber] = None,
    nbins: int = 9999,
    estimator: Optional["VASTModel"] = None,
) -> Union[float, TableSample]:
    """
    Computes  a classification  report using  multiple
    metrics (AUC, accuracy, PRC AUC, F1...). In the case
    of multiclass classification, it  considers each
    category as positive and switches to the next one
    during the computation.

    Parameters
    ----------
    y_true: str
        Response column.
    y_score: str
        Prediction.
    input_relation: SQLRelation
        Relation to use for scoring. This relation can
        be a view, table, or a customized relation (if
        an alias is used at the end of the relation).
        For example: (SELECT ... FROM ...) x
    metrics: list, optional
        List of the metrics used to compute the final
        report.

        - accuracy:
            Accuracy.

            .. math::

                Accuracy = \\frac{TP + TN}{TP + TN + FP + FN}

        - aic:
            Akaike's  Information  Criterion

            .. math::

                AIC = 2k - 2\\ln(\\hat{L})

        - auc:
            Area Under the Curve (ROC).

            .. math::

                AUC = \\int_{0}^{1} TPR(FPR) \\, dFPR

        - ba:
            Balanced Accuracy.

            .. math::

                BA = \\frac{TPR + TNR}{2}

        - best_cutoff:
            Cutoff  which optimised the  ROC
            Curve prediction.

        - bic:
            Bayesian  Information  Criterion

            .. math::

                BIC = -2\\ln(\\hat{L}) + k \\ln(n)

        - bm:
            Informedness

            .. math::

                BM = TPR + TNR - 1

        - csi:
            Critical Success Index

            .. math::

                index = \\frac{TP}{TP + FN + FP}

        - f1:
            F1 Score

            .. math::

                F_1 Score = 2 \\times \\frac{Precision \\times Recall}{Precision + Recall}

        - fdr:
            False Discovery Rate

            .. math::

                FDR = 1 - PPV

        - fm:
            Fowlkes-Mallows index

            .. math::

                FM = \\sqrt{PPV * TPR}

        - fnr:
            False Negative Rate

            .. math::

                FNR = \\frac{FN}{FN + TP}

        - for:
            False Omission Rate

            .. math::

                FOR = 1 - NPV

        - fpr:
            False Positive Rate

            .. math::

                FPR = \\frac{FP}{FP + TN}

        - logloss:
            Log Loss.

            .. math::

                Loss = -\\frac{1}{N} \\sum_{i=1}^{N} \\left( y_i \\log(p_i) + (1 - y_i) \\log(1 - p_i) \\right)


        - lr+:
            Positive Likelihood Ratio.

            .. math::

                LR+ = \\frac{TPR}{FPR}

        - lr-:
            Negative Likelihood Ratio.

            .. math::

                LR- = \\frac{FNR}{TNR}

        - dor:
            Diagnostic Odds Ratio.

            .. math::

                DOR = \\frac{TP \\times TN}{FP \\times FN}

        - mc:
            Matthews Correlation Coefficient
            .. math::

                MCC = \\frac{TP \\times TN - FP \\times FN}{\\sqrt{(TP + FP)(TP + FN)(TN + FP)(TN + FN)}}

        - mk:
            Markedness

            .. math::

                MK = PPV + NPV - 1

        - npv:
            Negative Predictive Value

            .. math::

                NPV = \\frac{TN}{TN + FN}

        - prc_auc:
            Area Under the Curve (PRC)

            .. math::

                AUC = \\int_{0}^{1} Precision(Recall) \\, dRecall

        - precision:
            Precision

            .. math::

                Precision = TP / (TP + FP)

        - pt:
            Prevalence Threshold.

            .. math::

                threshold = \\frac{\\sqrt{FPR}}{\\sqrt{TPR} + \\sqrt{FPR}}

        - recall:
            Recall.

            .. math::
                Recall = \\frac{TP}{TP + FN}

        - specificity:
            Specificity.

            .. math::

                Specificity = \\frac{TN}{TN + FP}

    labels: ArrayLike, optional
        List of the response column categories to use.
    cutoff: PythonNumber, optional
        Cutoff  for which the tested category will  be
        accepted as prediction.
    nbins: int, optional
        [Used to compute ROC AUC, PRC AUC and the best
        cutoff]
        An integer value that determines the number of
        decision boundaries.
        Decision boundaries  are set at equally spaced
        intervals between 0 and 1, inclusive.
        Greater  values  for nbins give  more  precise
        estimations  of the AUC,  but can  potentially
        decrease  performance.  The  maximum value  is
        9999.  If negative,  the  maximum value  is
        used.
    estimator: object, optional
        Estimator used to compute the classification
        report.

    Returns
    -------
    TableSample
        report.

    Examples
    --------

    We should first import vastorbit.

    .. ipython:: python

        import vastorbit as vo

    Binary Classification
    ^^^^^^^^^^^^^^^^^^^^^^^

    Let's create a small dataset that has:

    - true value
    - probability of the true value
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 1, 0, 0, 1],
                "y_prob": [0.8, 0.2, 0.1, 0.6, 0.8],
                "y_pred": [1, 0, 0, 1, 1]
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import classification_report

    Now we can conveniently calculate the score:

    .. ipython:: python

        classification_report(
            y_true  = "y_true",
            y_score = ["y_prob", "y_pred"],
            input_relation = data,
        )

    .. important::

        In binary classification, ``y_score`` should
        be a list of two column names:

        - Probability of true value
        - Prediction value

        In the case of multi-class, ``y_score``,
        is the list of two elements:

        - list of column names for class probabilities
          for each class

        - Prediction value

    .. note::

        For multi-class classification, we can select
        the ``average`` method for averaging from the
        following options:
        - binary
        - micro
        - macro
        - scores
        - weighted

    It is also possible to directly compute the score
    from the VastFrame:

    .. ipython:: python

        data.score(
            y_true  = "y_true",
            y_score = ["y_prob", "y_pred"],
            metric  = "classification_report",
        )

    .. note::

        vastorbit uses simple SQL queries to compute various metrics.
        You can use the :py:meth:`~vastorbit.set_option` function with
        the ``sql_on`` parameter to enable SQL generation and examine
        the generated queries.

    Multi-class Classification
    ^^^^^^^^^^^^^^^^^^^^^^^^^^

    Let's create a small dataset that has:

    - true value with more than two classes
    - probability of each class
    - predicted value

    .. ipython:: python

        data = vo.VastFrame(
            {
                "y_true": [1, 2, 0, 0, 1],
                "y_prob_0": [0.1, 0.1, 0.1, 0.1, 0.1],
                "y_prob_1": [0.8, 0.6, 0.4, 0.6, 0.2],
                "y_prob_2": [0.1, 0.3, 0.5, 0.3, 0.7],
                "y_pred": [1, 2, 0, 1, 1],
            },
        )

    Next, we import the metric:

    .. ipython:: python

        from vastorbit.machine_learning.metrics import classification_report

    Now we can conveniently calculate the score:

    .. ipython:: python

        classification_report(
            y_true  = "y_true",
            y_score =[["y_prob_0","y_prob_1","y_prob_1"], "y_pred"],
            labels = [0,1,2],
            input_relation = data,
        )

    .. seealso::

        | ``VastFrame.``:py:meth:`~vastorbit.VastFrame.score` : Computes the input ML metric.
    """

    # Initialization

    # Case when a list of probabilities is used
    prob_list = False
    if (
        isinstance(y_score, list)
        and (len(y_score) > 0)
        and isinstance(y_score[0], list)
    ):
        new_score = "CASE"
        n = len(y_score[0])
        if isinstance(labels, NoneType):
            labels = [i for i in range(n)]
        elif len(labels) < n:
            raise ValueError(
                f"Incorrect Parameter Label. The size should be: {n}; Found: {len(labels)}"
            )
        for i, yi in enumerate(y_score[0]):
            new_score += f" WHEN '{{0}}' = '{labels[i]}' THEN {yi}"
        new_score += " END"
        y_score[0] = new_score
        prob_list = True

    # Other parameters
    return_scalar = False
    if isinstance(metrics, str):
        metrics = [metrics]
        return_scalar = True
    if estimator:
        num_classes = len(estimator.classes_)
        labels = labels if (num_classes != 2) else [estimator.classes_[1]]
    else:
        labels = [1] if isinstance(labels, NoneType) else labels
        num_classes = len(labels) + 1
    if isinstance(metrics, NoneType):
        metrics = [
            "auc",
            "prc_auc",
            "accuracy",
            "log_loss",
            "precision",
            "recall",
            "f1_score",
            "mcc",
            "informedness",
            "markedness",
            "csi",
        ]
    values = {"index": metrics}

    # Computation
    if isinstance(cutoff, NoneType) and num_classes > 2:
        if estimator:
            cm = estimator.confusion_matrix()
        elif isinstance(y_score, (NoneType, str)):
            cm = confusion_matrix(y_true, y_score, input_relation, labels=labels)
        else:
            cm = confusion_matrix(y_true, y_score[1], input_relation, labels=labels)
        all_cm_metrics = _compute_classes_tn_fn_fp_tp_from_cm(cm)
        is_multi = True
    else:
        all_cm_metrics = []
        is_multi = False
    for idx, pos_label in enumerate(labels):
        y_s = "undefined"
        y_t = "undefined"
        _q = ""
        if isinstance(pos_label, str):
            _q = "'"
        if is_multi:
            tn, fn, fp, tp = all_cm_metrics[idx]
            if prob_list:
                y_s = y_score[0].format(pos_label)
                y_t = f"CASE CAST({y_true} AS VARCHAR) WHEN '{pos_label}' THEN 1 ELSE 0 END"
        else:
            if estimator:
                cm = estimator.confusion_matrix(pos_label=pos_label, cutoff=cutoff)
            else:
                y_s = y_score[0].format(pos_label)
                y_p = y_score[1]
                y_t = f"CASE CAST({y_true} AS VARCHAR) WHEN '{pos_label}' THEN 1 ELSE 0 END"
                cm = confusion_matrix(y_true, y_p, input_relation, pos_label=pos_label)
            tn, tp = cm[0][0], cm[1][1]
            fn, fp = cm[1][0], cm[0][1]
        if len(labels) == 1:
            key = "value"
        else:
            key = pos_label
        values[key] = []
        for m in metrics:
            if m in FUNCTIONS_CONFUSION_DICTIONNARY:
                fun = FUNCTIONS_CONFUSION_DICTIONNARY[m]
                values[key] += [fun(tn, fn, fp, tp)]
            elif m in FUNCTIONS_OTHER_METRICS_DICTIONNARY:
                if estimator:
                    values[key] += [
                        estimator.score(pos_label=pos_label, metric=m, nbins=nbins)
                    ]
                else:
                    fun = FUNCTIONS_OTHER_METRICS_DICTIONNARY[m]
                    values[key] += [fun(y_t, y_s, input_relation, pos_label=1)]
            else:
                possible_metrics = list(FUNCTIONS_CONFUSION_DICTIONNARY) + list(
                    FUNCTIONS_OTHER_METRICS_DICTIONNARY
                )
                possible_metrics = "|".join(possible_metrics)
                raise ValueError(
                    f"Undefined Metric '{m}'. Must be in {possible_metrics}."
                )
        if not is_multi:
            all_cm_metrics += [(tn, fn, fp, tp)]
    res = TableSample(values)
    if num_classes > 2:
        return_scalar = False
        res_array = res.to_numpy()
        # Models such as KNeighbors can return None for metrics they don't
        # support (e.g. probability-based ones like AUC); coerce those to NaN so
        # the macro / weighted averages don't raise "NoneType + NoneType".
        res_array = np.array(
            [[np.nan if v is None else v for v in row] for row in res_array],
            dtype=float,
        )
        n, m = res_array.shape
        avg_macro, avg_micro, avg_weighted = [], [], []
        for i in range(n):
            avg_macro += [np.nanmean(res_array[i])]
            weights = np.array([args[3] + args[1] for args in all_cm_metrics])
            avg_weighted += [np.nansum(res_array[i] * weights) / weights.sum()]
        res.values["avg_macro"] = avg_macro
        res.values["avg_weighted"] = avg_weighted
        args = [sum(args[i] for args in all_cm_metrics) for i in range(4)]
        for m in metrics:
            if m in FUNCTIONS_CONFUSION_DICTIONNARY:
                fun = FUNCTIONS_CONFUSION_DICTIONNARY[m]
                avg_micro += [fun(*args)]
            else:
                avg_micro += [None]
        res.values["avg_micro"] = avg_micro
    if return_scalar:
        res_array = res.to_numpy()
        n, m = res_array.shape
        if n == 1 and m == 1:
            return float(res_array[0][0])
    return res
